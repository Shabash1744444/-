from __future__ import annotations
from dataclasses import dataclass,asdict
from collections import defaultdict
from typing import Optional
import hashlib,time,re

KINDS={'SIGN','WORD','PHRASE','PROPOSITION','EVENT','EPISODE','STORY','BOOK'}
LINKS={'PART_OF','REFERS_TO','EXPRESSES','ORDER','INDEXES'}

@dataclass
class CompositionUnit:
    unit_id:str
    kind:str
    text:str
    created_step:int=0
    wall_time:float=0.0
    source_event_id:Optional[str]=None
    status:str='REPRESENTATION'
    semantic_eids:tuple=()
    meta:dict=None

    def to_dict(self):
        d=asdict(self);d['semantic_eids']=list(self.semantic_eids);d['meta']=dict(self.meta or {})
        return d

class SemanticComposition:
    """Non-truth representational weave over the continuous life-line.

    Units and links describe composition/indexing.  They never grant COMMIT
    authority to the semantic/world graph.  A phrase may express a proposition;
    an episode may contain events; a sign may index a story.  None implies truth.
    """
    SCHEMA='C4_SEMANTIC_COMPOSITION_V0.1'

    def __init__(self):
        self.units={}
        self.links=[]
        self._seq=0
        self.event_units={}     # life event id -> composition EVENT

    def _id(self,kind,text,step,source_event_id=None):
        self._seq+=1
        raw=f'{self._seq}|{kind}|{text}|{step}|{source_event_id or ""}'.encode('utf-8')
        return 'cmp:'+hashlib.blake2s(raw,digest_size=9).hexdigest()

    def add_unit(self,kind,text,*,step=0,source_event_id=None,status='REPRESENTATION',semantic_eids=(),meta=None):
        kind=str(kind).upper()
        if kind not in KINDS:raise ValueError(kind)
        uid=self._id(kind,str(text),int(step),source_event_id)
        self.units[uid]=CompositionUnit(uid,kind,str(text),int(step),time.time(),source_event_id,str(status),tuple(dict.fromkeys(semantic_eids or ())),dict(meta or {}))
        if kind=='EVENT' and source_event_id:self.event_units[str(source_event_id)]=uid
        return uid

    def link(self,source,target,relation,*,order=None,meta=None):
        relation=str(relation).upper()
        if relation not in LINKS:raise ValueError(relation)
        if source not in self.units:raise KeyError(source)
        # REFERS_TO may point to an external semantic entity; other links stay internal.
        if relation!='REFERS_TO' and target not in self.units:raise KeyError(target)
        row={'source':source,'target':str(target),'relation':relation}
        if order is not None:row['order']=int(order)
        if meta:row['meta']=dict(meta)
        key=(row['source'],row['target'],row['relation'],row.get('order'))
        if not any((x['source'],x['target'],x['relation'],x.get('order'))==key for x in self.links):self.links.append(row)
        return row

    def record_message(self,text,*,step,source_event_id,parsed=None,semantic_eids=()):
        """Create FORM/meaning composition without asserting the proposition."""
        phrase=self.add_unit('PHRASE',text,step=step,source_event_id=source_event_id,semantic_eids=semantic_eids,
                             meta={'surface':True})
        event=self.add_unit('EVENT','message received',step=step,source_event_id=source_event_id,
                            semantic_eids=semantic_eids,meta={'event_kind':'MESSAGE_RECEIVED'})
        self.link(phrase,event,'PART_OF',order=0)
        for eid in semantic_eids or ():
            self.link(phrase,eid,'REFERS_TO')
        p_kind=(parsed or {}).get('kind') if isinstance(parsed,dict) else None
        if p_kind and p_kind!='UNKNOWN':
            prop=self.add_unit('PROPOSITION',text,step=step,source_event_id=source_event_id,status='CANDIDATE',
                               semantic_eids=semantic_eids,meta={'parse_kind':p_kind,'truth_status':'UNCOMMITTED'})
            self.link(phrase,prop,'EXPRESSES')
            self.link(prop,event,'PART_OF',order=1)
            for eid in semantic_eids or ():
                self.link(prop,eid,'REFERS_TO')
        return event

    def ensure_life_event(self,event,*,step=0,semantic_eids=()):
        eid=str((event or {}).get('event_id') or '')
        if eid and eid in self.event_units:return self.event_units[eid]
        kind=str((event or {}).get('kind') or 'EVENT')
        text=str((event or {}).get('text') or kind)
        return self.add_unit('EVENT',text,step=int((event or {}).get('step',step)),source_event_id=eid or None,
                             semantic_eids=semantic_eids,meta={'event_kind':kind,'actor':(event or {}).get('actor')})

    def make_episode(self,label,event_units,*,step=0):
        ep=self.add_unit('EPISODE',label,step=step,meta={'truth_status':'UNCOMMITTED'})
        for i,eid in enumerate(event_units):self.link(eid,ep,'PART_OF',order=i)
        return ep

    def make_story(self,label,episode_units,*,step=0):
        st=self.add_unit('STORY',label,step=step,meta={'truth_status':'UNCOMMITTED'})
        for i,eid in enumerate(episode_units):self.link(eid,st,'PART_OF',order=i)
        return st

    def make_book(self,label,story_units,*,step=0):
        b=self.add_unit('BOOK',label,step=step,meta={'truth_status':'UNCOMMITTED'})
        for i,sid in enumerate(story_units):self.link(sid,b,'PART_OF',order=i)
        return b

    def bind_sign(self,sign,target_unit,*,step=0):
        if target_unit not in self.units:raise KeyError(target_unit)
        s=self.add_unit('SIGN',sign,step=step,status='INDEX')
        self.link(s,target_unit,'INDEXES')
        return s

    def parts(self,parent):
        rows=[x for x in self.links if x['relation']=='PART_OF' and x['target']==parent]
        return [x['source'] for x in sorted(rows,key=lambda x:x.get('order',10**9))]

    def descendants(self,unit_id):
        out=[];seen=set();stack=list(reversed(self.parts(unit_id)))
        while stack:
            x=stack.pop()
            if x in seen:continue
            seen.add(x);out.append(x);stack.extend(reversed(self.parts(x)))
        return out

    def semantic_refs(self,unit_id):
        nodes=[unit_id]+self.descendants(unit_id);refs=[]
        for uid in nodes:
            u=self.units.get(uid)
            for eid in (u.semantic_eids if u else ()):
                if eid not in refs:refs.append(eid)
            for x in self.links:
                if x['source']==uid and x['relation']=='REFERS_TO' and x['target'] not in refs:refs.append(x['target'])
        return refs

    def indexed_target(self,sign_unit):
        for x in self.links:
            if x['source']==sign_unit and x['relation']=='INDEXES':return x['target']
        return None

    def to_dict(self):
        return {'schema':self.SCHEMA,'seq':self._seq,'units':{k:v.to_dict() for k,v in self.units.items()},'links':list(self.links),'event_units':dict(self.event_units)}

    @classmethod
    def from_dict(cls,d):
        x=cls()
        if not d:return x
        x._seq=int(d.get('seq',0))
        for uid,row in (d.get('units') or {}).items():
            row=dict(row);row['semantic_eids']=tuple(row.get('semantic_eids') or ());row['meta']=dict(row.get('meta') or {})
            x.units[uid]=CompositionUnit(**row)
        x.links=[dict(r) for r in d.get('links',[]) if isinstance(r,dict)]
        x.event_units={str(k):str(v) for k,v in (d.get('event_units') or {}).items() if v in x.units}
        return x

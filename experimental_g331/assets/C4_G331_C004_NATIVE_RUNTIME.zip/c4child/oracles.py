from __future__ import annotations
from dataclasses import dataclass, asdict
from fractions import Fraction
from decimal import Decimal, InvalidOperation
import ast, operator, hashlib

OWNERS=('EVAL','COMMIT','DRIVE','MEDIATE')
KAPPA=('MASK','VALUE','AVAIL','TRIGGER','STATUS')

@dataclass(frozen=True)
class OracleReceipt:
    oracle:str
    query:str
    result:str
    exact:bool
    provenance:str
    receipt_id:str
    meta:dict
    def to_dict(self): return asdict(self)

class ExactMathOracle:
    """Tiny exact arithmetic oracle. It is a verifier/tool, not C4 memory itself."""
    ORIGIN='EXACT_MATH_ORACLE'
    _BIN={ast.Add:operator.add, ast.Sub:operator.sub, ast.Mult:operator.mul,
          ast.Div:operator.truediv, ast.FloorDiv:operator.floordiv, ast.Mod:operator.mod,
          ast.Pow:operator.pow}
    _UN={ast.UAdd:operator.pos, ast.USub:operator.neg}

    @classmethod
    def _eval(cls,node):
        if isinstance(node,ast.Expression): return cls._eval(node.body)
        if isinstance(node,ast.Constant) and isinstance(node.value,int): return Fraction(node.value,1)
        if isinstance(node,ast.UnaryOp) and type(node.op) in cls._UN: return cls._UN[type(node.op)](cls._eval(node.operand))
        if isinstance(node,ast.BinOp) and type(node.op) in cls._BIN:
            a,b=cls._eval(node.left),cls._eval(node.right)
            if isinstance(node.op,ast.Pow):
                if b.denominator!=1 or abs(b.numerator)>12: raise ValueError('unsupported exponent')
                return a ** b.numerator
            if isinstance(node.op,(ast.FloorDiv,ast.Mod)):
                if a.denominator!=1 or b.denominator!=1: raise ValueError('integer op only')
                if b==0: raise ZeroDivisionError
                return Fraction(cls._BIN[type(node.op)](a.numerator,b.numerator),1)
            if b==0 and isinstance(node.op,ast.Div): raise ZeroDivisionError
            return cls._BIN[type(node.op)](a,b)
        raise ValueError('unsupported expression')

    @classmethod
    def evaluate(cls,expr:str)->OracleReceipt:
        tree=ast.parse(str(expr),mode='eval')
        value=cls._eval(tree)
        result=str(value.numerator) if value.denominator==1 else f'{value.numerator}/{value.denominator}'
        raw=f'{cls.ORIGIN}|{expr}|{result}'.encode()
        rid='oracle:'+hashlib.blake2s(raw,digest_size=10).hexdigest()
        return OracleReceipt(cls.ORIGIN,str(expr),result,True,cls.ORIGIN,rid,{'numeric_type':'rational'})

    @classmethod
    def multiplication_table(cls,lo:int=0,hi:int=12):
        out=[]
        for a in range(int(lo),int(hi)+1):
            for b in range(int(lo),int(hi)+1):
                out.append(cls.evaluate(f'{a}*{b}'))
        return out

class ConstitutionOracle:
    """Syntactic oracle for the four-owner/five-effect vocabulary.

    The 80 combinations are a coarse candidate signature space, not 80 facts about
    the world and not proof that every combination is semantically realizable.
    """
    ORIGIN='CONSTITUTION_ORACLE'
    @staticmethod
    def coarse_signature_space():
        return [(src,dst,k) for src in OWNERS for dst in OWNERS for k in KAPPA]
    @staticmethod
    def vocabulary_valid(src,dst,k):
        return src in OWNERS and dst in OWNERS and k in KAPPA

@dataclass(frozen=True)
class SandboxReceipt:
    world_id:str
    episode_id:str
    step:int
    action:str
    pre_state_hash:str
    post_state_hash:str
    outcome:str
    success:bool
    provenance:str='SANDBOX_RECEIPT'
    reality_scope:str='SIMULATION'
    def to_dict(self): return asdict(self)

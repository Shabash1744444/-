from __future__ import annotations
from dataclasses import dataclass, asdict
from math import log1p
from typing import Iterable, List
from .gaps import KnowledgeGap, OPEN

@dataclass(frozen=True)
class LearningTarget:
    gap_id: str
    kind: str
    subject: str
    relation: str | None
    object_value: str | None
    score: float
    evidence_count: int
    dependency_count: int
    expected_unlocks: int
    estimated_teacher_cost: float
    reason: str


def estimated_teacher_cost(g: KnowledgeGap) -> float:
    """Crude intervention cost used only for curriculum ranking.

    This is not truth confidence and not semantic value.  A short yes/no relation
    normally costs less teacher effort than a definition or causal explanation.
    The constants are intentionally coarse; measured teacher words/relations remain
    the authoritative benchmark after the answer is received.
    """
    if g.kind in {'RELATION','COMPETENCY_RELATION','COMPETENCY_RELATION_TRUE','COMPETENCY_RELATION_FALSE'}:
        return 1.0
    if g.kind in {'LANGUAGE_RELATION'}:
        return 1.15
    if g.kind in {'LEXICAL_TERM'}:
        return 1.25
    if g.kind in {'DEFINITION'}:
        return 1.35
    if g.kind in {'CAUSE_OF','EFFECT_OF','CAUSAL_RELATION'}:
        return 1.65
    if g.kind in {'RULE_EXAMPLE','EPISTEMIC_VALIDATION'}:
        return 1.8
    return 1.4


def agenda_score(g: KnowledgeGap, current_step: int) -> float:
    """Expected learning utility per approximate unit of teacher effort.

    `cause_ids` are independent downstream needs/queries blocked by the same gap.
    Therefore a gap repeatedly blocking different things should outrank a one-off
    curiosity even when both have similar base priority.  Repetition still matters,
    but with diminishing returns.  Age prevents starvation.

    This score ranks *what to ask next*.  It never changes graph truth.
    """
    need = log1p(max(0, int(g.evidence_count)))
    unlocks = max(1, len(set(g.cause_ids)))
    deps = log1p(unlocks)
    age = log1p(max(0, int(current_step) - int(g.first_step)))
    cost = estimated_teacher_cost(g)
    gross = float(g.priority) * (1.0 + 0.35 * need + 1.20 * deps) + 0.012 * age
    return gross / max(0.25, cost)


def build_agenda(gaps: Iterable[KnowledgeGap], current_step: int, limit: int = 5) -> List[LearningTarget]:
    rows=[]
    for g in gaps:
        if g.status != OPEN:
            continue
        unlocks=max(1,len(set(g.cause_ids)))
        rows.append(LearningTarget(
            gap_id=g.gap_id, kind=g.kind, subject=g.subject,
            relation=g.relation, object_value=g.object_value,
            score=agenda_score(g,current_step), evidence_count=int(g.evidence_count),
            dependency_count=len(g.cause_ids), expected_unlocks=unlocks,
            estimated_teacher_cost=estimated_teacher_cost(g), reason=g.reason,
        ))
    rows.sort(key=lambda x:(-x.score,-x.expected_unlocks,-x.evidence_count,x.gap_id))
    return rows[:max(0,int(limit))]


def agenda_dicts(gaps: Iterable[KnowledgeGap], current_step: int, limit: int = 5):
    return [asdict(x) for x in build_agenda(gaps,current_step,limit)]

from __future__ import annotations
from dataclasses import dataclass, field, asdict
from typing import Dict, List, Optional, Tuple, Iterable
import math, json, hashlib
import numpy as np


def _unit(x):
    x=np.asarray(x,dtype=np.float64)
    n=float(np.linalg.norm(x))
    return x/(n if n>1e-12 else 1.0)

def cosine(a,b):
    return float(np.dot(_unit(a),_unit(b)))

@dataclass
class ModalityPrototype:
    mean: List[float]
    count: int=1

@dataclass
class SensoryConcept:
    concept_id: str
    modalities: Dict[str,ModalityPrototype]=field(default_factory=dict)
    bundle_count: int=0
    named_entity: Optional[str]=None
    created_order: int=0
    name_origin: Optional[str]=None
    name_source_ref: Optional[str]=None

class SensoryGrounder:
    """Post-codec structural grounder.

    It does NOT consume pixels/PCM and it never receives evaluation class labels.
    A synchronized multimodal bundle is treated as weak evidence that its members
    share a referent. Persistent concepts are modality-specific prototypes linked
    only by bundle co-occurrence.
    """
    SCHEMA="C4_SENSORY_GROUNDER_V0.1"
    def __init__(self, recognize_threshold=0.80, create_min_modalities=2, ema_cap=64):
        self.recognize_threshold=float(recognize_threshold)
        self.create_min_modalities=int(create_min_modalities)
        self.ema_cap=int(ema_cap)
        self.concepts:Dict[str,SensoryConcept]={}
        self.order=0
        self.audit=[]
        self.naming_requests={}
        # Derived/non-durable vector cache. Same cosine semantics, NumPy execution.
        self._compiled_ready=False
        self._compiled_ids=[]
        self._compiled_row={}
        self._compiled_mod={}
        self._compiled_mask={}

    def _invalidate_compiled(self):
        self._compiled_ready=False;self._compiled_ids=[];self._compiled_row={};self._compiled_mod={};self._compiled_mask={}

    def _rebuild_compiled(self):
        ids=list(self.concepts)
        self._compiled_ids=ids;self._compiled_row={cid:i for i,cid in enumerate(ids)}
        mods={}
        for cid,c in self.concepts.items():
            for m,p in c.modalities.items():mods.setdefault(m,len(p.mean))
        self._compiled_mod={m:np.zeros((len(ids),d),dtype=np.float64) for m,d in mods.items()}
        self._compiled_mask={m:np.zeros(len(ids),dtype=bool) for m in mods}
        for cid,c in self.concepts.items():
            i=self._compiled_row[cid]
            for m,p in c.modalities.items():
                self._compiled_mod[m][i]=_unit(p.mean);self._compiled_mask[m][i]=True
        self._compiled_ready=True

    def _ensure_compiled(self):
        if not self._compiled_ready:self._rebuild_compiled()

    def _cache_set(self,cid,modality,vec):
        if not self._compiled_ready:return
        if cid not in self._compiled_row:
            row=len(self._compiled_ids);self._compiled_ids.append(cid);self._compiled_row[cid]=row
            for m,mat in list(self._compiled_mod.items()):
                self._compiled_mod[m]=np.vstack([mat,np.zeros((1,mat.shape[1]),dtype=np.float64)])
                self._compiled_mask[m]=np.concatenate([self._compiled_mask[m],np.array([False])])
        row=self._compiled_row[cid];v=_unit(vec);m=str(modality).upper()
        if m not in self._compiled_mod:
            n=len(self._compiled_ids);self._compiled_mod[m]=np.zeros((n,len(v)),dtype=np.float64);self._compiled_mask[m]=np.zeros(n,dtype=bool)
        self._compiled_mod[m][row]=v;self._compiled_mask[m][row]=True

    def _score_vector(self,modality,vec):
        self._ensure_compiled();m=str(modality).upper()
        mat=self._compiled_mod.get(m)
        if mat is None:return None,None
        scores=mat @ _unit(vec);mask=self._compiled_mask[m]
        scores=np.where(mask,scores,-np.inf)
        return scores,mask

    def _new_id(self):
        self.order+=1
        return f"sc:{self.order:06d}"

    def _sim(self,c:SensoryConcept, modality:str, vec)->Optional[float]:
        p=c.modalities.get(modality)
        return None if p is None else cosine(p.mean,vec)

    def recognize(self, modality:str, vec, threshold:Optional[float]=None)->Tuple[Optional[str],float]:
        thr=self.recognize_threshold if threshold is None else float(threshold)
        scores,mask=self._score_vector(modality,vec)
        if scores is None or not np.any(mask):return None,-1.0
        i=int(np.argmax(scores));bs=float(scores[i])
        if not np.isfinite(bs) or bs<thr:return None,bs
        return self._compiled_ids[i],bs

    def rank(self,modality:str,vec,k:int=3,min_score:float=0.45):
        scores,mask=self._score_vector(modality,vec)
        if scores is None:return []
        idx=np.flatnonzero(mask & (scores>=float(min_score)))
        if len(idx)==0:return []
        kk=max(1,int(k))
        if len(idx)>kk:
            part=idx[np.argpartition(scores[idx],-kk)[-kk:]]
        else:part=idx
        rows=[(self._compiled_ids[int(i)],float(scores[int(i)])) for i in part]
        rows.sort(key=lambda z:z[1],reverse=True)
        return rows[:kk]

    def _bundle_score(self,c:SensoryConcept,bundle:Dict[str,Iterable[float]])->Tuple[float,int,float]:
        sims=[]
        for m,v in bundle.items():
            s=self._sim(c,m,v)
            if s is not None:sims.append(s)
        if not sims:return -1.0,0,-1.0
        # Mean rewards agreement; minimum blocks one excellent modality from dragging a wrong merge.
        return float(sum(sims)/len(sims)),len(sims),float(min(sims))

    def observe_bundle(self,bundle:Dict[str,Iterable[float]], *, origin="SIM", allow_create=True):
        bundle={str(m).upper():_unit(v) for m,v in bundle.items()}
        self._ensure_compiled();N=len(self._compiled_ids)
        chosen=None;score=-1.0
        if N:
            sums=np.zeros(N,dtype=np.float64);counts=np.zeros(N,dtype=np.int32);mins=np.full(N,np.inf,dtype=np.float64)
            for m,v in bundle.items():
                mat=self._compiled_mod.get(m)
                if mat is None:continue
                mask=self._compiled_mask[m];sc=mat @ v
                sums[mask]+=sc[mask];counts[mask]+=1;mins[mask]=np.minimum(mins[mask],sc[mask])
            valid=counts>0
            if np.any(valid):
                avg=np.full(N,-np.inf,dtype=np.float64);avg[valid]=sums[valid]/counts[valid]
                # Exact tuple order is only relevant for near-identical ties; creation row breaks ties deterministically.
                candidates=np.flatnonzero(valid)
                best=max((float(avg[i]),float(mins[i]),int(counts[i]),self._compiled_ids[int(i)],int(i)) for i in candidates)
                avgv,mnv,nv,cid,i=best
                if avgv>=self.recognize_threshold and mnv>=self.recognize_threshold-0.08:
                    chosen=cid;score=avgv
        created=False
        if chosen is None:
            if not allow_create or len(bundle)<self.create_min_modalities:
                self.audit.append({"type":"UNRESOLVED","modalities":sorted(bundle),"origin":origin})
                return {"concept_id":None,"created":False,"score":score}
            cid=self._new_id();c=SensoryConcept(cid,{},0,None,self.order)
            for m,v in bundle.items():c.modalities[m]=ModalityPrototype(v.tolist(),1)
            c.bundle_count=1;self.concepts[cid]=c
            for m,v in bundle.items():self._cache_set(cid,m,v)
            chosen=cid;created=True;score=1.0
        else:
            c=self.concepts[chosen];c.bundle_count+=1
            for m,v in bundle.items():
                p=c.modalities.get(m)
                if p is None:
                    c.modalities[m]=ModalityPrototype(v.tolist(),1);self._cache_set(chosen,m,v)
                else:
                    # bounded running mean: old concept stays stable without becoming frozen forever
                    k=min(p.count,self.ema_cap)
                    new=_unit((np.asarray(p.mean)*k+v)/(k+1))
                    p.mean=new.tolist();p.count+=1;self._cache_set(chosen,m,new)
        self.audit.append({"type":"CREATE" if created else "UPDATE","concept_id":chosen,"modalities":sorted(bundle),"origin":origin,"score":score})
        return {"concept_id":chosen,"created":created,"score":score}

    def collapse_duplicates(self, merge_threshold=0.91, min_modalities=2):
        """Merge redundant concepts using multimodal prototype equivalence.

        This is deliberately stricter than recognition: collapse requires agreement
        across multiple independent modality prototypes. Named concepts with
        conflicting semantic bindings are never merged. Returns old->kept remap.
        """
        remap={}
        changed=True
        while changed:
            changed=False;ids=list(self.concepts)
            best=None
            for i,a in enumerate(ids):
                ca=self.concepts[a]
                for b in ids[i+1:]:
                    cb=self.concepts[b]
                    if ca.named_entity and cb.named_entity and ca.named_entity!=cb.named_entity:continue
                    common=sorted(set(ca.modalities)&set(cb.modalities))
                    if len(common)<min_modalities:continue
                    sims=[cosine(ca.modalities[m].mean,cb.modalities[m].mean) for m in common]
                    score=sum(sims)/len(sims)
                    if min(sims)>=merge_threshold-0.05 and score>=merge_threshold:
                        cand=(score,min(sims),a,b)
                        if best is None or cand>best:best=cand
            if best is None:break
            _,_,a,b=best;ca=self.concepts[a];cb=self.concepts[b]
            # keep older identity for stability
            keep,drop=(a,b) if ca.created_order<=cb.created_order else (b,a)
            ck,cd=self.concepts[keep],self.concepts[drop]
            for m,pd in cd.modalities.items():
                pk=ck.modalities.get(m)
                if pk is None:ck.modalities[m]=pd
                else:
                    nk=max(1,pk.count);nd=max(1,pd.count)
                    merged=_unit((np.asarray(pk.mean)*nk+np.asarray(pd.mean)*nd)/(nk+nd))
                    pk.mean=merged.tolist();pk.count=nk+nd
            ck.bundle_count+=cd.bundle_count
            if ck.named_entity is None:ck.named_entity=cd.named_entity
            del self.concepts[drop];remap[drop]=keep
            # transitive remap normalization
            for k,v in list(remap.items()):
                if v==drop:remap[k]=keep
            self.audit.append({"type":"COLLAPSE","kept":keep,"dropped":drop,"score":best[0]})
            self._invalidate_compiled();changed=True
        return remap

    def name(self,concept_id:str,entity_id:str,*,origin="CREATOR_PRIOR",source_ref=None):
        c=self.concepts[concept_id];prev=c.named_entity
        c.named_entity=entity_id;c.name_origin=origin;c.name_source_ref=source_ref
        self.audit.append({"type":"RENAME" if prev and prev!=entity_id else "NAME","concept_id":concept_id,"entity_id":entity_id,"previous_entity":prev,"origin":origin,"source_ref":source_ref})
        return c

    def naming_request(self,concept_id:str,min_support=5):
        c=self.concepts.get(concept_id)
        if c is None or c.named_entity is not None or c.bundle_count<int(min_support):return None
        last=int(self.naming_requests.get(concept_id,0))
        n=int(c.bundle_count)
        if last and n<max(last+1,last*2):return None
        self.naming_requests[concept_id]=max(1,n)
        return {"kind":"ASK_NAME","concept_id":concept_id,"support":n,"modalities":sorted(c.modalities),"reason":"STABLE_UNNAMED_CONCEPT"}

    def entity_for(self,modality:str,vec):
        cid,s=self.recognize(modality,vec)
        if cid is None:return None,s,None
        return self.concepts[cid].named_entity,s,cid

    def to_dict(self):
        return {"schema":self.SCHEMA,"recognize_threshold":self.recognize_threshold,"create_min_modalities":self.create_min_modalities,
                "ema_cap":self.ema_cap,"order":self.order,"concepts":{
                    cid:{"concept_id":c.concept_id,"modalities":{m:asdict(p) for m,p in c.modalities.items()},"bundle_count":c.bundle_count,
                         "named_entity":c.named_entity,"created_order":c.created_order,"name_origin":c.name_origin,"name_source_ref":c.name_source_ref} for cid,c in self.concepts.items()},"audit":self.audit,"naming_requests":self.naming_requests}
    @classmethod
    def from_dict(cls,d):
        x=cls(d.get("recognize_threshold",.80),d.get("create_min_modalities",2),d.get("ema_cap",64));x.order=int(d.get("order",0));x.audit=list(d.get("audit",[]))
        for cid,z in d.get("concepts",{}).items():
            c=SensoryConcept(cid,{},int(z.get("bundle_count",0)),z.get("named_entity"),int(z.get("created_order",0)),z.get("name_origin"),z.get("name_source_ref"))
            c.modalities={m:ModalityPrototype(list(p["mean"]),int(p.get("count",1))) for m,p in z.get("modalities",{}).items()}
            x.concepts[cid]=c
        x.naming_requests={str(k):int(v) for k,v in d.get("naming_requests",{}).items()}
        return x

class SyntheticCodecWorld:
    """Evaluation nursery: produces modality-local compact features with nuisance.
    Truth labels are held by the world and never passed to SensoryGrounder.
    """
    def __init__(self,labels,seed=123,dims=None,confusable_pairs=None):
        self.labels=list(labels);self.rng=np.random.default_rng(seed);self.dims=dims or {"VISION":18,"AUDIO":14,"SYMBOL":10}
        self.prototypes={m:{} for m in self.dims}
        for m,d in self.dims.items():
            # approximately orthogonal random class anchors
            raw=self.rng.normal(size=(len(self.labels),d))
            raw=np.array([_unit(x) for x in raw])
            for i,l in enumerate(self.labels):self.prototypes[m][l]=raw[i]
        # Make selected pairs deliberately closer, but still distinguishable.
        for a,b in confusable_pairs or []:
            for m in self.dims:
                pa=self.prototypes[m][a]
                orth=self.rng.normal(size=len(pa));orth=orth-pa*np.dot(orth,pa);orth=_unit(orth)
                self.prototypes[m][b]=_unit(0.80*pa+0.60*orth)

    def encode(self,label,modality,*,rng=None,noise=.10):
        rng=rng or self.rng;m=modality.upper();p=self.prototypes[m][label]
        # nuisance includes isotropic noise plus modality-local gain jitter before renorm
        x=p + rng.normal(0,noise,size=len(p))
        x=x*rng.uniform(.85,1.15,size=len(p))
        return _unit(x)

    def bundle(self,label,modalities,*,rng=None,noise=.10):
        return {m:self.encode(label,m,rng=rng,noise=noise) for m in modalities}

@dataclass
class SequenceChunk:
    chunk_id:str
    constituents:Tuple[str,...]
    support:int=0
    named_entity:Optional[str]=None

class SequenceComposer:
    SCHEMA="C4_SEQUENCE_COMPOSER_V0.1"
    def __init__(self,min_support=3):
        self.min_support=int(min_support);self.chunks:Dict[Tuple[str,...],SequenceChunk]={};self.seq=0
    def observe(self,constituents:Iterable[str]):
        key=tuple(constituents)
        c=self.chunks.get(key)
        if c is None:
            self.seq+=1;c=SequenceChunk(f"chunk:{self.seq:06d}",key,0,None);self.chunks[key]=c
        c.support+=1
        return c.chunk_id if c.support>=self.min_support else None
    def recognize(self,constituents:Iterable[str]):
        c=self.chunks.get(tuple(constituents));return None if c is None or c.support<self.min_support else c.chunk_id
    def decode_lattice(self,lattice,*,min_mean_score=.72,min_margin=.01,max_mean_regret=None):
        """Bounded top-down disambiguation using only already-admitted chunks.
        lattice: list[list[(concept_id, score)]]. Unknown sequences remain unknown.
        max_mean_regret limits how much lexical context may contradict local percepts.
        """
        scored=[]
        maps=[dict(x) for x in lattice]
        local_tops=[max(mp.values()) if mp else -1.0 for mp in maps]
        for c in self.chunks.values():
            if c.support<self.min_support or len(c.constituents)!=len(maps):continue
            vals=[];regrets=[];ok=True
            for cid,mp,top in zip(c.constituents,maps,local_tops):
                if cid not in mp:ok=False;break
                v=mp[cid];vals.append(v);regrets.append(max(0.0,top-v))
            if ok:
                mean_regret=sum(regrets)/len(regrets) if regrets else 0.0
                if max_mean_regret is not None and mean_regret>float(max_mean_regret):continue
                scored.append((sum(vals)/len(vals),c.chunk_id))
        if not scored:return None,0.0,0.0
        scored.sort(reverse=True);best_score,best=scored[0];second=scored[1][0] if len(scored)>1 else -1.0
        margin=best_score-second if second>=0 else best_score
        if best_score<min_mean_score or margin<min_margin:return None,best_score,margin
        return best,best_score,margin

    def name(self,chunk_id,entity_id):
        for c in self.chunks.values():
            if c.chunk_id==chunk_id:c.named_entity=entity_id;return
        raise KeyError(chunk_id)
    def chunk_by_id(self,chunk_id):
        for c in self.chunks.values():
            if c.chunk_id==chunk_id:return c
        return None
    def entity_for_chunk(self,chunk_id):
        c=self.chunk_by_id(chunk_id)
        return None if c is None or c.support<self.min_support else c.named_entity
    def decode_entity(self,lattice,*,min_mean_score=.72,min_margin=.01,max_mean_regret=None):
        chunk_id,score,margin=self.decode_lattice(lattice,min_mean_score=min_mean_score,min_margin=min_margin,max_mean_regret=max_mean_regret)
        return (None,score,margin,None) if chunk_id is None else (self.entity_for_chunk(chunk_id),score,margin,chunk_id)
    def decode_entity_multiview(self,lattices,*,min_confirm=2,min_mean_score=.72,min_margin=.01,max_mean_regret=.01):
        """Evidence-gated sensory identity. One noisy read is only a hypothesis.
        Returns an entity only when independent views agree.
        """
        votes={};rows=[]
        for lattice in lattices:
            eid,score,margin,cid=self.decode_entity(lattice,min_mean_score=min_mean_score,min_margin=min_margin,max_mean_regret=max_mean_regret)
            rows.append((eid,score,margin,cid))
            if eid is not None:votes[eid]=votes.get(eid,0)+1
        if not votes:return None,rows
        ranked=sorted(votes.items(),key=lambda z:z[1],reverse=True)
        winner,count=ranked[0]
        if count<int(min_confirm):return None,rows
        if len(ranked)>1 and ranked[1][1]==count:return None,rows
        return winner,rows
    def to_dict(self):
        return {"schema":self.SCHEMA,"min_support":self.min_support,"seq":self.seq,"chunks":[{"chunk_id":c.chunk_id,"constituents":list(c.constituents),"support":c.support,"named_entity":c.named_entity} for c in self.chunks.values()]}
    @classmethod
    def from_dict(cls,d):
        x=cls(d.get("min_support",3));x.seq=int(d.get("seq",0))
        for z in d.get("chunks",[]):
            c=SequenceChunk(z["chunk_id"],tuple(z["constituents"]),int(z["support"]),z.get("named_entity"));x.chunks[c.constituents]=c
        return x

class TransitionLearner:
    SCHEMA="C4_TRANSITION_LEARNER_V0.1"
    def __init__(self,min_support=4,entropy_threshold=.55):
        self.min_support=int(min_support);self.entropy_threshold=float(entropy_threshold);self.counts={};self.requests={}
    def observe(self,src,dst):
        row=self.counts.setdefault(str(src),{});row[str(dst)]=row.get(str(dst),0)+1
    def stats(self,src):
        row=self.counts.get(str(src),{});n=sum(row.values())
        if n==0:return {"support":0,"entropy":1.0,"confidence":0.0,"prediction":None,"probs":{}}
        probs={k:v/n for k,v in row.items()};pred=max(probs,key=probs.get);conf=probs[pred]
        if len(probs)<=1:ent=0.0
        else:
            h=-sum(p*math.log2(p) for p in probs.values() if p>0);ent=h/math.log2(len(probs))
        return {"support":n,"entropy":ent,"confidence":conf,"prediction":pred,"probs":probs}
    def learning_request(self,src):
        st=self.stats(src);n=st["support"]
        unresolved=n<self.min_support or st["entropy"]>=self.entropy_threshold
        if not unresolved:return None
        last=self.requests.get(str(src),0)
        # Event-driven backoff: ask at first meaningful uncertainty, then only after evidence roughly doubles.
        trigger=(n>=self.min_support and (last==0 or n>=max(last+1,last*2))) or (n==0 and last==0)
        if not trigger:return None
        self.requests[str(src)]=max(1,n)
        return {"kind":"ASK_MORE_EXAMPLES","source":str(src),"support":n,"entropy":st["entropy"],"reason":"UNRESOLVED_PREDICTION"}
    def to_dict(self):return {"schema":self.SCHEMA,"min_support":self.min_support,"entropy_threshold":self.entropy_threshold,"counts":self.counts,"requests":self.requests}
    @classmethod
    def from_dict(cls,d):
        x=cls(d.get("min_support",4),d.get("entropy_threshold",.55));x.counts={str(k):{str(a):int(b) for a,b in v.items()} for k,v in d.get("counts",{}).items()};x.requests={str(k):int(v) for k,v in d.get("requests",{}).items()};return x

class NurseryState:
    SCHEMA="C4_NURSERY_STATE_V0.1"
    def __init__(self,grounder=None,composer=None,predictor=None):
        self.grounder=grounder or SensoryGrounder();self.composer=composer or SequenceComposer();self.predictor=predictor or TransitionLearner()
    def to_dict(self):return {"schema":self.SCHEMA,"grounder":self.grounder.to_dict(),"composer":self.composer.to_dict(),"predictor":self.predictor.to_dict()}
    @classmethod
    def from_dict(cls,d):return cls(SensoryGrounder.from_dict(d["grounder"]),SequenceComposer.from_dict(d["composer"]),TransitionLearner.from_dict(d["predictor"]))

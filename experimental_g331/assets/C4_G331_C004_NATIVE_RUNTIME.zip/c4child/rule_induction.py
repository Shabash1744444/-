from __future__ import annotations
from dataclasses import dataclass, asdict
from itertools import combinations
from typing import Dict, List, Optional, Tuple
import hashlib
from .graph import C4Graph, ACTIVE_STATUSES

Feature = Tuple[str,str,str,str]  # relation, polarity, object_kind, object_value

RULE_MODEL_CLASSES={'MODEL','TEACHER_SYNTHETIC'}
RULE_FORBIDDEN_CLASSES={'SELF_OUTPUT','REPLAY','SIM','DERIVED','PREDICTION'}
RULE_NONMODEL_CLASSES={'HUMAN','CREATOR','CORPUS','OBS','RECEIPT','ORACLE','VALIDATED'}

def _fact_source_class(f)->str:
    origin=str(getattr(f,'origin','')).upper();authority=str(getattr(f,'authority','')).upper()
    if authority in {'EPISTEMIC_CHALLENGE','EPISTEMIC_REVALIDATION'}:return 'VALIDATED'
    if origin in RULE_FORBIDDEN_CLASSES:return origin
    if origin in {'MODEL','TEACHER_SYNTHETIC'}:return 'MODEL'
    if origin in {'CREATOR_PRIOR','CREATOR'}:return 'CREATOR'
    if origin in {'USER_SAID','HUMAN'}:return 'HUMAN'
    if origin in {'EXTERNAL_CORPUS','CORPUS'}:return 'CORPUS'
    if origin in {'OBS','SANDBOX_OBS'}:return 'OBS'
    if origin in {'RECEIPT','SANDBOX_RECEIPT'}:return 'RECEIPT'
    if origin in {'EXACT_MATH_ORACLE','ORACLE'}:return 'ORACLE'
    # Unknown historical provenance is not allowed to become a strong autonomous anchor.
    return 'UNKNOWN'


def _fid(parts)->str:
    raw='|'.join(map(str,parts)).encode('utf-8')
    return 'rule:'+hashlib.blake2s(raw,digest_size=10).hexdigest()

@dataclass
class RuleExample:
    entity:str
    expected:bool
    split:str
    source_group:str
    order:int
    source_class:str='HUMAN'
    source_fact_id:Optional[str]=None
    active:bool=True

@dataclass
class LearnedRule:
    rule_id:str
    target_relation:str
    target_object_kind:str
    target_object_value:str
    target_polarity:str
    antecedent:List[Feature]
    status:str
    train_support:int
    validation_support:int
    validation_negatives:int
    independent_sources:int
    created_order:int
    supersedes:Optional[str]=None
    failure_reason:Optional[str]=None

@dataclass
class RuleStudy:
    study_id:str
    target_relation:str
    target_object_kind:str
    target_object_value:str
    target_polarity:str='POS'
    status:str='OPEN'
    created_order:int=0

@dataclass
class RuleResult:
    truth:str
    rule_id:Optional[str]=None
    derived:bool=False
    antecedent:Optional[List[Feature]]=None

class RuleInductionOrgan:
    """Bounded structural rule induction over already-admitted graph features.

    This organ never mutates world facts when it applies a rule.  It learns only
    rules that survive an explicit train/validation split and source-diversity
    checks.  Counterexamples trigger re-evaluation rather than being averaged away.
    """
    def __init__(self, *, max_order:int=2, min_train_pos:int=3, min_validation_pos:int=2,
                 min_validation_neg:int=1, min_independent_sources:int=2):
        self.max_order=max(1,int(max_order))
        self.min_train_pos=max(1,int(min_train_pos))
        self.min_validation_pos=max(1,int(min_validation_pos))
        self.min_validation_neg=max(0,int(min_validation_neg))
        self.min_independent_sources=max(1,int(min_independent_sources))
        self.examples:Dict[str,List[RuleExample]]={}
        self.rules:Dict[str,LearnedRule]={}
        self.studies:Dict[str,RuleStudy]={}
        self.order=0

    @staticmethod
    def target_key(relation:str,object_kind:str,object_value:str,polarity:str='POS')->str:
        return f'{str(relation).upper()}|{object_kind}|{object_value}|{str(polarity).upper()}'

    def begin_study(self,relation:str,object_value:str,*,object_kind='literal',polarity='POS')->RuleStudy:
        key=self.target_key(relation,object_kind,str(object_value),polarity)
        sid='study:'+hashlib.blake2s(key.encode('utf-8'),digest_size=8).hexdigest()
        st=self.studies.get(sid)
        if st is None:
            self.order+=1
            st=RuleStudy(sid,str(relation).upper(),object_kind,str(object_value),str(polarity).upper(),'OPEN',self.order)
            self.studies[sid]=st
        return st

    def seed_study_from_graph(self,g:C4Graph,study_id:str,*,principal='USER',viewer='USER')->dict:
        """Seed only explicit POS/NEG target facts. UNKNOWN is never used as FALSE."""
        st=self.studies[study_id]; added=0
        target_polarity=st.target_polarity
        # Positive labels for this study are facts whose polarity equals the study conclusion.
        desired_pol=target_polarity
        opposite='NEG' if desired_pol=='POS' else 'POS'
        target=st.target_object_value
        for expected,pol in ((True,desired_pol),(False,opposite)):
            # G270: the facts naming this target, by reverse lookup (not a scan of the whole graph)
            for f in g.reverse_facts(st.target_relation,target,object_kind=st.target_object_kind,viewer=principal,principal=principal,polarity=pol):
                if f.status not in ACTIVE_STATUSES or f.principal!=principal:continue
                if f.relation!=st.target_relation or f.object_kind!=st.target_object_kind or str(f.object_value)!=target or f.polarity!=pol:continue
                # Deterministic 3:2-ish split without inventing labels.
                split='validation' if (int(hashlib.blake2s(f.subject.encode(),digest_size=2).hexdigest(),16)%5)>=3 else 'train'
                group=str(f.source_group or f.source_ref or f'{f.origin}:{f.principal}')
                before=len(self.examples.get(self.target_key(st.target_relation,st.target_object_kind,target,st.target_polarity),[]))
                self.observe(g,f.subject,st.target_relation,target,expected=expected,object_kind=st.target_object_kind,polarity=st.target_polarity,split=split,source_group=group,source_class=_fact_source_class(f),source_fact_id=f.fact_id,principal=principal,viewer=viewer)
                after=len(self.examples.get(self.target_key(st.target_relation,st.target_object_kind,target,st.target_polarity),[]))
                added += max(0,after-before)
        return {'added':added,'status':self.study_status(study_id)}

    def study_status(self,study_id:str)->dict:
        st=self.studies[study_id];key=self.target_key(st.target_relation,st.target_object_kind,st.target_object_value,st.target_polarity)
        rows=[r for r in self.examples.get(key,[]) if getattr(r,'active',True)]
        counts={(sp,ex):sum(1 for r in rows if r.split==sp and r.expected==ex) for sp in ('train','validation') for ex in (True,False)}
        nonmodel=lambda r:r.source_class in RULE_NONMODEL_CLASSES
        sources={r.source_group for r in rows if r.expected and nonmodel(r)}
        nm_train_pos=sum(1 for r in rows if r.split=='train' and r.expected and nonmodel(r))
        nm_val_pos=sum(1 for r in rows if r.split=='validation' and r.expected and nonmodel(r))
        nm_val_neg=sum(1 for r in rows if r.split=='validation' and (not r.expected) and nonmodel(r))
        admitted=[r for r in self.rules.values() if r.status=='ADMITTED' and self._target_matches(r,st.target_relation,st.target_object_kind,st.target_object_value) and r.target_polarity==st.target_polarity]
        need=None
        if counts[('train',True)]<self.min_train_pos:need='TRAIN_POSITIVE'
        elif nm_train_pos<1:need='NONMODEL_TRAIN_POSITIVE'
        elif counts[('train',False)]<1:need='TRAIN_NEGATIVE'
        elif counts[('validation',True)]<self.min_validation_pos:need='VALIDATION_POSITIVE'
        elif nm_val_pos<1:need='NONMODEL_VALIDATION_POSITIVE'
        elif counts[('validation',False)]<self.min_validation_neg:need='VALIDATION_NEGATIVE'
        elif self.min_validation_neg>0 and nm_val_neg<1:need='NONMODEL_VALIDATION_NEGATIVE'
        elif len(sources)<self.min_independent_sources:need='INDEPENDENT_SOURCE'
        elif not admitted:need='DISTINGUISHING_FEATURE'
        if admitted:
            st.status='ADMITTED';need=None
        else: st.status='OPEN'
        return {'study_id':study_id,'status':st.status,'next_need':need,'counts':{f'{a}_{"pos" if b else "neg"}':v for (a,b),v in counts.items()},'independent_positive_sources':len(sources),'nonmodel_train_positive':nm_train_pos,'nonmodel_validation_positive':nm_val_pos,'nonmodel_validation_negative':nm_val_neg,'admitted_rule_ids':[r.rule_id for r in admitted]}

    def add_study_example(self,g:C4Graph,study_id:str,entity:str,*,expected:bool,split:str,source_group:str,source_class='HUMAN',principal='USER',viewer='USER')->dict:
        st=self.studies[study_id]
        r=self.observe(g,entity,st.target_relation,st.target_object_value,expected=expected,object_kind=st.target_object_kind,polarity=st.target_polarity,split=split,source_group=source_group,source_class=source_class,principal=principal,viewer=viewer)
        return {'rule_id':None if r is None else r.rule_id,'status':self.study_status(study_id)}

    def _features(self,g:C4Graph,eid:str,*,principal='USER',viewer='USER',exclude_target=None)->set[Feature]:
        out=set()
        for pol in ('POS','NEG'):
            for f in g.facts_about(eid,viewer=viewer,principal=principal,polarity=pol):
                # Target-independent, durable structural descriptors only.
                if f.status not in ACTIVE_STATUSES:continue
                if f.relation.startswith('EVENT_'):continue
                if exclude_target is not None:
                    tr,ok,ov=exclude_target
                    if f.relation==tr and f.object_kind==ok and str(f.object_value)==str(ov):continue
                out.add((f.relation,f.polarity,f.object_kind,f.object_value))
        return out

    @staticmethod
    def _matches(features:set[Feature], antecedent:List[Feature])->bool:
        return all(tuple(x) in features for x in antecedent)

    def _refresh_example_activity(self,g:C4Graph,key:Optional[str]=None):
        items=self.examples.items() if key is None else [(key,self.examples.get(key,[]))]
        for _,rows in items:
            for ex in rows:
                if ex.source_fact_id is None:
                    ex.active=True
                else:
                    f=g.facts.get(ex.source_fact_id)
                    ex.active=bool(f is not None and f.status in ACTIVE_STATUSES)

    def _rule_supported_now(self,g:C4Graph,r:LearnedRule,*,principal='USER',viewer='USER')->bool:
        key=self.target_key(r.target_relation,r.target_object_kind,r.target_object_value,r.target_polarity)
        self._refresh_example_activity(g,key)
        rows=[x for x in self.examples.get(key,[]) if x.active]
        # Backward-compatible opaque rules from older checkpoints may not retain
        # their original examples. They remain usable but cannot claim tracked
        # dependency invalidation until relearned under the new schema.
        if not rows:
            return True
        train_pos=[x for x in rows if x.split=='train' and x.expected]
        train_neg=[x for x in rows if x.split=='train' and not x.expected]
        val_pos=[x for x in rows if x.split=='validation' and x.expected]
        val_neg=[x for x in rows if x.split=='validation' and not x.expected]
        if len(train_pos)<self.min_train_pos or len(val_pos)<self.min_validation_pos or len(val_neg)<self.min_validation_neg:return False
        if not any(x.source_class in RULE_NONMODEL_CLASSES for x in train_pos):return False
        if not any(x.source_class in RULE_NONMODEL_CLASSES for x in val_pos):return False
        if self.min_validation_neg>0 and not any(x.source_class in RULE_NONMODEL_CLASSES for x in val_neg):return False
        fmap={x.entity:self._features(g,x.entity,principal=principal,viewer=viewer,exclude_target=(r.target_relation,r.target_object_kind,r.target_object_value)) for x in rows}
        if not all(self._matches(fmap[x.entity],r.antecedent) for x in train_pos):return False
        if not all(not self._matches(fmap[x.entity],r.antecedent) for x in train_neg):return False
        if not all(self._matches(fmap[x.entity],r.antecedent) for x in val_pos):return False
        if not all(not self._matches(fmap[x.entity],r.antecedent) for x in val_neg):return False
        srcs={x.source_group for x in rows if x.expected and x.source_class in RULE_NONMODEL_CLASSES and self._matches(fmap[x.entity],r.antecedent)}
        return len(srcs)>=self.min_independent_sources

    def refresh_supports(self,g:C4Graph,*,principal='USER',viewer='USER')->dict:
        self._refresh_example_activity(g)
        suspended=[]
        for r in self.rules.values():
            if r.status=='ADMITTED' and not self._rule_supported_now(g,r,principal=principal,viewer=viewer):
                r.status='SUSPENDED';r.failure_reason='SUPPORT_RETRACTED';suspended.append(r.rule_id)
        return {'suspended':suspended}

    def observe(self,g:C4Graph,entity:str,relation:str,object_value:str,*,expected:bool,
                object_kind='literal',polarity='POS',split='train',source_group='teacher',source_class='HUMAN',source_fact_id=None,
                principal='USER',viewer='USER')->Optional[LearnedRule]:
        if split not in {'train','validation'}:raise ValueError('split must be train or validation')
        eid=entity if entity in g.entities else g.resolve(entity)
        if eid is None:raise KeyError(f'unknown entity: {entity}')
        source_class=str(source_class).upper()
        if source_class in RULE_FORBIDDEN_CLASSES:
            return None
        self.order+=1
        key=self.target_key(relation,object_kind,str(object_value),polarity)
        ex=RuleExample(eid,bool(expected),split,str(source_group),self.order,source_class,None if source_fact_id is None else str(source_fact_id),True)
        rows=self.examples.setdefault(key,[])
        # Exact repeat from same source/split/entity does not multiply evidence.
        if not any(x.entity==ex.entity and x.expected==ex.expected and x.split==ex.split and x.source_group==ex.source_group for x in rows):
            rows.append(ex)
        return self.reassess(g,relation,object_value,object_kind=object_kind,polarity=polarity,principal=principal,viewer=viewer)

    def _candidate_pool(self,g:C4Graph,rows:List[RuleExample],*,target_relation,target_object_kind,target_object_value,principal,viewer):
        pos=[x for x in rows if x.split=='train' and x.expected]
        neg=[x for x in rows if x.split=='train' and not x.expected]
        if len(pos)<self.min_train_pos:return []
        fmap={x.entity:self._features(g,x.entity,principal=principal,viewer=viewer,exclude_target=(str(target_relation).upper(),target_object_kind,str(target_object_value))) for x in rows}
        common=set.intersection(*(fmap[x.entity] for x in pos)) if pos else set()
        candidates=[]
        feats=sorted(common)
        for k in range(1,min(self.max_order,len(feats))+1):
            for combo in combinations(feats,k):
                ant=list(combo)
                # Training candidate must explain all positives and reject every known train negative.
                if all(self._matches(fmap[x.entity],ant) for x in pos) and all(not self._matches(fmap[x.entity],ant) for x in neg):
                    candidates.append((ant,fmap))
        return candidates

    def reassess(self,g:C4Graph,relation:str,object_value:str,*,object_kind='literal',polarity='POS',principal='USER',viewer='USER')->Optional[LearnedRule]:
        key=self.target_key(relation,object_kind,str(object_value),polarity);self._refresh_example_activity(g,key);rows=[x for x in self.examples.get(key,[]) if x.active]
        # Any active rule contradicted by a newly known example is suspended before new search.
        for r in self.rules.values():
            if self.target_key(r.target_relation,r.target_object_kind,r.target_object_value,r.target_polarity)!=key or r.status!='ADMITTED':continue
            for ex in rows:
                if ex.expected:continue
                fs=self._features(g,ex.entity,principal=principal,viewer=viewer,exclude_target=(str(relation).upper(),object_kind,str(object_value)))
                if self._matches(fs,r.antecedent):
                    r.status='SUSPENDED';r.failure_reason='COUNTEREXAMPLE'
                    break
        cands=self._candidate_pool(g,rows,target_relation=relation,target_object_kind=object_kind,target_object_value=object_value,principal=principal,viewer=viewer)
        val_pos=[x for x in rows if x.split=='validation' and x.expected]
        val_neg=[x for x in rows if x.split=='validation' and not x.expected]
        if len(val_pos)<self.min_validation_pos or len(val_neg)<self.min_validation_neg:return None
        # Synthetic/model examples may help propose a separator, but they cannot
        # self-certify a durable generalization.  Require non-model anchors across
        # training, positive validation, and negative validation.
        nm_train_pos=[x for x in rows if x.split=='train' and x.expected and x.source_class in RULE_NONMODEL_CLASSES]
        nm_val_pos=[x for x in val_pos if x.source_class in RULE_NONMODEL_CLASSES]
        nm_val_neg=[x for x in val_neg if x.source_class in RULE_NONMODEL_CLASSES]
        if not nm_train_pos or not nm_val_pos or (self.min_validation_neg>0 and not nm_val_neg):return None
        best=None
        for ant,fmap in cands:
            if not all(self._matches(fmap[x.entity],ant) for x in val_pos):continue
            if not all(not self._matches(fmap[x.entity],ant) for x in val_neg):continue
            matching=[x for x in rows if x.expected and self._matches(fmap[x.entity],ant)]
            srcs={x.source_group for x in matching if x.source_class in RULE_NONMODEL_CLASSES}
            if len(srcs)<self.min_independent_sources:continue
            score=(len(ant), -len(matching), tuple(ant))
            if best is None or score<best[0]:best=(score,ant,srcs)
        if best is None:return None
        _,ant,srcs=best
        train_support=sum(1 for x in rows if x.split=='train' and x.expected)
        rid=_fid([key,repr(ant)])
        existing=self.rules.get(rid)
        if existing is not None:
            existing.status='ADMITTED';existing.failure_reason=None
            existing.train_support=train_support;existing.validation_support=len(val_pos);existing.validation_negatives=len(val_neg);existing.independent_sources=len(srcs)
            return existing
        supersedes=None
        for r in sorted(self.rules.values(),key=lambda z:z.created_order,reverse=True):
            if self.target_key(r.target_relation,r.target_object_kind,r.target_object_value,r.target_polarity)==key and r.status=='SUSPENDED':
                supersedes=r.rule_id;break
        self.order+=1
        r=LearnedRule(rid,str(relation).upper(),object_kind,str(object_value),str(polarity).upper(),list(ant),'ADMITTED',train_support,len(val_pos),len(val_neg),len(srcs),self.order,supersedes,None)
        self.rules[rid]=r
        return r

    def infer(self,g:C4Graph,entity:str,relation:str,object_value:str,*,object_kind='literal',polarity='POS',principal='USER',viewer='USER')->RuleResult:
        eid=entity if entity in g.entities else g.resolve(entity)
        if eid is None:return RuleResult('UNKNOWN')
        # Direct world knowledge dominates a learned generalization.
        direct=g.truth(eid,relation,str(object_value),object_kind=object_kind,viewer=viewer,principal=principal)
        if direct!='UNKNOWN':return RuleResult(direct,derived=False)
        key=self.target_key(relation,object_kind,str(object_value),polarity)
        fs=self._features(g,eid,principal=principal,viewer=viewer,exclude_target=(str(relation).upper(),object_kind,str(object_value)))
        matched=[r for r in self.rules.values() if r.status=='ADMITTED' and self.target_key(r.target_relation,r.target_object_kind,r.target_object_value,r.target_polarity)==key and self._matches(fs,r.antecedent) and self._rule_supported_now(g,r,principal=principal,viewer=viewer)]
        if not matched:return RuleResult('UNKNOWN')
        matched.sort(key=lambda r:(-len(r.antecedent),-r.validation_support,r.created_order))
        r=matched[0]
        truth='TRUE' if r.target_polarity=='POS' else 'FALSE'
        return RuleResult(truth,r.rule_id,True,list(r.antecedent))


    def _target_matches(self,r,relation,object_kind,object_value):
        return (r.target_relation==str(relation).upper() and r.target_object_kind==object_kind and r.target_object_value==str(object_value))

    def _coverage(self,g:C4Graph,r:LearnedRule,*,principal='USER',viewer='USER')->int:
        """How many entities the antecedent covers. G270: the subjects of each antecedent feature are found by reverse
        lookup and intersected — the same count as testing every entity's features, without visiting every entity."""
        ant=[tuple(x) for x in r.antecedent]
        if not ant:return len(g.entities)
        subjects=None
        for rel,pol,ok,ov in ant:
            if str(rel).startswith('EVENT_'):return 0
            if rel==r.target_relation and ok==r.target_object_kind and str(ov)==str(r.target_object_value):return 0
            got={f.subject for f in g.reverse_facts(rel,ov,object_kind=ok,viewer=viewer,principal=principal,polarity=pol)
                 if f.status in ACTIVE_STATUSES and f.object_value==ov}
            subjects=got if subjects is None else (subjects & got)
            if not subjects:return 0
        return len(subjects)

    def infer_truth(self,g:C4Graph,entity:str,relation:str,object_value:str,*,object_kind='literal',principal='USER',viewer='USER')->RuleResult:
        """Evaluate a proposition against admitted rules of either polarity.

        More constrained rules win.  If rule order is equal, the rule whose
        antecedent currently covers fewer graph entities is treated as the more
        specific generalization.  Opposite equally-specific rules yield CONFLICT.
        No result is persisted.
        """
        eid=entity if entity in g.entities else g.resolve(entity)
        if eid is None:return RuleResult('UNKNOWN')
        direct=g.truth(eid,relation,str(object_value),object_kind=object_kind,viewer=viewer,principal=principal)
        if direct!='UNKNOWN':return RuleResult(direct,derived=False)
        fs=self._features(g,eid,principal=principal,viewer=viewer,exclude_target=(str(relation).upper(),object_kind,str(object_value)))
        matched=[r for r in self.rules.values() if r.status=='ADMITTED' and self._target_matches(r,relation,object_kind,object_value) and self._matches(fs,r.antecedent) and self._rule_supported_now(g,r,principal=principal,viewer=viewer)]
        if not matched:return RuleResult('UNKNOWN')
        ranked=[]
        for r in matched:
            ranked.append(((-len(r.antecedent),self._coverage(g,r,principal=principal,viewer=viewer)),r))
        best_key=min(x[0] for x in ranked)
        best=[r for k,r in ranked if k==best_key]
        pols={r.target_polarity for r in best}
        if len(pols)>1:return RuleResult('CONFLICT',derived=True,antecedent=list(best[0].antecedent))
        r=sorted(best,key=lambda z:(-z.validation_support,z.created_order))[0]
        return RuleResult('TRUE' if r.target_polarity=='POS' else 'FALSE',r.rule_id,True,list(r.antecedent))

    def to_dict(self):
        return {'schema':'C4_RULE_INDUCTION_V0.4','config':{'max_order':self.max_order,'min_train_pos':self.min_train_pos,'min_validation_pos':self.min_validation_pos,'min_validation_neg':self.min_validation_neg,'min_independent_sources':self.min_independent_sources},'order':self.order,'examples':{k:[asdict(x) for x in v] for k,v in self.examples.items()},'rules':[asdict(x) for x in self.rules.values()],'studies':[asdict(x) for x in self.studies.values()]}

    @classmethod
    def from_dict(cls,d):
        o=cls(**d.get('config',{}));o.order=int(d.get('order',0));o.examples={}
        for k,v in d.get('examples',{}).items():
            rows=[]
            for x in v:
                x=dict(x);x.setdefault('source_class','HUMAN');x.setdefault('source_fact_id',None);x.setdefault('active',True);rows.append(RuleExample(**x))
            o.examples[k]=rows
        for x in d.get('rules',[]):
            x=dict(x);x['antecedent']=[tuple(a) for a in x.get('antecedent',[])]
            r=LearnedRule(**x);o.rules[r.rule_id]=r
        for x in d.get('studies',[]):
            st=RuleStudy(**x);o.studies[st.study_id]=st
        return o

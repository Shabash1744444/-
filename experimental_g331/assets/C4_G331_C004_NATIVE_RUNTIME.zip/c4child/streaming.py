from __future__ import annotations
from dataclasses import dataclass, asdict, field
from typing import Dict, Optional, Any
import hashlib, re

from .runtime import C4LivingRuntime
from .bootstrap import BootstrapTeacher


def _hid(raw: str, n: int = 8) -> str:
    return hashlib.blake2s(raw.encode('utf-8'), digest_size=n).hexdigest()


@dataclass
class SourceState:
    source_id: str
    source_type: str
    origin: str
    principal: str
    privacy: str
    metadata: Dict[str, Any] = field(default_factory=dict)
    last_offset: int = 0
    tail: str = ''
    ended: bool = False
    chunks: int = 0
    sentences: int = 0
    semantic_events: int = 0
    admitted: int = 0
    dedup: int = 0
    rejected: int = 0
    unknown: int = 0
    last_chunk_offset: int = -1
    last_chunk_len: int = 0
    last_chunk_hash: str = ''
    last_progress_offset: int = 0
    focus_entity_id: Optional[str] = None


class C4StreamingRuntime:
    """Streaming source wrapper around the living runtime.

    Transport chunks are not cognitive boundaries. Text is incrementally split into
    bounded utterance/sentence surfaces; each surface may emit semantic teacher events.
    Durable state includes source offsets + processed span ids so crash/replay is
    idempotent when graph and runtime state are checkpointed atomically.
    """
    SCHEMA = 'C4_STREAM_RUNTIME_V0.1'

    def __init__(self, living: Optional[C4LivingRuntime] = None):
        self.living = living or C4LivingRuntime()
        self.sources: Dict[str, SourceState] = {}
        self._source_seq = 0
        self._scheduled_unknowns = set()

    def begin_source(self, source_type='TEXT', origin='CREATOR_PRIOR', principal='USER',
                     privacy='PRIVATE', metadata=None, source_id=None):
        self._source_seq += 1
        sid = source_id or f"src:{_hid(f'{self._source_seq}|{source_type}|{origin}|{metadata or {}}',10)}"
        if sid in self.sources:
            return sid
        self.sources[sid] = SourceState(
            source_id=sid, source_type=str(source_type), origin=str(origin),
            principal=str(principal), privacy=str(privacy), metadata=dict(metadata or {})
        )
        return sid

    @staticmethod
    def _extract_complete(text: str):
        """Return complete surfaces and trailing incomplete text.

        Newline is always a boundary. ., !, ? are boundaries when followed by
        whitespace/end. This is transport parsing, not semantic tokenization.
        """
        parts = []
        start = 0
        for m in re.finditer(r'(?:[.!?]+(?=\s|$)|\n+)', text):
            end = m.end()
            seg = text[start:end].strip()
            if seg:
                parts.append((start, end, seg))
            start = end
        return parts, text[start:]

    def _schedule_unresolved_definition(self, subject: str, relation: str, obj: str, cause_id: str):
        if relation != 'IS_A':
            return
        g = self.living.dialogue.g
        oid = g.resolve(obj)
        if not oid or oid in self.living.asked or oid in self._scheduled_unknowns:
            return
        defined = g.get_all(oid, 'IS_A', viewer=self.living.dialogue.principal, principal=self.living.dialogue.principal)
        foundational = g.get(oid, 'FOUNDATIONAL', viewer=self.living.dialogue.principal, principal=self.living.dialogue.principal)
        if not defined and not (foundational and foundational.object_value == 'true'):
            self.living.register_gap('DEFINITION',oid,relation='IS_A',reason='UNRESOLVED_DEFINITION',priority=0.65,cause_id=cause_id,schedule=True)
            self._scheduled_unknowns.add(oid)

    @staticmethod
    def _is_subject_pronoun(surface: str):
        return re.sub(r'\s+',' ',str(surface).strip().lower().replace('ё','е')) in {'он','она','оно','они','этот','эта','это'}

    def _semantic_ingest(self, st: SourceState, surface: str, abs_start: int, abs_end: int):
        span_id = f"{st.source_id}:{abs_start}:{abs_end}"
        th = hashlib.sha256(surface.encode('utf-8')).hexdigest()
        intent = self.living.dialogue.lang.parse(surface)
        st.sentences += 1
        if intent.kind not in {'CLAIM', 'REMEMBER_CLAIM', 'CORRECT_CLAIM'}:
            st.unknown += 1
            return

        kind = 'CORRECTION' if intent.kind == 'CORRECT_CLAIM' else 'CLAIM'
        subject_value = intent.subject
        pronoun_subject = bool(intent.subject and self._is_subject_pronoun(intent.subject))
        if pronoun_subject and st.focus_entity_id is not None:
            subject_value = st.focus_entity_id
        event = {
            'schema': 'C4_BOOTSTRAP_EVENT_V0.1',
            'event_id': span_id,
            'origin': st.origin,
            'status': 'ADMITTED',
            'scope': {'principal': st.principal, 'privacy': st.privacy},
            'authority': 'TEACHER' if st.origin in {'CREATOR_PRIOR','EXTERNAL_CORPUS'} else 'USER',
            'confidence': 1.0,
            'source_ref': span_id,
            'source_group': st.source_id,
            'payload': {
                'kind': kind,
                'subject': subject_value,
                'relation': intent.relation,
                'object': intent.object,
            },
        }
        g = self.living.dialogue.g
        audit_before = len(g.audit)
        m = BootstrapTeacher(g, principal=st.principal).ingest([event])
        # High-volume repeated teacher surfaces are evidence counts, not hot audit rows.
        # The cold source itself remains the provenance record.
        if m.dedup and len(g.audit) > audit_before and g.audit[-1].get('type') == 'DEDUP':
            g.audit.pop()
        st.semantic_events += m.events
        st.admitted += m.admitted
        st.dedup += m.dedup
        st.rejected += m.rejected
        # Discourse identity is source-local, not global runtime state. A transport
        # chunk may end anywhere without changing the referent chain.
        if not pronoun_subject:
            sid = subject_value if subject_value in g.entities else g.resolve(str(subject_value))
            if sid and sid not in {self.living.dialogue.user_eid,self.living.dialogue.self_eid}:
                st.focus_entity_id = sid
        resolved_subject = g.label(st.focus_entity_id) if pronoun_subject and st.focus_entity_id else intent.subject
        self._schedule_unresolved_definition(resolved_subject, intent.relation, intent.object, span_id)

    def append_source(self, source_id: str, offset: int, payload: str):
        if source_id not in self.sources:
            raise KeyError(source_id)
        st = self.sources[source_id]
        if st.ended:
            raise ValueError('source already ended')
        payload = str(payload)
        off = int(offset)
        ch = hashlib.sha256(payload.encode('utf-8')).hexdigest()
        # Exact retry of the latest accepted chunk is idempotent without an O(chunks) map.
        if off == st.last_chunk_offset and len(payload.encode('utf-8')) == st.last_chunk_len:
            if ch != st.last_chunk_hash:
                raise ValueError('latest chunk replayed with different content')
            return self.source_status(source_id)
        # Older prefix is already durable/processed. Do not replay it into cognition.
        if off < st.last_offset:
            if off + len(payload.encode('utf-8')) <= st.last_offset:
                return self.source_status(source_id)
            raise ValueError('overlapping replay past durable offset')
        if off != st.last_offset:
            raise ValueError(f'non-contiguous offset: expected {st.last_offset}, got {off}')

        # Tail belongs immediately before this chunk. Keep its absolute start.
        tail_start = st.last_offset - len(st.tail.encode('utf-8'))
        combined = st.tail + payload
        complete, new_tail = self._extract_complete(combined)
        # Character -> UTF-8 byte offset is computed exactly for source provenance.
        for cstart, cend, surface in complete:
            abs_start = tail_start + len(combined[:cstart].encode('utf-8'))
            abs_end = tail_start + len(combined[:cend].encode('utf-8'))
            self._semantic_ingest(st, surface, abs_start, abs_end)

        st.tail = new_tail
        chunk_len = len(payload.encode('utf-8'))
        st.last_offset += chunk_len
        st.last_chunk_offset = off; st.last_chunk_len = chunk_len; st.last_chunk_hash = ch
        st.chunks += 1
        # Coalesce progress events; transport can query source_status at any time.
        if st.last_offset - st.last_progress_offset >= 65536:
            st.last_progress_offset = st.last_offset
            self.living._event('INGEST_PROGRESS', f'Источник обработан до {st.last_offset} байт.',
                               'SOURCE_PROGRESS', 0.1, source_id, False)
        return self.source_status(source_id)

    def end_source(self, source_id: str):
        if source_id not in self.sources:
            raise KeyError(source_id)
        st = self.sources[source_id]
        if st.ended:
            return self.source_status(source_id)
        if st.tail.strip():
            start = st.last_offset - len(st.tail.encode('utf-8'))
            self._semantic_ingest(st, st.tail.strip(), start, st.last_offset)
        st.tail = ''
        st.ended = True
        self.living._event('STATUS', f'Источник {source_id} завершён.', 'SOURCE_ENDED', 0.2, source_id, False)
        return self.source_status(source_id)

    def source_status(self, source_id: str):
        st = self.sources[source_id]
        d = asdict(st)
        d['active_tail_chars'] = len(st.tail)
        return d

    def tick(self, n=1):
        return self.living.tick(n)

    def poll(self, limit=100):
        return self.living.poll(limit)

    def runtime_state(self):
        return {
            'schema': self.SCHEMA,
            'living': self.living.runtime_state(),
            'source_seq': self._source_seq,
            'scheduled_unknowns': sorted(self._scheduled_unknowns),
            'sources': {sid: asdict(st) for sid, st in self.sources.items()},
        }

    def load_runtime_state(self, d):
        if not d:
            return
        if d.get('schema') != self.SCHEMA:
            # backward compatible: an old living runtime state may be passed directly
            self.living.load_runtime_state(d)
            return
        self._source_seq = int(d.get('source_seq', 0))
        self.living.load_runtime_state(d.get('living'))
        self.sources = {sid: SourceState(**raw) for sid, raw in d.get('sources', {}).items()}
        self._scheduled_unknowns = set(d.get('scheduled_unknowns', []))
        if not self._scheduled_unknowns:
            self._scheduled_unknowns = {x[0] for x in self.living.pending_questions}

from __future__ import annotations
from dataclasses import dataclass,asdict
from typing import List,Dict,Any
import random
from .dialogue import C4ChildDialogue

@dataclass
class ProbeResult:
    kind:str
    question:str
    expected:str
    answer:str
    passed:bool
    subject:str=''
    target:str=''

class NurseryExamEngine:
    """Read-only self-assessment over admitted knowledge.

    The graph is the answer key. The engine never turns the child's answers into
    training data; failures are review targets only.
    """
    def __init__(self,dialogue:C4ChildDialogue,seed=23):self.d=dialogue;self.rng=random.Random(seed)

    def _run(self,kind,q,expected,pred,subject='',target=''):
        before=len(self.d.g.facts);ans=self.d.say(q);after=len(self.d.g.facts)
        ok=bool(pred(ans)) and before==after
        return ProbeResult(kind,q,expected,ans,ok,subject,target)

    def direct_is_a(self,limit=100):
        out=[]
        facts=[f for f in self.d.g.facts.values() if f.status in {'ADMITTED','REVISED'} and f.relation=='IS_A' and f.object_kind=='entity']
        self.rng.shuffle(facts)
        for f in facts[:limit]:
            s=self.d.g.label(f.subject);o=self.d.g.object_surface(f)
            if f.polarity=='POS':out.append(self._run('IS_A_TRUE',f'Правда ли, что {s} — {o}?','Да.',lambda a:a=='Да.',s,o))
            else:
                rr=self.d.reasoner.evaluate_is_a(f.subject,f.object_value,principal=self.d.principal,viewer=self.d.principal)
                if rr.value=='FALSE':out.append(self._run('IS_A_FALSE',f'Правда ли, что {s} — {o}?','Нет.',lambda a:a=='Нет.',s,o))
        return out

    def derived_is_a(self,limit=80):
        out=[];entities=list(self.d.g.entities)
        self.rng.shuffle(entities)
        for s in entities:
            # walk each direct parent one level further; only probe genuinely non-direct targets
            direct={f.object_value for f in self.d.g.get_all(s,'IS_A',viewer=self.d.principal,principal=self.d.principal) if f.object_kind=='entity'}
            for p in list(direct):
                for f in self.d.g.get_all(p,'IS_A',viewer=self.d.principal,principal=self.d.principal):
                    if f.object_kind!='entity' or f.object_value in direct or f.object_value==s:continue
                    rr=self.d.reasoner.evaluate_is_a(s,f.object_value,principal=self.d.principal,viewer=self.d.principal)
                    if rr.value=='TRUE' and rr.derived:
                        sl=self.d.g.label(s);ol=self.d.g.label(f.object_value)
                        out.append(self._run('IS_A_DERIVED',f'Правда ли, что {sl} — {ol}?','Да.',lambda a:a=='Да.',sl,ol))
                        if len(out)>=limit:return out
        return out

    def causal(self,limit=80):
        out=[]
        facts=[f for f in self.d.g.facts.values() if f.status in {'ADMITTED','REVISED'} and f.relation=='CAUSES' and f.object_kind=='entity' and f.polarity=='POS']
        self.rng.shuffle(facts)
        for f in facts[:limit]:
            s=self.d.g.label(f.subject);o=self.d.g.object_surface(f)
            out.append(self._run('CAUSE_DIRECT',f'Правда ли, что {s} вызывает {o}?','DIRECT',lambda a:'прямое причинное' in a.lower(),s,o))
        # sample two-edge chains that are not direct
        for f1 in facts:
            mid=f1.object_value
            for f2 in self.d.g.get_all(mid,'CAUSES',viewer=self.d.principal,principal=self.d.principal):
                rr=self.d.reasoner.evaluate_causes(f1.subject,f2.object_value,principal=self.d.principal,viewer=self.d.principal)
                if rr.value!='CHAIN':continue
                s=self.d.g.label(f1.subject);o=self.d.g.label(f2.object_value)
                out.append(self._run('CAUSE_CHAIN',f'Правда ли, что {s} вызывает {o}?','CHAIN',lambda a:'не как прямой факт' in a.lower(),s,o))
                if len(out)>=limit:return out
        return out

    def inherited(self,limit=100):
        out=[];rels=('CAN','PROPERTY','USED_FOR');entities=list(self.d.g.entities);self.rng.shuffle(entities)
        for s in entities:
            for rel in rels:
                vals=self.d.reasoner.inherited_relation(s,rel,principal=self.d.principal,viewer=self.d.principal)
                for x in vals:
                    surface=self.d.g.object_surface(x.fact);sl=self.d.g.label(s)
                    if rel=='CAN':q=f'Что может {sl}?'
                    elif rel=='PROPERTY':q=f'Какие свойства у {sl}?'
                    else:q=f'Для чего используется {sl}?'
                    out.append(self._run('INHERITED_'+rel,q,surface,lambda a,v=surface:v in a,sl,surface))
                    if len(out)>=limit:return out
        return out

    def unknown_is_a(self,limit=60):
        out=[];entities=list(self.d.g.entities)
        attempts=0
        while len(out)<limit and attempts<limit*100:
            attempts+=1;s,o=self.rng.sample(entities,2)
            rr=self.d.reasoner.evaluate_is_a(s,o,principal=self.d.principal,viewer=self.d.principal)
            if rr.value!='UNKNOWN':continue
            sl=self.d.g.label(s);ol=self.d.g.label(o)
            out.append(self._run('IS_A_UNKNOWN',f'Правда ли, что {sl} — {ol}?','Не знаю.',lambda a:a=='Не знаю.',sl,ol))
        return out

    def run(self,limits=None):
        lim=limits or {}
        results=[]
        results+=self.direct_is_a(lim.get('direct',100))
        results+=self.derived_is_a(lim.get('derived',80))
        results+=self.causal(lim.get('causal',80))
        results+=self.inherited(lim.get('inherited',100))
        results+=self.unknown_is_a(lim.get('unknown',60))
        failures=[x for x in results if not x.passed]
        return {'total':len(results),'passed':len(results)-len(failures),'failed':len(failures),'accuracy':(len(results)-len(failures))/len(results) if results else 1.0,
                'by_kind':self._by_kind(results),'failures':[asdict(x) for x in failures],'results':[asdict(x) for x in results]}
    @staticmethod
    def _by_kind(xs):
        out={}
        for x in xs:
            z=out.setdefault(x.kind,{'total':0,'passed':0});z['total']+=1;z['passed']+=int(x.passed)
        for z in out.values():z['accuracy']=z['passed']/z['total']
        return out

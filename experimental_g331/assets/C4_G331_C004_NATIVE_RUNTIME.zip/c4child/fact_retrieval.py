"""Read-only lexical access from the dialogue organ to admitted kernel facts (G267).

Why it exists: most of the organism's knowledge (PROPERTY/MEANS/CAUSES sentences from curricula and corpora)
is attached to topic subjects that a fixed surface grammar can never name. Without a lexical path the organ
answers "не понимаю" while the kernel holds the answer.

Laws it keeps:
- read-only: never creates entities, aliases or facts, never changes statuses;
- only ACTIVE facts visible to the asking principal are candidates (graph._visible);
- similarity only PROPOSES related knowledge; the dialogue frames it as "что я знаю по теме",
  never as an answer to a different question (SIMILARITY != IDENTITY);
- every returned item carries its fact_id, so provenance stays inspectable.
"""
from __future__ import annotations
import math
import re
import sys
from collections import defaultdict
from functools import lru_cache
from typing import Dict, List, Optional, Sequence, Tuple

import json
from .graph import C4Graph, norm

TECHNICAL_RELATIONS = {
    'WORD_FORM', 'GRAM_GENDER', 'LETTER_NAME', 'GROUNDS', 'FOUNDATIONAL', 'QUERY_RELATION', 'PREDICATE_RELATION',
    'PREDICATE_PRESENT_FORM', 'PREDICATE_PAST_FORM', 'EVENT_PREDICATE', 'EVENT_SUBJECT', 'EVENT_OBJECT',
    'EVENT_TENSE', 'EVENT_POLARITY',
}

STOPWORDS = set("""
что как кто где когда почему зачем какой какая какое какие каких каким каков какова чем чего чему чей чья чьё
это этот эта эти этого этой этом тот та те то того той там тут здесь сюда туда
и а но или да нет не ни же ли бы б уж вот ну ведь даже лишь только еще ещё уже очень так также тоже
в во на с со к ко о об обо у от до по за из без для про при над под перед через между около после возле
я ты он она оно мы вы они меня тебя его её ее нас вас их мне тебе ему ей нам вам им мной тобой ими
мой моя моё мое мои твой твоя твоё твое твои свой своя своё свои себя себе собой наш ваш
был была было были быть есть будет будут буду будешь является являются
если то тогда потом сейчас теперь сегодня всегда иногда
все всё весь вся всех всем такое такой такая такие
расскажи расскажите скажи скажите объясни объясните знаешь знаете знаю помнишь
правда разве можно нужно надо просто вообще
""".split())

_ENDINGS = sorted("""
иями ями ами ого его ому ему ыми ими ых их ая яя ое ее ую юю ой ей ий ый ом ем ам ям ах ях ов ев ью ия ие
ии ию ием иях иям ией ье ья ьи ьям ьях ьями ьев ьей
ы и а я о е у ю ь
""".split(), key=len, reverse=True)

_TOKEN = re.compile(r"[0-9a-zа-я]+(?:[-_][0-9a-zа-я]+)*")
_CYR = re.compile(r"[а-я]")


@lru_cache(maxsize=262144)
def stem_full(word: str) -> str:
    """Inflection-stripped form without truncation (used to keep proper names apart)."""
    w = word.lower().replace('ё', 'е')
    if not _CYR.search(w):
        return w
    if len(w) >= 4:
        for e in _ENDINGS:
            if w.endswith(e) and len(w) - len(e) >= 3:
                return w[:-len(e)]
    return w


@lru_cache(maxsize=262144)
def stem(word: str) -> str:
    """Recall-oriented key: inflection stripped, then truncated (нагреть ~ нагревание, воду ~ вода)."""
    w = stem_full(word)
    return w[:5] if _CYR.search(w) else w


def content_tokens(text: str) -> List[str]:
    t = norm(text)
    return [w for w in _TOKEN.findall(t) if w not in STOPWORDS and len(w) >= 2]


def stems(text: str) -> List[str]:
    out, seen = [], set()
    for w in content_tokens(text):
        s = stem(w)
        if s not in seen:
            seen.add(s); out.append(s)
    return out


class AdmittedFactRetriever:
    """Compact incremental index (mobile): interned stem strings, one tuple pair per fact, postings as lists.

    G270: on a disk graph (SQLiteGraph) the same index lives in tables (ret_doc / ret_post / ret_df / ret_lemma),
    built once at import and extended incrementally; nothing is rebuilt at start-up."""

    def __init__(self, graph: C4Graph):
        self.g = graph
        self._sql = getattr(graph, 'store_kind', 'memory') == 'sqlite'
        self._sig = None
        self._post: Dict[str, List[str]] = defaultdict(list)
        self._doc: Dict[str, Tuple[tuple, tuple]] = {}      # fact_id -> (subject stems, object stems)
        self._lemma: Dict[tuple, object] = {}               # label key -> entity id, or a tuple of ids if ambiguous
        self._seen_f: set = set()
        self._seen_e: Dict[str, int] = {}
        self._n = 1
        self._dfc: Dict[str, int] = {}

    def _signature(self):
        return (self.g.order, len(self.g.facts), len(self.g.entities))

    @staticmethod
    def lemma_key(text: str) -> tuple:
        return tuple(sys.intern(stem_full(w)) for w in content_tokens(text))

    def lemma(self, text: str) -> Optional[str]:
        """Inflection-tolerant lookup of an EXISTING concept («о Руслане» -> Руслан, «семью Карамазовых» -> семья
        Карамазовых). Unique match only; never creates anything."""
        self.ensure()
        key = self.lemma_key(text)
        if not key:
            return None
        if self._sql:
            r = self.g.db.execute("SELECT eid, amb FROM ret_lemma WHERE lkey=?", (" ".join(key),)).fetchone()
            return r[0] if (r and not r[1]) else None
        hit = self._lemma.get(key)
        return hit if isinstance(hit, str) else None

    def _full_of(self, fid: str) -> set:
        f = self.g.facts[fid]
        return {stem_full(w) for w in content_tokens(self.g.label(f.subject)) + content_tokens(self.g.object_surface(f))}

    def _index_new(self):
        """Incremental: facts are indexed once whatever their status; visibility/status is checked at query time."""
        if self._sql:
            index_sqlite_new(self.g)
            self._dfc = {}
            self._n = max(1, int(self.g.meta_get('ret_n', 0) or 0))
            return
        intern = sys.intern
        for fid, f in self.g.facts.items():
            if fid in self._seen_f:
                continue
            self._seen_f.add(fid)
            if f.relation in TECHNICAL_RELATIONS or 'sha256=' in str(f.object_value):
                continue
            ss = tuple(intern(x) for x in stems(self.g.label(f.subject)))
            os_ = tuple(intern(x) for x in stems(self.g.object_surface(f)))
            if not ss and not os_:
                continue
            self._doc[fid] = (ss, os_)
            for x in set(ss) | set(os_):
                self._post[x].append(fid)
        for eid, e in self.g.entities.items():
            if e.kind != 'concept' or self._seen_e.get(eid) == len(e.aliases):
                continue
            self._seen_e[eid] = len(e.aliases)
            for a in [e.label] + list(e.aliases):
                k = self.lemma_key(a)
                if not k:
                    continue
                old = self._lemma.get(k)
                if old is None or old == eid:
                    self._lemma[k] = eid
                elif isinstance(old, str):
                    self._lemma[k] = (old, eid)
                elif eid not in old:
                    self._lemma[k] = old + (eid,)
        self._n = max(1, len(self._doc))

    def ensure(self):
        sig = self._signature()
        if self._sig != sig:
            self._index_new()
            self._sig = sig

    # ---- the index, whichever store holds it
    def _df(self, s: str) -> int:
        if not self._sql:
            return len(self._post.get(s, ()))
        v = self._dfc.get(s)
        if v is None:
            r = self.g.db.execute("SELECT df FROM ret_df WHERE stem=?", (s,)).fetchone()
            v = self._dfc[s] = int(r[0]) if r else 0
        return v

    def _postings(self, s: str):
        if not self._sql:
            return self._post.get(s, ())
        return [r[0] for r in self.g.db.execute("SELECT f.fid FROM ret_post p JOIN facts f ON f.frow=p.frow WHERE p.stem=?", (s,))]

    def _rows(self, fids):
        """(fid, subject stems, object stems, fact) for indexed candidates."""
        if not self._sql:
            for fid in fids:
                d = self._doc.get(fid)
                if d is not None:
                    yield fid, d[0], d[1], self.g.facts[fid]
            return
        fids = list(fids)
        for i in range(0, len(fids), 500):
            chunk = fids[i:i + 500]
            for fid, subj, obj in self.g.db.execute(
                    "SELECT f.fid, d.subj, d.obj FROM facts f JOIN ret_doc d ON d.frow=f.frow WHERE f.fid IN ("
                    + ",".join("?" * len(chunk)) + ")", chunk):
                yield fid, tuple(subj.split()), tuple(obj.split()), self.g.facts[fid]

    def candidates(self, query_stems: Sequence[str]) -> set:
        """Fact ids sharing at least one key with the query (for callers that filter by relation themselves)."""
        self.ensure()
        out = set()
        for s in query_stems:
            out.update(self._postings(s))
        return out

    def candidates_all(self, query_stems: Sequence[str]) -> set:
        """Fact ids whose text contains EVERY key of the query (exact-phrase callers: «кто живёт в норе?»)."""
        self.ensure()
        keys = sorted(dict.fromkeys(query_stems), key=self._df)
        if not keys:
            return set()
        out = set(self._postings(keys[0]))
        for s in keys[1:]:
            if not out:
                break
            out &= set(self._postings(s))
        return out

    def idf(self, s: str) -> float:
        return math.log(1.0 + self._n / (1.0 + self._df(s)))

    def search(self, query_stems: Sequence[str], *, viewer: str, principal: str, limit: int = 3,
               min_coverage: float = 0.6, exclude: Optional[set] = None,
               anchor_stems: Sequence[str] = (), strict: Optional[Dict[str, str]] = None,
               no_subject_bonus: Sequence[str] = ()) -> List[Tuple[float, str]]:
        """Rank visible admitted facts by idf-weighted coverage of the query stems.

        Only facts of the asking principal's namespace are candidates (same scoping as graph.get_all).
        anchor_stems (e.g. the focused entity) are added with half weight and do not count towards coverage.
        strict maps a key to the full inflection-stripped form it must match (proper names: Александра != Алексей).
        no_subject_bonus: query keys that are references (e.g. «ты» -> C4), not the topic of the question.
        A fact must match at least one RARE query key to be spoken about, so candidates are drawn from the postings
        of rare keys only (G270: the same result without touching the long postings of frequent words).
        """
        strict = strict or {}
        self.ensure()
        q = [s for s in dict.fromkeys(query_stems) if self._df(s)]
        unknown = [s for s in dict.fromkeys(query_stems) if not self._df(s)]
        if not q:
            return []
        w = {s: self.idf(s) for s in q}
        total = sum(w.values()) + sum(self.idf(s) for s in unknown) * 0.5   # unknown words lower the coverage
        anchors = [s for s in anchor_stems if self._df(s) and s not in w]
        rare_df = max(3, int(0.03 * self._n))
        rare = {s for s in q if self._df(s) <= rare_df}
        cands = set()
        for s in rare:
            cands.update(self._postings(s))
        scored = []
        for fid, ss, os_, f in self._rows(cands):
            if exclude and fid in exclude:
                continue
            if f.principal != principal or not self.g._visible(f, viewer, principal):
                continue
            matched = [s for s in q if s in ss or s in os_]
            if strict and any(s in strict for s in matched):
                full = self._full_of(fid)
                matched = [s for s in matched if s not in strict or strict[s] in full]
            if not matched:
                continue
            if not any(s in rare for s in matched):
                continue        # only frequent words matched: not specific enough to speak about
            cov = sum(w[s] for s in matched) / total
            if cov < min_coverage:
                continue
            bonus = sum(0.5 * w[s] for s in matched if s in ss and s not in no_subject_bonus) / total
            bonus += sum(0.25 * self.idf(a) for a in anchors if a in ss or a in os_) / total
            precision = len(matched) / max(1, len(set(ss) | set(os_)))
            scored.append((cov + bonus + 0.15 * precision, fid, f.order))
        scored.sort(key=lambda x: (-x[0], x[2]))
        return [(sc, fid) for sc, fid, _ in scored[:limit]]


# ---------------------------------------------------------------- G270: the index of a disk graph
def _doc_stems(label_s, relation, object_kind, object_value, label_o):
    if relation in TECHNICAL_RELATIONS or 'sha256=' in str(object_value):
        return None
    ss = stems(label_s)
    os_ = stems(label_o if object_kind == 'entity' else object_value)
    if not ss and not os_:
        return None
    return ss, os_


def _index_fact_rows(db, rows):
    docs, posts = [], []
    for frow, rel, ok, ov, ls, lo in rows:
        d = _doc_stems(ls, rel, ok, ov, lo)
        if d is None:
            continue
        ss, os_ = d
        docs.append((frow, " ".join(ss), " ".join(os_)))
        for x in set(ss) | set(os_):
            posts.append((x, frow))
    db.executemany("INSERT OR IGNORE INTO ret_doc VALUES(?,?,?)", docs)
    db.executemany("INSERT OR IGNORE INTO ret_post VALUES(?,?)", posts)
    return docs, posts


_FACT_TEXT_SQL = ("SELECT f.frow, f.relation, f.object_kind, f.object_value, COALESCE(es.label, f.subject), "
                  "COALESCE(eo.label, f.object_value) FROM facts f LEFT JOIN entities es ON es.eid=f.subject "
                  "LEFT JOIN entities eo ON f.object_kind='entity' AND eo.eid=f.object_value ")


def build_sqlite_index(g, *, batch=20000, progress=None):
    """Full build of the retrieval index of a disk graph (done once, at import)."""
    db = g.db
    for t in ('ret_doc', 'ret_post', 'ret_df', 'ret_lemma'):
        db.execute(f"DELETE FROM {t}")
    last = 0
    buf = []
    top = db.execute("SELECT COALESCE(MAX(frow),1) FROM facts").fetchone()[0]
    for row in _iter_rows(db):
        last = row[0]
        buf.append(row)
        if len(buf) >= batch:
            _index_fact_rows(db, buf)
            buf = []
            if progress:
                progress(0.8 * last / top)
    _index_fact_rows(db, buf)
    db.execute("INSERT INTO ret_df SELECT stem, COUNT(*) FROM ret_post GROUP BY stem")
    db.execute("CREATE TEMP TABLE IF NOT EXISTS _lk(lkey TEXT, eid TEXT)")
    db.execute("DELETE FROM _lk")
    rows = []
    after = 0
    while True:                     # chunked, so the import keeps a bounded amount of rows in memory
        chunk = db.execute("SELECT rid, eid, label, aliases FROM entities WHERE kind='concept' AND rid>? ORDER BY rid LIMIT ?",
                           (after, batch)).fetchall()
        if not chunk:
            break
        after = chunk[-1][0]
        for _, eid, label, aliases in chunk:
            for a in dict.fromkeys([label] + json.loads(aliases)):
                k = AdmittedFactRetriever.lemma_key(a)
                if k:
                    rows.append((" ".join(k), eid))
        db.executemany("INSERT INTO _lk VALUES(?,?)", rows)
        rows = []
    db.execute("INSERT INTO ret_lemma SELECT lkey, MIN(eid), COUNT(DISTINCT eid)>1 FROM _lk GROUP BY lkey")
    db.execute("DROP TABLE _lk")
    g.meta_put('ret_fact_rowid', last)
    g.meta_put('ret_n', db.execute("SELECT COUNT(*) FROM ret_doc").fetchone()[0])
    g._dirty_lemma = set()
    db.commit()


def _iter_rows(db, after=0, chunk=20000):
    """Stream facts with their texts in rowid order without holding a cursor across writes."""
    while True:
        rows = db.execute(_FACT_TEXT_SQL + "WHERE f.frow>? ORDER BY f.frow LIMIT ?", (after, chunk)).fetchall()
        if not rows:
            return
        for r in rows:
            yield r
        after = rows[-1][0]


def index_sqlite_new(g):
    """Incremental update of a disk graph's retrieval index: facts beyond the high-water mark, changed concepts."""
    db = g.db
    last = int(g.meta_get('ret_fact_rowid', 0) or 0)
    rows = list(_iter_rows(db, last))
    if rows:
        docs, posts = _index_fact_rows(db, rows)
        for x, _ in posts:
            db.execute("INSERT INTO ret_df VALUES(?,1) ON CONFLICT(stem) DO UPDATE SET df=df+1", (x,))
        g.meta_put('ret_fact_rowid', rows[-1][0])
        g.meta_put('ret_n', int(g.meta_get('ret_n', 0) or 0) + len(docs))
    dirty = getattr(g, '_dirty_lemma', set())
    for eid in list(dirty):
        e = g.entities.get(eid)
        if e is None or e.kind != 'concept':
            continue
        for a in dict.fromkeys([e.label] + list(e.aliases)):
            k = AdmittedFactRetriever.lemma_key(a)
            if not k:
                continue
            key = " ".join(k)
            r = db.execute("SELECT eid, amb FROM ret_lemma WHERE lkey=?", (key,)).fetchone()
            if r is None:
                db.execute("INSERT INTO ret_lemma VALUES(?,?,0)", (key, eid))
            elif r[0] != eid and not r[1]:
                db.execute("UPDATE ret_lemma SET amb=1 WHERE lkey=?", (key,))
    dirty.clear()

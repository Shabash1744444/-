from __future__ import annotations
from dataclasses import dataclass, asdict
from collections import Counter
import re
from .bootstrap import BootstrapTeacher
from .graph import norm

_SAFE_KINDS = {'CLAIM','REMEMBER_CLAIM'}
_SAFE_RELATIONS = {'IS_A','PROPERTY','USED_FOR','CAN','HAS','LIKES','MEANS','ROLE','CAUSES'}

@dataclass
class GuidedReadResult:
    surfaces: int
    parsed_surfaces: int
    skipped_surfaces: int
    emitted_events: int
    admitted: int
    dedup: int
    rejected: int
    compound_classes: list[str]
    gaps_touched: int
    skipped: list[str]

class GuidedReaderRU:
    """Conservative Russian guided-reading bridge.

    It only admits structures already recognized by C4's existing deterministic
    language organs. Unsupported prose stays unsupported; it is never guessed into
    graph truth. A corpus-level first pass protects repeated adjective+noun class
    phrases (e.g. 'навигационный прибор') from being flattened into a noun plus a
    property merely because the class was previously unknown.
    """
    _COPULA = re.compile(r"^(.+?)\s+(?:—|-)\s+(?:это\s+)?(.+)$", re.IGNORECASE)
    _REL = re.compile(r"\s*,?\s*\b(?:который|которая|которое|которые|которого|которой|которому|которым|которых|где)\b\s+", re.IGNORECASE)
    _WORD = re.compile(r"[А-Яа-яЁё][А-Яа-яЁё-]{2,}")
    _STOP = {
        'для','или','при','без','над','под','между','через','после','перед','около','внутри','снаружи',
        'это','этого','этой','этих','как','что','чтобы','который','которая','которое','которые','где',
        'его','ее','её','их','свой','своя','свои','также','обычно','часто','может','могут','нужен','нужна','нужно',
        'используется','используют','использовать','служит','служат','помогает','помогают','позволяет','позволяют'
    }

    def __init__(self, runtime):
        self.rt = runtime
        self.d = runtime.dialogue

    @staticmethod
    def split(text: str) -> list[str]:
        out=[]; start=0; text=str(text)
        for m in re.finditer(r'(?:[.!?]+(?=\s|$)|\n+)', text):
            seg=text[start:m.end()].strip(); start=m.end()
            if seg: out.append(seg)
        tail=text[start:].strip()
        if tail: out.append(tail)
        return out

    def _copula(self, surface: str):
        raw=surface.strip().rstrip('.! ')
        m=self._COPULA.match(raw)
        if not m: return None
        subj=m.group(1).strip(); body=m.group(2).strip()
        if not subj or not body: return None
        core=self._REL.split(body,maxsplit=1)[0].strip(' ,')
        return subj,body,core

    def _compound_classes(self, surfaces: list[str]) -> set[str]:
        rhs=[]; subjects=set()
        for s in surfaces:
            c=self._copula(s)
            if not c: continue
            subj,_,core=c; subjects.add(norm(subj)); toks=core.split()
            if 2 <= len(toks) <= 4 and self.d._is_adj(toks[0]): rhs.append(norm(core))
        counts=Counter(rhs)
        # Repetition or an explicit definition of the phrase is evidence that the
        # phrase is being used as a class label in this text. This is discourse
        # structure, not a world-truth guess; the sentence itself remains evidence.
        return {x for x,n in counts.items() if n>=2 or x in subjects}

    def _compound_intents(self, surface: str, compounds: set[str]):
        c=self._copula(surface)
        if not c: return None
        subj,body,core=c
        if norm(core) not in compounds: return None
        from .language_ru import Intent
        out=[Intent('CLAIM',subject=subj,relation='IS_A',object=core,raw=surface,polarity='POS')]
        parts=self._REL.split(body,maxsplit=1)
        if len(parts)>1:
            for vp in self.d._split_vps(parts[1].strip(' ,')):
                out.append(self.d._vp_intent(subj,vp,'CLAIM',surface))
        return out

    def _intents(self, surface: str, compounds:set[str]):
        # External reading is not an answer to the child's open chat question.
        # Parse the sentence with teaching-dialogue state temporarily isolated,
        # then restore that state byte-for-byte.
        pa=getattr(self.d,'pending_ask',None); pc=getattr(self.d,'pending_confirm',None); tr=getattr(self.d,'teach_root',None)
        try:
            self.d.pending_ask=None; self.d.pending_confirm=None; self.d.teach_root=None
            its=self._compound_intents(surface,compounds)
            if its: return its
            its=self.d._definition_route(surface)
            if its: return its
            one=self.d.semantic_intent(surface)
            if one.kind in _SAFE_KINDS and one.relation in _SAFE_RELATIONS:
                # Causal prose is admitted only when both endpoint concepts already
                # exist.  Guided reading may connect known concepts, but it must not
                # mint new world entities merely because a causal-looking sentence
                # was syntactically recognized. Unknown endpoints stay unsupported
                # until lexical/definition teaching establishes them explicitly.
                if one.relation=='CAUSES':
                    sid=self.d._rid(one.subject) or self.d.morphology.resolve(one.subject)
                    oid=self.d._rid(one.object) or self.d.morphology.resolve(one.object)
                    if not sid or not oid:
                        return None
                return [one]
            return None
        finally:
            self.d.pending_ask=pa; self.d.pending_confirm=pc; self.d.teach_root=tr

    def _unknown_lexical_terms(self, intent):
        # G281: discover unknown content forms only inside already-supported
        # predicate/object structures.  This creates learning gaps, never world facts
        # and never guesses a lemma.  The teacher must supply the dictionary form.
        if intent.relation not in {'USED_FOR','HAS','LIKES','MEANS','ROLE'}:
            return []
        text=str(intent.object or '')
        out=[]
        for raw in self._WORD.findall(text):
            w=norm(raw)
            if len(w)<4 or w in self._STOP: continue
            if self.d._rid(w) or self.d.morphology.resolve(w): continue
            if w not in out: out.append(w)
        return out

    def _event(self, idx:int, intent, source_ref:str, source_group:str):
        payload={'kind':'RELATION','subject':intent.subject,'relation':intent.relation,'object':intent.object,
                 'polarity':intent.polarity}
        # relation schema decides object kind unless IS_A explicitly needs entity.
        if intent.relation in {'IS_A','CAUSES'}: payload['object_kind']='entity'
        return {'schema':'C4_BOOTSTRAP_EVENT_V0.1','event_id':f'{source_ref}:{idx}',
                'origin':'EXTERNAL_CORPUS','scope':{'principal':self.d.principal,'privacy':'PUBLIC'},
                'authority':'TEACHER','confidence':1.0,'source_ref':f'{source_ref}:{idx}',
                'source_group':source_group,'payload':payload}

    def read(self, text:str, *, source_ref='guided', source_group=None, priority=0.72):
        surfaces=self.split(text); compounds=self._compound_classes(surfaces)
        events=[]; skipped=[]; class_members=[]; lexical_terms=[]; idx=0

        def collect(surface, intents):
            nonlocal idx
            for it in intents:
                idx+=1; events.append(self._event(idx,it,source_ref,source_group or source_ref))
                if it.relation=='IS_A': class_members.append((it.subject,it.object,surface))
                for term in self._unknown_lexical_terms(it):
                    lexical_terms.append((term,it.subject,it.relation,surface))

        # Pass 1: admit everything that is already safely resolvable.
        first_events_start=0
        for surface in surfaces:
            intents=self._intents(surface,compounds)
            if not intents:
                skipped.append(surface); continue
            collect(surface,intents)
        teacher=BootstrapTeacher(self.d.g,principal=self.d.principal)
        m1=teacher.ingest(events[first_events_start:])

        # G289: one deterministic dependency retry inside the SAME chunk.
        # Definitions/classes admitted in pass 1 may make previously unsupported
        # relation sentences (notably CAUSES with newly-defined endpoints) safe.
        # This is not guessing: the exact same parser is re-run after explicit
        # earlier evidence from the chunk has been admitted. Unsupported text still
        # remains skipped. One retry is intentionally bounded.
        retry=list(skipped); skipped=[]; before_retry=len(events)
        for surface in retry:
            intents=self._intents(surface,compounds)
            if not intents:
                skipped.append(surface); continue
            collect(surface,intents)
        m2=teacher.ingest(events[before_retry:]) if len(events)>before_retry else None

        admitted=m1.admitted+(m2.admitted if m2 else 0)
        dedup=m1.dedup+(m2.dedup if m2 else 0)
        rejected=m1.rejected+(m2.rejected if m2 else 0)
        gaps_before=len(self.rt.gaps.gaps)
        # After admission, repeated members of an undefined semantic class all add
        # independent cause_ids to the same gap; ActiveGaps can therefore prefer it.
        for subj,obj,surface in class_members:
            oid=self.d.g.resolve(obj)
            sid=self.d.g.resolve(subj)
            if not oid or not sid: continue
            if self.rt._semantic_definition_known(oid): continue
            self.rt.register_gap('DEFINITION',oid,relation='IS_A',reason='GUIDED_READING',priority=priority,
                                 cause_id=f'{source_ref}:{sid}',schedule=False)
        for term,subj,rel,surface in lexical_terms:
            # Surface IDs deliberately remain unresolved and do not create entities.
            self.rt.register_gap('LEXICAL_TERM','surface:'+term,relation='LEXEME',reason='GUIDED_READING_TERM',
                                 priority=max(0.55,priority+0.18),cause_id=f'{source_ref}:{norm(subj)}:{rel}',schedule=False)
        self.rt.refresh_gaps()
        self.rt._autosave_tick(bool(admitted))
        return GuidedReadResult(
            surfaces=len(surfaces), parsed_surfaces=len(surfaces)-len(skipped), skipped_surfaces=len(skipped),
            emitted_events=len(events), admitted=admitted, dedup=dedup, rejected=rejected,
            compound_classes=sorted(compounds), gaps_touched=max(0,len(self.rt.gaps.gaps)-gaps_before), skipped=skipped)

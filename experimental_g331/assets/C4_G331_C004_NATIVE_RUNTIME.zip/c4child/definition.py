from __future__ import annotations
from dataclasses import dataclass
from typing import List, Dict, Any
from .graph import C4Graph
from .reasoner import StructuralReasoner

@dataclass
class DefinitionView:
    entity_id: str
    label: str
    direct_types: List[str]
    derived_types: List[str]
    properties: List[Dict[str,str]]
    fact_ids: List[str]

class DefinitionComposer:
    """Build a bounded definition from admitted structure only.

    It is deliberately non-generative: no absent attribute is completed from priors,
    no derived statement is persisted, and only whitelisted semantic relations are
    exposed in the child-language definition surface.
    """
    DETAIL_RELATIONS=("HAS_PART","USED_FOR","CAN","PROPERTY","COLOR")
    def __init__(self,graph:C4Graph,max_derived_types:int=3):
        self.g=graph; self.reasoner=StructuralReasoner(graph); self.max_derived_types=max(0,int(max_derived_types))

    def compose(self,eid:str,*,principal='USER',viewer='USER')->DefinitionView:
        direct=[]; fact_ids=[]
        for f in self.g.get_all(eid,'IS_A',viewer=viewer,principal=principal,polarity='POS'):
            if f.object_kind=='entity':
                direct.append(self.g.label(f.object_value)); fact_ids.append(f.fact_id)
        props=[]
        for rel in self.DETAIL_RELATIONS:
            for f in self.g.get_all(eid,rel,viewer=viewer,principal=principal,polarity='POS'):
                props.append({'relation':rel,'value':self.g.object_surface(f),'fact_id':f.fact_id})
                fact_ids.append(f.fact_id)
        # Derived supertypes are optional context, never durable facts.
        derived=[]
        seen=set(direct)
        frontier=[f.object_value for f in self.g.get_all(eid,'IS_A',viewer=viewer,principal=principal,polarity='POS') if f.object_kind=='entity']
        visited={eid}; depth=0
        while frontier and len(derived)<self.max_derived_types and depth<4:
            nxt=[]; depth+=1
            for cur in frontier:
                if cur in visited: continue
                visited.add(cur)
                for f in self.g.get_all(cur,'IS_A',viewer=viewer,principal=principal,polarity='POS'):
                    if f.object_kind!='entity': continue
                    lab=self.g.label(f.object_value)
                    if lab not in seen:
                        seen.add(lab); derived.append(lab)
                        if len(derived)>=self.max_derived_types: break
                    nxt.append(f.object_value)
                if len(derived)>=self.max_derived_types: break
            frontier=nxt
        return DefinitionView(eid,self.g.label(eid),direct,derived,props,fact_ids)

    def render_ru(self,eid:str,*,principal='USER',viewer='USER')->str:
        d=self.compose(eid,principal=principal,viewer=viewer)
        if not d.direct_types and not d.properties:
            return "Не знаю. Можешь меня этому научить."
        chunks=[]
        if d.direct_types:
            chunks.append(f"{d.label} — " + ", ".join(d.direct_types) + ".")
        rel_words={'HAS_PART':'Содержит/имеет части','USED_FOR':'Используется для','CAN':'Может','PROPERTY':'Свойства','COLOR':'Цвет'}
        grouped={}
        for p in d.properties: grouped.setdefault(p['relation'],[]).append(p['value'])
        for rel in self.DETAIL_RELATIONS:
            vals=grouped.get(rel)
            if vals: chunks.append(f"{rel_words[rel]}: " + ", ".join(vals) + ".")
        if d.derived_types:
            chunks.append("Из известных связей также следует: " + ", ".join(d.derived_types) + ".")
        return " ".join(chunks)

from __future__ import annotations
from .graph import fast_asdict
from dataclasses import dataclass,asdict
from typing import Dict,Optional
import hashlib

OPEN='OPEN';SUCCESS='SUCCESS'

@dataclass
class LearningSession:
    session_id:str
    gap_id:str
    created_step:int
    updated_step:int
    status:str=OPEN
    last_outcome:str='OPEN'   # OPEN|NO_EFFECT|PARTIAL|SUCCESS
    lessons:int=0
    admitted:int=0
    dedup:int=0
    rejected:int=0

class LearningSessionRegistry:
    SCHEMA='C4_LEARNING_SESSIONS_V0.1'
    def __init__(self):self.sessions:Dict[str,LearningSession]={};self._seq=0
    def begin(self,gap_id:str,step:int):
        self._seq+=1
        raw=f'{gap_id}|{step}|{self._seq}'.encode('utf-8')
        sid='learn:'+hashlib.blake2s(raw,digest_size=8).hexdigest()
        s=LearningSession(sid,str(gap_id),int(step),int(step));self.sessions[sid]=s;return s
    def note_lesson(self,session_id,*,step,admitted=0,dedup=0,rejected=0):
        s=self.sessions[session_id];s.updated_step=int(step);s.lessons+=1
        s.admitted+=int(admitted);s.dedup+=int(dedup);s.rejected+=int(rejected)
        if s.status!=SUCCESS:s.last_outcome='PARTIAL' if admitted else 'NO_EFFECT'
        return s
    def evaluate(self,session_id,*,step,resolved:bool):
        s=self.sessions[session_id];s.updated_step=int(step)
        if resolved:s.status=SUCCESS;s.last_outcome=SUCCESS
        return s
    def to_dict(self):return {'schema':self.SCHEMA,'seq':self._seq,'sessions':[fast_asdict(x) for x in self.sessions.values()]}
    @classmethod
    def from_dict(cls,d):
        x=cls()
        if not d:return x
        x._seq=int(d.get('seq',0))
        for raw in d.get('sessions',[]):
            s=LearningSession(**raw);x.sessions[s.session_id]=s
        return x

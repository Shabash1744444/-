from __future__ import annotations
from dataclasses import dataclass,asdict
from typing import Dict

_ALLOWED={'USER_TEACHING','SIMULATION_ALIGNMENT','ALIGNED_CORPUS'}

@dataclass
class FormLink:
    sound_concept:str
    glyph_concept:str
    support:int=0
    provenance_counts:dict=None
    def __post_init__(self):
        if self.provenance_counts is None:self.provenance_counts={}

class SoundSymbolBridge:
    """Many-to-many learned alignment between acoustic-form and glyph-form concepts.

    Association is not identity. It never merges sensory concepts and never creates
    graph facts by itself. Ambiguous grapheme/phoneme mappings are allowed.
    """
    SCHEMA='C4_SOUND_SYMBOL_BRIDGE_V0.1'
    def __init__(self,min_support=3):self.min_support=int(min_support);self.links:Dict[tuple,FormLink]={}
    def observe(self,sound_concept,glyph_concept,*,provenance='USER_TEACHING'):
        if provenance not in _ALLOWED:raise ValueError('unsupported alignment provenance')
        key=(str(sound_concept),str(glyph_concept));row=self.links.get(key)
        if row is None:row=FormLink(*key);self.links[key]=row
        row.support+=1;row.provenance_counts[provenance]=row.provenance_counts.get(provenance,0)+1
        return row
    def glyphs_for(self,sound_concept,min_support=None):
        n=self.min_support if min_support is None else int(min_support)
        out=[(g,r.support) for (s,g),r in self.links.items() if s==str(sound_concept) and r.support>=n]
        return sorted(out,key=lambda z:(-z[1],z[0]))
    def sounds_for(self,glyph_concept,min_support=None):
        n=self.min_support if min_support is None else int(min_support)
        out=[(s,r.support) for (s,g),r in self.links.items() if g==str(glyph_concept) and r.support>=n]
        return sorted(out,key=lambda z:(-z[1],z[0]))
    def to_dict(self):return {'schema':self.SCHEMA,'min_support':self.min_support,'links':[asdict(r) for r in self.links.values()]}
    @classmethod
    def from_dict(cls,d):
        x=cls((d or {}).get('min_support',3))
        for z in (d or {}).get('links',[]):
            r=FormLink(z['sound_concept'],z['glyph_concept'],int(z.get('support',0)),dict(z.get('provenance_counts',{})));x.links[(r.sound_concept,r.glyph_concept)]=r
        return x

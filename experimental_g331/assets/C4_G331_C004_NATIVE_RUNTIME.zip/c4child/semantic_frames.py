from __future__ import annotations
from dataclasses import dataclass,asdict
from typing import Optional,Dict,List
from .graph import C4Graph,rel_norm

@dataclass
class TypeGuard:
    relation:str
    object_entity:str

@dataclass
class BinaryFrame:
    frame_id:str
    output_relation:str
    subject_pos:int
    object_pos:int
    left_guard:Optional[TypeGuard]=None
    right_guard:Optional[TypeGuard]=None
    origin:str='CREATOR_PRIOR'

class SemanticFrameBank:
    SCHEMA='C4_SEMANTIC_FRAME_BANK_V0.1'
    def __init__(self): self.frames:Dict[str,BinaryFrame]={}
    def admit(self,frame:BinaryFrame):
        if frame.subject_pos not in (0,1) or frame.object_pos not in (0,1) or frame.subject_pos==frame.object_pos:raise ValueError('bad positions')
        self.frames[frame.frame_id]=frame;return frame
    def _guard(self,g:C4Graph,eid:str,guard:Optional[TypeGuard],principal='USER'):
        if guard is None:return True
        vals=g.get_all(eid,guard.relation,viewer=principal,principal=principal)
        return any(f.object_kind=='entity' and f.object_value==guard.object_entity for f in vals)
    def propose(self,g:C4Graph,left:str,right:str,principal='USER'):
        xs=[left,right];out=[]
        for f in self.frames.values():
            if not self._guard(g,left,f.left_guard,principal):continue
            if not self._guard(g,right,f.right_guard,principal):continue
            out.append({'frame_id':f.frame_id,'subject':xs[f.subject_pos],'relation':rel_norm(f.output_relation),'object_kind':'entity','object':xs[f.object_pos],'frame_origin':f.origin})
        return out
    def to_dict(self):
        def guard(x):return None if x is None else asdict(x)
        return {'schema':self.SCHEMA,'frames':[{'frame_id':f.frame_id,'output_relation':f.output_relation,'subject_pos':f.subject_pos,'object_pos':f.object_pos,'left_guard':guard(f.left_guard),'right_guard':guard(f.right_guard),'origin':f.origin} for f in self.frames.values()]}
    @classmethod
    def from_dict(cls,d):
        x=cls()
        for z in d.get('frames',[]):
            lg=None if z.get('left_guard') is None else TypeGuard(**z['left_guard']);rg=None if z.get('right_guard') is None else TypeGuard(**z['right_guard'])
            x.admit(BinaryFrame(z['frame_id'],z['output_relation'],int(z['subject_pos']),int(z['object_pos']),lg,rg,z.get('origin','CREATOR_PRIOR')))
        return x

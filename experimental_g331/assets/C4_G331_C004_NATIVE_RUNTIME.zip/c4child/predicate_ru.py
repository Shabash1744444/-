from __future__ import annotations
from dataclasses import dataclass
from typing import Optional
from .graph import C4Graph, rel_norm
from .morphology_ru import RussianMorphologyV1

@dataclass
class PredicateParse:
    subject:str
    relation:str
    object:str
    polarity:str='POS'
    predicate_entity:Optional[str]=None
    predicate_surface:str=''
    tense:str='UNSPEC'

class RussianPredicateLexiconV1:
    """Learned SVO predicate bridge.

    Predicate words are entities taught with:
      PREDICATE_RELATION(predicate, "LIKES"/"CAUSES"/...)
      WORD_FORM(predicate, surface variants)

    The parser contains no per-verb relation list. It only recognizes a predicate
    when the durable graph explicitly binds that lexeme to a relation template.
    """
    def __init__(self,g:C4Graph,morph:Optional[RussianMorphologyV1]=None):
        self.g=g;self.morph=morph or RussianMorphologyV1(g)

    def predicate_relation(self,surface:str,principal='USER'):
        eid=self.g.resolve(surface) or self.morph.resolve(surface)
        if not eid:return None,None
        f=self.g.get(eid,'PREDICATE_RELATION',viewer=principal,principal=principal)
        if not f:return None,None
        return eid,rel_norm(f.object_value)

    def predicate_tense(self,eid:str,surface:str,principal='USER'):
        n=surface.strip().lower().replace('ё','е')
        for rel,val in (("PREDICATE_PAST_FORM","PAST"),("PREDICATE_PRESENT_FORM","PRESENT")):
            for f in self.g.get_all(eid,rel,viewer=principal,principal=principal):
                if str(f.object_value).strip().lower().replace('ё','е')==n:return val
        return 'UNSPEC'

    def parse_claim(self,text:str,principal='USER')->Optional[PredicateParse]:
        toks=[x for x in str(text).strip(' .!?').split() if x]
        if len(toks)<3:return None
        hits=[]
        for i,t in enumerate(toks):
            if t.lower()=='не':continue
            eid,rel=self.predicate_relation(t,principal)
            if eid and rel:hits.append((i,eid,rel,t))
        if len(hits)!=1:return None
        i,eid,rel,surf=hits[0]
        future_aux={'буду','будешь','будет','будем','будете','будут'}
        tense=None;neg=False;subj_end=i
        # G303: bounded Russian periphrastic future.  The auxiliary belongs to
        # tense, not to the subject surface: «Антон будет любить чай» must never
        # create an entity named «Антон будет» or a current LIKES fact.
        if i>=1 and toks[i-1].lower() in future_aux:
            tense='FUTURE';neg=(i>=2 and toks[i-2].lower()=='не');subj_end=i-2 if neg else i-1
        elif i>=2 and toks[i-1].lower()=='не' and toks[i-2].lower() in future_aux:
            tense='FUTURE';neg=True;subj_end=i-2
        else:
            neg=i>0 and toks[i-1].lower()=='не';subj_end=i-1 if neg else i
        subj_toks=toks[:subj_end]
        obj_toks=toks[i+1:]
        if not subj_toks or not obj_toks:return None
        # Bounded child grammar: one nominal surface on each side. Multiword names
        # can already be single graph aliases and are handled later by phrase grammar.
        subject=' '.join(subj_toks).strip();obj=' '.join(obj_toks).strip()
        if tense is None:tense=self.predicate_tense(eid,surf,principal)
        return PredicateParse(subject,rel,obj,'NEG' if neg else 'POS',eid,surf,tense)
    def parse_truth_query(self,text:str,principal='USER'):
        import re
        s=str(text).strip().rstrip('.!?')
        m=re.match(r'^правда ли,?\s*что\s+(.+)$',s,flags=re.IGNORECASE)
        if not m:return None
        p=self.parse_claim(m.group(1).strip(),principal=principal)
        if p is None:return None
        # G303: a negative past proposition is still a query about episodic
        # memory.  Do not reject it merely because its polarity is NEG.
        # EVENT_POLARITY already stores POS/NEG explicitly, and the dialogue
        # layer answers existence of the matching episode read-only.
        return p

    def parse_object_query(self,text:str,principal='USER'):
        toks=[x for x in str(text).strip(' .!?').split() if x]
        if len(toks)<3 or toks[0].lower() not in {'что','кого'}:return None
        hits=[]
        for i,t in enumerate(toks[1:],start=1):
            eid,rel=self.predicate_relation(t,principal)
            if eid and rel:hits.append((i,eid,rel,t))
        if len(hits)!=1:return None
        i,eid,rel,surf=hits[0]
        subject=' '.join(toks[i+1:]).strip()
        if not subject:return None
        future_aux={'буду','будешь','будет','будем','будете','будут'}
        tense='FUTURE' if (i>=1 and toks[i-1].lower() in future_aux) or (i>=2 and toks[i-1].lower()=='не' and toks[i-2].lower() in future_aux) else self.predicate_tense(eid,surf,principal)
        return {'subject':subject,'relation':rel,'predicate_entity':eid,'predicate_surface':surf,'tense':tense}


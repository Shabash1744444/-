from __future__ import annotations
from .graph import fast_asdict
from dataclasses import dataclass, asdict, field
from typing import Dict, Optional
import hashlib

FORBIDDEN_CLASSES={'SELF_OUTPUT','REPLAY','SIM','DERIVED','PREDICTION'}
MODEL_CLASSES={'MODEL'}
NONMODEL_CLASSES={'CORPUS','HUMAN','CREATOR','OBS','RECEIPT','ORACLE'}


def _hid(s:str,n=10):
    return hashlib.blake2s(s.encode('utf-8'),digest_size=n).hexdigest()

@dataclass
class ClaimSupport:
    source_id:str
    source_family:str
    source_class:str
    source_lineage:str=''
    dependency_root:str=''
    phase:str='PROPOSAL'  # PROPOSAL|CHALLENGE|REVALIDATION
    confidence:float=1.0
    order:int=0


@dataclass
class SourceIdentity:
    source_id:str
    source_family:str
    source_class:str
    source_lineage:str
    registered_order:int=0

@dataclass
class EpistemicCandidate:
    candidate_id:str
    slot_key:str
    subject:str
    relation:str
    object_kind:str
    object_value:str
    polarity:str
    principal:str
    status:str='PENDING'  # PENDING|NEEDS_CHALLENGE|NEEDS_REVALIDATION|ADMITTED|CONFLICT|QUARANTINED
    supports:Dict[str,ClaimSupport]=field(default_factory=dict)  # family -> latest support
    created_order:int=0
    admitted_fact_id:Optional[str]=None
    failure_reason:Optional[str]=None

class EpistemicAdmissionOrgan:
    """Quarantine + challenge gate for autonomous external teaching.

    Important: this organ is intentionally stricter than BootstrapTeacher.  It is
    the path for untrusted/synthetic autonomous sources.  Creator bootstrap may
    still use the explicit bootstrap path, but MODEL/self-derived material cannot
    promote itself through this organ.
    """
    def __init__(self,degrade_after:int=3,rehabilitate_after:int=5,strict_world:bool=False):
        self.order=0
        self.strict_world=bool(strict_world)
        self.candidates:Dict[str,EpistemicCandidate]={}
        self.slot_index:Dict[str,set[str]]={}
        self.family_failures:Dict[str,int]={}
        # Unique verified mistakes prevent one repeated bad claim from counting as many failures.
        self.family_failure_keys:Dict[str,set[str]]={}
        # Recovery is earned only on distinct propositions that agree with pre-existing canonical knowledge.
        self.family_recovery_keys:Dict[str,set[str]]={}
        self.degraded_families:set[str]=set()
        self.lineage_failures:Dict[str,int]={}
        self.lineage_failure_keys:Dict[str,set[str]]={}
        self.lineage_recovery_keys:Dict[str,set[str]]={}
        self.degraded_lineages:set[str]=set()
        self.source_registry:Dict[str,SourceIdentity]={}
        # Externally attested per-evidence ancestry. Claim content cannot mutate it.
        self.evidence_registry:Dict[str,str]={}
        self.degrade_after=max(1,int(degrade_after))
        self.rehabilitate_after=max(1,int(rehabilitate_after))


    def register_source(self,source_id:str,source_family:str,source_class:str,source_lineage:Optional[str]=None):
        source_id=str(source_id)
        source_family=str(source_family or source_id)
        source_class=str(source_class).upper()
        source_lineage=str(source_lineage or source_family)
        existing=self.source_registry.get(source_id)
        if existing is not None:
            same=(existing.source_family==source_family and existing.source_class==source_class and existing.source_lineage==source_lineage)
            return {'status':'KNOWN' if same else 'REJECTED','reason':None if same else 'SOURCE_IDENTITY_MISMATCH','identity':asdict(existing),'mutated':False}
        self.order+=1
        ident=SourceIdentity(source_id,source_family,source_class,source_lineage,self.order)
        self.source_registry[source_id]=ident
        return {'status':'REGISTERED','reason':None,'identity':asdict(ident),'mutated':True}

    def source_identity(self,source_id:str):
        x=self.source_registry.get(str(source_id))
        return asdict(x) if x else None

    def register_evidence_origin(self,evidence_id:str,dependency_root:str):
        evidence_id=str(evidence_id);dependency_root=str(dependency_root)
        existing=self.evidence_registry.get(evidence_id)
        if existing is not None:
            return {'status':'KNOWN' if existing==dependency_root else 'REJECTED','reason':None if existing==dependency_root else 'EVIDENCE_ORIGIN_MISMATCH','evidence_id':evidence_id,'dependency_root':existing,'mutated':False}
        self.evidence_registry[evidence_id]=dependency_root
        return {'status':'REGISTERED','reason':None,'evidence_id':evidence_id,'dependency_root':dependency_root,'mutated':True}

    @staticmethod
    def _support_lineage(x:ClaimSupport):
        return str(x.source_lineage or x.source_family)

    @staticmethod
    def _support_dependency(x:ClaimSupport):
        # Claim ancestry is per support. Legacy supports without explicit ancestry
        # retain the old semantics: their own lineage is their dependency root.
        return str(x.dependency_root or x.source_lineage or x.source_family)

    @classmethod
    def _independence_key(cls,x:ClaimSupport):
        return (cls._support_lineage(x), cls._support_dependency(x))

    @staticmethod
    def _calibration_anchor(graph,c,current):
        """Return True only when current direct truth is independently anchored.

        Canonical belief is not automatically verification ground. In particular,
        facts admitted by this epistemic organ must not punish later challengers merely
        for disagreeing with the organism's own autonomous conclusion.
        """
        if current not in {'TRUE','FALSE'}:
            return False
        polarity='POS' if current=='TRUE' else 'NEG'
        sid=c.subject if c.subject in graph.entities else graph.resolve(c.subject)
        if sid is None:
            return False
        oval=c.object_value
        if c.object_kind=='entity':
            oval=c.object_value if c.object_value in graph.entities else graph.resolve(c.object_value)
            if oval is None:
                return False
        anchors={'CREATOR','OBS','SENSOR'}
        for f in graph.get_all(sid,c.relation,viewer=c.principal,principal=c.principal,polarity=polarity):
            if f.object_kind==c.object_kind and f.object_value==str(oval) and str(f.authority).upper() in anchors:
                return True
        return False

    def _record_verified_failure(self,family:str,key:str,lineage:Optional[str]=None):
        family=str(family);key=str(key);lineage=str(lineage or family)
        family_keys=self.family_failure_keys.setdefault(family,set())
        lineage_keys=self.lineage_failure_keys.setdefault(lineage,set())
        fresh_family=key not in family_keys
        fresh_lineage=key not in lineage_keys
        if fresh_family:
            family_keys.add(key);self.family_failures[family]=self.family_failures.get(family,0)+1
            self.family_recovery_keys.pop(family,None)
            if self.family_failures[family]>=self.degrade_after:self.degraded_families.add(family)
        if fresh_lineage:
            lineage_keys.add(key);self.lineage_failures[lineage]=self.lineage_failures.get(lineage,0)+1
            self.lineage_recovery_keys.pop(lineage,None)
            if self.lineage_failures[lineage]>=self.degrade_after:self.degraded_lineages.add(lineage)
        return fresh_family or fresh_lineage

    def _record_verified_success(self,family:str,key:str,lineage:Optional[str]=None):
        family=str(family);key=str(key);lineage=str(lineage or family)
        family_degraded=family in self.degraded_families
        lineage_degraded=lineage in self.degraded_lineages
        if not family_degraded and not lineage_degraded:
            return {'count':0,'needed':0,'rehabilitated':False,'lineage_rehabilitated':False}
        fcount=0;lcount=0;frehab=False;lrehab=False
        if family_degraded:
            keys=self.family_recovery_keys.setdefault(family,set());keys.add(key);fcount=len(keys);frehab=fcount>=self.rehabilitate_after
            if frehab:
                self.degraded_families.discard(family);self.family_recovery_keys.pop(family,None)
        if lineage_degraded:
            keys=self.lineage_recovery_keys.setdefault(lineage,set());keys.add(key);lcount=len(keys);lrehab=lcount>=self.rehabilitate_after
            if lrehab:
                self.degraded_lineages.discard(lineage);self.lineage_recovery_keys.pop(lineage,None)
        return {'count':max(fcount,lcount),'needed':self.rehabilitate_after,'rehabilitated':(frehab or lrehab),'lineage_rehabilitated':lrehab}

    def source_calibration(self,family_or_lineage:str):
        target=str(family_or_lineage)
        matching=[x for x in self.source_registry.values() if x.source_family==target or x.source_lineage==target]
        lineages={x.source_lineage for x in matching}
        if not lineages:lineages={target}
        degraded_lineages=sorted(x for x in lineages if x in self.degraded_lineages)
        lineage_failures=sum(self.lineage_failures.get(x,0) for x in lineages)
        lineage_recovery=max([len(self.lineage_recovery_keys.get(x,set())) for x in lineages] or [0])
        return {
            'source_family':target,
            'lineages':sorted(lineages),
            'degraded':target in self.degraded_families or bool(degraded_lineages),
            'degraded_lineages':degraded_lineages,
            'verified_failures':max(self.family_failures.get(target,0),lineage_failures),
            'family_verified_failures':self.family_failures.get(target,0),
            'lineage_verified_failures':lineage_failures,
            'recovery_progress':max(len(self.family_recovery_keys.get(target,set())),lineage_recovery),
            'rehabilitate_after':self.rehabilitate_after,
        }

    @staticmethod
    def slot_key(subject,relation,object_kind,object_value,principal):
        raw=f'{subject}|{str(relation).upper()}|{object_kind}|{object_value}|{principal}'
        return 'eslot:'+_hid(raw,12)

    @staticmethod
    def candidate_id(subject,relation,object_kind,object_value,polarity,principal):
        raw=f'{subject}|{str(relation).upper()}|{object_kind}|{object_value}|{str(polarity).upper()}|{principal}'
        return 'ecand:'+_hid(raw,12)

    def _candidate(self,subject,relation,object_kind,object_value,polarity,principal):
        cid=self.candidate_id(subject,relation,object_kind,object_value,polarity,principal)
        c=self.candidates.get(cid)
        if c is None:
            self.order+=1
            slot=self.slot_key(subject,relation,object_kind,object_value,principal)
            c=EpistemicCandidate(cid,slot,str(subject),str(relation).upper(),str(object_kind),str(object_value),str(polarity).upper(),str(principal),created_order=self.order)
            self.candidates[cid]=c;self.slot_index.setdefault(slot,set()).add(cid)
        return c

    def _opposites(self,c):
        return [self.candidates[x] for x in self.slot_index.get(c.slot_key,set()) if x!=c.candidate_id]

    def _active_supports(self,c,phase=None):
        vals=list(c.supports.values())
        if phase is not None:vals=[x for x in vals if x.phase==phase]
        return [x for x in vals if x.source_family not in self.degraded_families and self._support_lineage(x) not in self.degraded_lineages]

    def _proposal_ready(self,c):
        s=self._active_supports(c,'PROPOSAL')
        lineages={self._support_lineage(x) for x in s}
        deps={self._support_dependency(x) for x in s}
        classes={x.source_class for x in s}
        if len(lineages)<2 or len(deps)<2:return False
        # Multiple model families are useful hypotheses, never self-certifying evidence.
        if classes and classes<=MODEL_CLASSES:return False
        # Require at least one non-model proposal leg.
        return any(x.source_class in NONMODEL_CLASSES for x in s)

    def _challenge_ready(self,c):
        props=self._active_supports(c,'PROPOSAL');ch=self._active_supports(c,'CHALLENGE')
        pf={self._support_lineage(x) for x in props};pd={self._support_dependency(x) for x in props}
        # Validation must be independent both by source lineage and by claim ancestry.
        return any(self._support_lineage(x) not in pf and self._support_dependency(x) not in pd and x.source_class in NONMODEL_CLASSES for x in ch)

    def _revalidation_ready(self,c):
        props=self._active_supports(c,'PROPOSAL');ch=self._active_supports(c,'CHALLENGE');rv=self._active_supports(c,'REVALIDATION')
        used={self._support_lineage(x) for x in props+ch};used_dep={self._support_dependency(x) for x in props+ch}
        return any(self._support_lineage(x) not in used and self._support_dependency(x) not in used_dep and x.source_class in NONMODEL_CLASSES for x in rv)

    def submit(self,graph,subject,relation,object_value,*,object_kind='entity',polarity='POS',principal='USER',
               source_id,source_family,source_class,source_lineage=None,evidence_id=None,dependency_root=None,phase='PROPOSAL',confidence=1.0):
        source_class=str(source_class).upper();phase=str(phase).upper();polarity=str(polarity).upper()
        if source_class in FORBIDDEN_CLASSES:
            return {'status':'REJECTED','reason':'FORBIDDEN_SOURCE_CLASS','candidate_id':None,'mutated':False}
        if source_class=='MODEL' and not source_family:
            return {'status':'REJECTED','reason':'MODEL_REQUIRES_SOURCE_FAMILY','candidate_id':None,'mutated':False}
        ident=self.source_registry.get(str(source_id))
        if ident is None:
            return {'status':'REJECTED','reason':'UNREGISTERED_SOURCE','candidate_id':None,'mutated':False}
        same=(ident.source_family==str(source_family or source_id) and ident.source_class==source_class and ident.source_lineage==str(source_lineage or source_family or source_id))
        if not same:
            return {'status':'REJECTED','reason':'SOURCE_IDENTITY_MISMATCH','candidate_id':None,'mutated':False,'registered_identity':asdict(ident)}
        source_family=ident.source_family;source_class=ident.source_class;source_lineage=ident.source_lineage
        if evidence_id is not None:
            evidence_id=str(evidence_id)
            attested=self.evidence_registry.get(evidence_id)
            if attested is None:
                return {'status':'REJECTED','reason':'UNREGISTERED_EVIDENCE_ORIGIN','candidate_id':None,'mutated':False}
            if dependency_root is not None and str(dependency_root)!=attested:
                return {'status':'REJECTED','reason':'EVIDENCE_ORIGIN_MISMATCH','candidate_id':None,'mutated':False,'attested_dependency_root':attested}
            dependency_root=attested
        if phase not in {'PROPOSAL','CHALLENGE','REVALIDATION'}:raise ValueError('bad phase')
        c=self._candidate(subject,relation,object_kind,str(object_value),polarity,principal)
        self.order+=1
        fam=str(source_family or source_id);lineage=str(source_lineage or fam)
        dependency_root=str(dependency_root or lineage)
        c.supports[f'{phase}|{lineage}']=ClaimSupport(str(source_id),fam,source_class,lineage,dependency_root,phase,float(confidence),self.order)

        # Source calibration is allowed against knowledge that was already canonical before this claim.
        # It never mutates the graph and never turns reliability into authority.
        sid0=c.subject if c.subject in graph.entities else graph.resolve(c.subject)
        if c.object_kind=='entity':
            oval0=c.object_value if c.object_value in graph.entities else graph.resolve(c.object_value)
        else:
            oval0=c.object_value
        current0='UNKNOWN' if sid0 is None or (c.object_kind=='entity' and oval0 is None) else graph.truth(sid0,c.relation,oval0,object_kind=c.object_kind,viewer=c.principal,principal=c.principal)
        desired0='TRUE' if c.polarity=='POS' else 'FALSE'
        calibration=None
        if current0!='UNKNOWN' and self._calibration_anchor(graph,c,current0):
            ckey=f'{c.slot_key}|{c.polarity}'
            if current0==desired0:
                calibration={'result':'VERIFIED_CORRECT',**self._record_verified_success(fam,ckey,lineage)}
            else:
                fresh=self._record_verified_failure(fam,ckey,lineage)
                calibration={'result':'VERIFIED_WRONG','fresh':fresh,**self.source_calibration(lineage)}

        # G324-P3 strict mode: testimony about WORLD is not a MEDIATE receipt.
        # This organ has no trusted boundary to verify physical-world outcomes;
        # even three mutually independent human/model/corpus reports cannot
        # directly create a WORLD fact. Keep claims as candidates only. Verified
        # observations must enter via an independently guarded MEDIATE path.
        # Legacy policy retained ONLY to compare older tests, not for live release.
        if self.strict_world:
            c.status='NEEDS_GROUNDING'
            c.failure_reason='NO_VERIFIED_WORLD_BOUNDARY'
            return {'status':c.status,'reason':c.failure_reason,
                    'candidate_id':c.candidate_id,'mutated':False,'calibration':calibration}

        # Opposite evidence is not enough by itself to retract.  Retraction is at least
        # as strict as admission: the incoming opposite stance must itself have mature
        # proposal evidence plus an independent non-model challenge.
        opposites=self._opposites(c)
        mature_opposition=self._proposal_ready(c) and self._challenge_ready(c)
        if mature_opposition:
            admitted_opposites=[o for o in opposites if o.admitted_fact_id and o.status=='ADMITTED']
            if admitted_opposites:
                c.status='NEEDS_REVALIDATION';c.failure_reason='MATURE_OPPOSING_EVIDENCE'
                for o in admitted_opposites:
                    o.status='QUARANTINED';o.failure_reason='LATE_CHALLENGED_CONTRADICTION'
                    qsid=o.subject if o.subject in graph.entities else graph.resolve(o.subject)
                    qov=o.object_value if o.object_kind!='entity' or o.object_value in graph.entities else graph.resolve(o.object_value)
                    if qsid is not None and (o.object_kind!='entity' or qov is not None):
                        graph.forget(qsid,o.relation,principal=o.principal,object_kind=o.object_kind,object_value=qov,origin="EXTERNAL_CORPUS",authority="EPISTEMIC_RETRACTION",constitutional_basis="EPISTEMIC_RETRACTION")
                # Conservative revision: mature contradiction returns the proposition to
                # UNKNOWN/CONFLICT. It does not automatically invert truth in the same step.
                return {'status':c.status,'reason':c.failure_reason,'candidate_id':c.candidate_id,'mutated':True,'calibration':calibration}

        # After a mature retraction, the same proposal/challenge coalition cannot simply
        # flip canonical truth. A fresh non-model family must revalidate the revised stance.
        if c.status=='NEEDS_REVALIDATION':
            if not self._revalidation_ready(c):
                return {'status':c.status,'candidate_id':c.candidate_id,'mutated':False,'calibration':calibration}
            sid=c.subject if c.subject in graph.entities else graph.resolve(c.subject)
            if c.object_kind=='entity':
                oval=c.object_value if c.object_value in graph.entities else graph.resolve(c.object_value)
            else:oval=c.object_value
            current='UNKNOWN' if sid is None or (c.object_kind=='entity' and oval is None) else graph.truth(sid,c.relation,oval,object_kind=c.object_kind,viewer=c.principal,principal=c.principal)
            desired='TRUE' if c.polarity=='POS' else 'FALSE'
            if current!='UNKNOWN':
                if current==desired:
                    c.status='ADMITTED';c.failure_reason='ALREADY_SUPPORTED_BY_GRAPH'
                    return {'status':c.status,'candidate_id':c.candidate_id,'mutated':False,'calibration':calibration}
                c.status='CONFLICT';c.failure_reason='REVALIDATION_CONFLICTS_WITH_CANONICAL_GRAPH'
                return {'status':c.status,'reason':c.failure_reason,'candidate_id':c.candidate_id,'mutated':False,'calibration':calibration}
            sid=sid or graph.entity(c.subject,'concept')
            if c.object_kind=='entity':oval=oval or graph.entity(c.object_value,'concept')
            before=len(graph.facts)
            f=graph.commit(sid,c.relation,oval,object_kind=c.object_kind,polarity=c.polarity,
                           origin='EXTERNAL_CORPUS',principal=c.principal,privacy='PRIVATE',authority='EPISTEMIC_REVALIDATION',
                           confidence=min(x.confidence for x in self._active_supports(c)),source_ref=c.candidate_id,source_group=c.candidate_id,constitutional_basis='EPISTEMIC_REVALIDATION')
            c.status='ADMITTED';c.admitted_fact_id=f.fact_id;c.failure_reason='REVALIDATED_AFTER_RETRACTION'
            return {'status':c.status,'candidate_id':c.candidate_id,'mutated':len(graph.facts)!=before,'fact_id':f.fact_id,'calibration':calibration}

        # For unadmitted competing hypotheses, call it conflict only when both sides have
        # proposal-ready evidence. A lone model disagreement remains ordinary quarantine.
        for o in opposites:
            if not o.admitted_fact_id and self._proposal_ready(c) and self._proposal_ready(o):
                c.status='CONFLICT';o.status='CONFLICT';c.failure_reason=o.failure_reason='OPPOSING_PROPOSALS'
                return {'status':c.status,'reason':c.failure_reason,'candidate_id':c.candidate_id,'mutated':False,'calibration':calibration}

        if c.status in {'ADMITTED','QUARANTINED'}:
            return {'status':c.status,'candidate_id':c.candidate_id,'mutated':False,'calibration':calibration}
        if not self._proposal_ready(c):
            c.status='PENDING';return {'status':c.status,'candidate_id':c.candidate_id,'mutated':False,'calibration':calibration}
        if not self._challenge_ready(c):
            c.status='NEEDS_CHALLENGE';return {'status':c.status,'candidate_id':c.candidate_id,'mutated':False,'calibration':calibration}

        # Never override pre-existing canonical knowledge through the autonomous-teacher path.
        sid=c.subject if c.subject in graph.entities else graph.resolve(c.subject)
        if c.object_kind=='entity':
            oval=c.object_value if c.object_value in graph.entities else graph.resolve(c.object_value)
        else:oval=c.object_value
        current='UNKNOWN' if sid is None or (c.object_kind=='entity' and oval is None) else graph.truth(sid,c.relation,oval,object_kind=c.object_kind,viewer=c.principal,principal=c.principal)
        desired='TRUE' if c.polarity=='POS' else 'FALSE'
        if current!='UNKNOWN':
            if current==desired:
                c.status='ADMITTED';c.failure_reason='ALREADY_SUPPORTED_BY_GRAPH'
                return {'status':c.status,'candidate_id':c.candidate_id,'mutated':False,'calibration':calibration}
            c.status='CONFLICT';c.failure_reason='CONFLICTS_WITH_CANONICAL_GRAPH'
            if self._calibration_anchor(graph,c,current):
                for s in self._active_supports(c):
                    self._record_verified_failure(s.source_family,f'{c.slot_key}|{c.polarity}',self._support_lineage(s))
            return {'status':c.status,'reason':c.failure_reason,'candidate_id':c.candidate_id,'mutated':False,'calibration':calibration}

        # Aggregate admission keeps detailed provenance in this organ; the graph stores one audited canonical support.
        # Materialize identities only after challenge admission.
        sid=sid or graph.entity(c.subject,'concept')
        if c.object_kind=='entity':oval=oval or graph.entity(c.object_value,'concept')
        before=len(graph.facts)
        f=graph.commit(sid,c.relation,oval,object_kind=c.object_kind,polarity=c.polarity,
                       origin='EXTERNAL_CORPUS',principal=c.principal,privacy='PRIVATE',authority='EPISTEMIC_CHALLENGE',
                       confidence=min(x.confidence for x in self._active_supports(c)),source_ref=c.candidate_id,source_group=c.candidate_id,constitutional_basis='EPISTEMIC_ADMISSION')
        c.status='ADMITTED';c.admitted_fact_id=f.fact_id
        return {'status':c.status,'candidate_id':c.candidate_id,'mutated':len(graph.facts)!=before,'fact_id':f.fact_id,'calibration':calibration}

    def status(self,candidate_id):
        c=self.candidates[candidate_id]
        p=self._active_supports(c,'PROPOSAL');v=self._active_supports(c,'CHALLENGE');r=self._active_supports(c,'REVALIDATION')
        return {'candidate_id':c.candidate_id,'status':c.status,'failure_reason':c.failure_reason,
                'proposal_families':sorted({x.source_family for x in p}),'proposal_lineages':sorted({self._support_lineage(x) for x in p}),'proposal_classes':sorted({x.source_class for x in p}),
                'challenge_families':sorted({x.source_family for x in v}),'challenge_lineages':sorted({self._support_lineage(x) for x in v}),'challenge_classes':sorted({x.source_class for x in v}),
                'revalidation_families':sorted({x.source_family for x in r}),'revalidation_lineages':sorted({self._support_lineage(x) for x in r}),'revalidation_classes':sorted({x.source_class for x in r}),
                'admitted_fact_id':c.admitted_fact_id}

    def pending_challenges(self):
        return [c.candidate_id for c in self.candidates.values() if c.status=='NEEDS_CHALLENGE']

    def to_dict(self):
        return {'schema':'C4_EPISTEMIC_ADMISSION_V0.6','strict_world':self.strict_world,'order':self.order,'degrade_after':self.degrade_after,'rehabilitate_after':self.rehabilitate_after,
                'source_registry':{k:fast_asdict(v) for k,v in self.source_registry.items()},
                'evidence_registry':dict(self.evidence_registry),
                'lineage_failures':dict(self.lineage_failures),
                'lineage_failure_keys':{k:sorted(v) for k,v in self.lineage_failure_keys.items()},
                'lineage_recovery_keys':{k:sorted(v) for k,v in self.lineage_recovery_keys.items()},
                'degraded_lineages':sorted(self.degraded_lineages),
                'family_failures':dict(self.family_failures),
                'family_failure_keys':{k:sorted(v) for k,v in self.family_failure_keys.items()},
                'family_recovery_keys':{k:sorted(v) for k,v in self.family_recovery_keys.items()},
                'degraded_families':sorted(self.degraded_families),
                'candidates':[{**fast_asdict(c),'supports':{k:fast_asdict(v) for k,v in c.supports.items()}} for c in self.candidates.values()]}

    @classmethod
    def from_dict(cls,d):
        o=cls(d.get('degrade_after',3),d.get('rehabilitate_after',5),d.get('strict_world',False));o.order=int(d.get('order',0));o.family_failures={str(k):int(v) for k,v in d.get('family_failures',{}).items()};o.family_failure_keys={str(k):set(v) for k,v in d.get('family_failure_keys',{}).items()};o.family_recovery_keys={str(k):set(v) for k,v in d.get('family_recovery_keys',{}).items()};o.degraded_families=set(d.get('degraded_families',[]));o.lineage_failures={str(k):int(v) for k,v in d.get('lineage_failures',{}).items()};o.lineage_failure_keys={str(k):set(v) for k,v in d.get('lineage_failure_keys',{}).items()};o.lineage_recovery_keys={str(k):set(v) for k,v in d.get('lineage_recovery_keys',{}).items()};o.degraded_lineages=set(d.get('degraded_lineages',[]));o.evidence_registry={str(k):str(v) for k,v in d.get('evidence_registry',{}).items()}
        for k,v in d.get('source_registry',{}).items():
            row=dict(v);row.setdefault('source_lineage',row.get('source_family',k));o.source_registry[str(k)]=SourceIdentity(**row)
        for row in d.get('candidates',[]):
            row=dict(row);sup={}
            for k,v in row.get('supports',{}).items():
                vv=dict(v);vv.setdefault('source_lineage',vv.get('source_family',''));vv.setdefault('dependency_root',vv.get('source_lineage') or vv.get('source_family',''));sup[k]=ClaimSupport(**vv)
            row['supports']=sup
            c=EpistemicCandidate(**row);o.candidates[c.candidate_id]=c;o.slot_index.setdefault(c.slot_key,set()).add(c.candidate_id)
            # Backward migration: older checkpoints had supports but no source registry.
            # Bind each historical source_id to the provenance it already used; never
            # let a restart reset source identity.
            for sup in c.supports.values():
                if sup.source_id not in o.source_registry:
                    lineage=o._support_lineage(sup)
                    o.source_registry[sup.source_id]=SourceIdentity(sup.source_id,sup.source_family,sup.source_class,lineage,int(sup.order or c.created_order or 0))
        return o

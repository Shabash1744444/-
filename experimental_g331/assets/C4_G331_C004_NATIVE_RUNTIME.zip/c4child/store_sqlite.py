"""G270: the child's graph on disk (SQLite).

``SQLiteGraph`` is a ``C4Graph``: the admission logic (slots, corrections, evidence, source conflicts) is the same
code; only the storage changes.

- Facts, entities, canonical slots, aliases, evidence and the audit log live in indexed tables.
- Objects are loaded on demand through an identity map (one Python object per row while it is in use), so the
  graph's in-place updates are written back explicitly (``_touch_*``).
- ``flush()`` ends a user turn with one transaction commit (milliseconds): what was taught survives a crash, and a
  half-finished turn is rolled back as a whole.
- Opening reads a few meta rows, whatever the size of the model.

The .c4m checkpoint stays the exchange format of the weights: ``import_c4m`` streams it into a .c4db with bounded
memory, ``export_c4m`` streams it back (the graph JSON is byte-identical to ``save_c4m_compact`` of the same graph).
"""
from __future__ import annotations

import hashlib
import io
import json
import os
import sqlite3
import time
import weakref
from typing import Dict, List
from zipfile import ZipFile, ZIP_DEFLATED

from .graph import (C4Graph, Entity, EvidenceRecord, EvidenceSource, Fact, RelationSpec, STRICT_IDENTITY_KINDS,
                    _field_names, alias_norm, norm, norm_exact, rel_norm)
from .constitution import LEGACY, STRICT
from .scope import KNOWLEDGE

SCHEMA_DB = "C4DB_V1"
_PUBLIC_ORIGINS = ("CREATOR_PRIOR", "EXTERNAL_CORPUS", "OBS", "RECEIPT")
_ACTIVE_SQL = "('ADMITTED','REVISED')"

_DDL = """
CREATE TABLE IF NOT EXISTS meta(key TEXT PRIMARY KEY, value TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS entities(rid INTEGER PRIMARY KEY, eid TEXT UNIQUE NOT NULL, kind TEXT NOT NULL,
    label TEXT NOT NULL, aliases TEXT NOT NULL, created_order INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS aliases(akey TEXT NOT NULL, kind TEXT NOT NULL, eid TEXT NOT NULL, seq INTEGER NOT NULL,
    PRIMARY KEY(akey, kind, eid)) WITHOUT ROWID;
CREATE TABLE IF NOT EXISTS facts(frow INTEGER PRIMARY KEY, fid TEXT UNIQUE NOT NULL, subject TEXT NOT NULL, relation TEXT NOT NULL,
    object_kind TEXT NOT NULL, object_value TEXT NOT NULL, origin TEXT, principal TEXT, privacy TEXT, status TEXT,
    authority TEXT, confidence REAL, ord INTEGER, source_ref TEXT, correction_of TEXT, polarity TEXT,
    source_group TEXT);
CREATE TABLE IF NOT EXISTS canonical(rid INTEGER PRIMARY KEY, subject TEXT NOT NULL, relation TEXT NOT NULL, principal TEXT NOT NULL,
    slot TEXT NOT NULL, fid TEXT NOT NULL, object_kind TEXT, object_value TEXT,
    UNIQUE(subject, relation, principal, slot));
CREATE TABLE IF NOT EXISTS evidence(rid INTEGER PRIMARY KEY, pk TEXT UNIQUE NOT NULL, subject TEXT, relation TEXT, principal TEXT,
    object_kind TEXT, object_value TEXT, polarity TEXT, total_count INTEGER, sources TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS audit(seq INTEGER PRIMARY KEY AUTOINCREMENT, rec TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS ret_doc(frow INTEGER PRIMARY KEY, subj TEXT NOT NULL, obj TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS ret_post(stem TEXT NOT NULL, frow INTEGER NOT NULL, PRIMARY KEY(stem, frow)) WITHOUT ROWID;
CREATE TABLE IF NOT EXISTS ret_df(stem TEXT PRIMARY KEY, df INTEGER NOT NULL) WITHOUT ROWID;
CREATE TABLE IF NOT EXISTS ret_lemma(lkey TEXT PRIMARY KEY, eid TEXT NOT NULL, amb INTEGER NOT NULL) WITHOUT ROWID;
"""
_INDEXES = """
CREATE INDEX IF NOT EXISTS canon_object ON canonical(relation, principal, object_kind, object_value);
CREATE INDEX IF NOT EXISTS ev_slot ON evidence(subject, relation, principal);
CREATE INDEX IF NOT EXISTS facts_active ON facts(principal, ord) WHERE status IN ('ADMITTED','REVISED');
CREATE INDEX IF NOT EXISTS facts_user ON facts(principal, ord) WHERE status IN ('ADMITTED','REVISED') AND origin='USER_SAID';
"""
_FACT_COLS = ("fid", "subject", "relation", "object_kind", "object_value", "origin", "principal", "privacy", "status",
              "authority", "confidence", "ord", "source_ref", "correction_of", "polarity", "source_group")
_FACT_SELECT = "SELECT " + ",".join("f." + c for c in _FACT_COLS) + " FROM "


def _visible_sql(viewer, principal, alias="f"):
    """SQL for C4Graph._visible: active, and private non-public knowledge only for its own principal / CREATOR."""
    base = f"{alias}.status IN {_ACTIVE_SQL}"
    if viewer in (principal, "CREATOR"):
        return base, ()
    return (base + f" AND NOT ({alias}.privacy='PRIVATE' AND {alias}.origin NOT IN (?,?,?,?))", _PUBLIC_ORIGINS)


class _Cache:
    """Identity map: one live object per row (weak), plus a bounded set of recently used objects (strong)."""

    def __init__(self, size):
        self.weak = weakref.WeakValueDictionary()
        self.recent: Dict[str, object] = {}
        self.size = max(256, int(size))

    def get(self, k):
        o = self.weak.get(k)
        if o is not None:
            self.recent[k] = o
        return o

    def put(self, k, o):
        self.weak[k] = o
        self.recent[k] = o
        if len(self.recent) > self.size:
            for x in list(self.recent)[: self.size // 2]:
                self.recent.pop(x, None)

    def drop(self, k):
        self.weak.pop(k, None)
        self.recent.pop(k, None)


def _sources_to_json(sources) -> str:
    return json.dumps([[k, v.origin, v.authority, v.count, v.max_confidence, v.first_order, v.last_order]
                       for k, v in (sources or {}).items()], ensure_ascii=False, separators=(",", ":"))


def _sources_from_json(text) -> Dict[str, EvidenceSource]:
    data = json.loads(text)
    if isinstance(data, dict):      # tolerant of the verbose form
        return {k: EvidenceSource(**v) for k, v in data.items()}
    return {x[0]: EvidenceSource(x[0], x[1], x[2], x[3], x[4], x[5], x[6]) for x in data}


# ---------------------------------------------------------------- dict-like views used by the shared C4Graph logic
class _FactMap:
    def __init__(self, g):
        self.g = g

    def __getitem__(self, fid):
        f = self.g._fact(fid)
        if f is None:
            raise KeyError(fid)
        return f

    def get(self, fid, default=None):
        f = self.g._fact(fid)
        return default if f is None else f

    def __contains__(self, fid):
        if self.g._fc.get(fid) is not None:
            return True
        return self.g.db.execute("SELECT 1 FROM facts WHERE fid=?", (fid,)).fetchone() is not None

    def __setitem__(self, fid, f):
        g = self.g
        cur = g.db.execute("INSERT OR IGNORE INTO facts(fid,subject,relation,object_kind,object_value,origin,principal,privacy,status,authority,confidence,ord,source_ref,correction_of,polarity,source_group) VALUES(" + ",".join("?" * 16) + ")", g._fact_row(f))
        if cur.rowcount:
            g._n_facts += 1
            g._new_fids.append(fid)
        else:
            g._touch_fact(f)
        g._fc.put(fid, f)

    def __len__(self):
        return self.g._n_facts

    def __iter__(self):
        for (fid,) in self.g.db.execute("SELECT fid FROM facts ORDER BY frow"):
            yield fid

    def keys(self):
        return list(iter(self))

    def values(self):
        return self.g._iter_facts(_FACT_SELECT + "facts f ORDER BY f.frow", ())

    def items(self):
        for f in self.values():
            yield f.fact_id, f


class _EntityMap:
    def __init__(self, g):
        self.g = g

    def __getitem__(self, eid):
        e = self.g._entity(eid)
        if e is None:
            raise KeyError(eid)
        return e

    def get(self, eid, default=None):
        e = self.g._entity(eid)
        return default if e is None else e

    def __contains__(self, eid):
        if not isinstance(eid, str):
            return False
        if self.g._ec.get(eid) is not None:
            return True
        return self.g.db.execute("SELECT 1 FROM entities WHERE eid=?", (eid,)).fetchone() is not None

    def __setitem__(self, eid, e):
        g = self.g
        cur = g.db.execute("INSERT OR IGNORE INTO entities(eid,kind,label,aliases,created_order) VALUES(?,?,?,?,?)",
                           (e.entity_id, e.kind, e.label, json.dumps(list(e.aliases), ensure_ascii=False), int(e.created_order)))
        if cur.rowcount:
            g._n_entities += 1
        else:
            g._touch_entity(e)
        g._ec.put(eid, e)
        if e.kind == "concept":
            g._dirty_lemma.add(eid)

    def __len__(self):
        return self.g._n_entities

    def __iter__(self):
        for (eid,) in self.g.db.execute("SELECT eid FROM entities ORDER BY rid"):
            yield eid

    def keys(self):
        return list(iter(self))

    def values(self):
        g = self.g
        for row in g.db.execute("SELECT eid,kind,label,aliases,created_order FROM entities ORDER BY rid"):
            yield g._entity_from_row(row)

    def items(self):
        for e in self.values():
            yield e.entity_id, e


class _CanonMap:
    def __init__(self, g):
        self.g = g

    def get(self, key, default=None):
        r = self.g.db.execute("SELECT fid FROM canonical WHERE subject=? AND relation=? AND principal=? AND slot=?",
                              tuple(key)).fetchone()
        return default if r is None else r[0]

    def __getitem__(self, key):
        v = self.get(key)
        if v is None:
            raise KeyError(key)
        return v

    def __contains__(self, key):
        return self.get(key) is not None

    def __setitem__(self, key, fid):
        g = self.g
        f = g._fact(fid)
        ok, ov = (f.object_kind, str(f.object_value)) if f is not None else (None, None)
        if self.get(key) is None:
            g.db.execute("INSERT INTO canonical(subject,relation,principal,slot,fid,object_kind,object_value) VALUES(?,?,?,?,?,?,?)", tuple(key) + (fid, ok, ov))
            g._n_canon += 1
        else:
            g.db.execute("UPDATE canonical SET fid=?,object_kind=?,object_value=? WHERE subject=? AND relation=? "
                         "AND principal=? AND slot=?", (fid, ok, ov) + tuple(key))

    def pop(self, key, *default):
        fid = self.get(key)
        if fid is None:
            if default:
                return default[0]
            raise KeyError(key)
        self.g.db.execute("DELETE FROM canonical WHERE subject=? AND relation=? AND principal=? AND slot=?", tuple(key))
        self.g._n_canon -= 1
        return fid

    def __len__(self):
        return self.g._n_canon

    def items(self):
        for s, r, p, slot, fid in self.g.db.execute("SELECT subject,relation,principal,slot,fid FROM canonical ORDER BY rid"):
            yield (s, r, p, slot), fid

    def __iter__(self):
        for k, _ in self.items():
            yield k

    def keys(self):
        return list(iter(self))

    def values(self):
        for _, fid in self.items():
            yield fid

    def has_relation(self, r):
        return self.g.db.execute("SELECT 1 FROM canonical WHERE relation=? LIMIT 1", (r,)).fetchone() is not None


class _KeyView:
    """Read-only view of a derived index (e.g. slot index): .get(key) returns the canonical keys."""

    def __init__(self, g, sql, build):
        self.g, self.sql, self.build = g, sql, build

    def get(self, key, default=()):
        rows = self.g.db.execute(self.sql, tuple(key)).fetchall()
        return [self.build(key, r) for r in rows] if rows else default

    def setdefault(self, key, default=None):          # the shared logic only writes derived indexes in _index_* hooks
        return set()


class _AliasMap:
    """C4Graph.alias_index: (kind, alias key) -> entity; the latest indexed row wins (as the dict assignment did)."""

    def __init__(self, g):
        self.g = g

    def get(self, key, default=None):
        kind, akey = key
        r = self.g.db.execute("SELECT eid FROM aliases WHERE akey=? AND kind=? ORDER BY seq DESC LIMIT 1", (akey, kind)).fetchone()
        return default if r is None else r[0]

    def __getitem__(self, key):
        v = self.get(key)
        if v is None:
            raise KeyError(key)
        return v

    def __contains__(self, key):
        return self.get(key) is not None

    def __setitem__(self, key, eid):
        kind, akey = key
        g = self.g
        g._alias_seq += 1
        g.db.execute("INSERT INTO aliases VALUES(?,?,?,?) ON CONFLICT(akey,kind,eid) DO UPDATE SET seq=excluded.seq",
                     (akey, kind, eid, g._alias_seq))

    def __len__(self):
        return self.g.db.execute("SELECT COUNT(*) FROM (SELECT 1 FROM aliases GROUP BY akey, kind)").fetchone()[0]


_STRICT = tuple(sorted(STRICT_IDENTITY_KINDS))


class _LexView:
    """C4Graph._alias_lex / _alias_exact: every entity ever indexed under a key (strict kinds or the others)."""

    def __init__(self, g, strict):
        self.g = g
        self.where = "kind IN (?,?,?)" if strict else "kind NOT IN (?,?,?)"

    def get(self, key, default=()):
        rows = self.g.db.execute("SELECT DISTINCT eid FROM aliases WHERE akey=? AND " + self.where, (key,) + _STRICT).fetchall()
        return {r[0] for r in rows} if rows else default


class _EvidenceMap:
    def __init__(self, g):
        self.g = g

    def get(self, pk, default=None):
        r = self.g._evidence(pk)
        return default if r is None else r

    def __getitem__(self, pk):
        r = self.g._evidence(pk)
        if r is None:
            raise KeyError(pk)
        return r

    def __contains__(self, pk):
        return self.g._evidence(pk) is not None

    def __setitem__(self, pk, rec):
        g = self.g
        if g.db.execute("SELECT 1 FROM evidence WHERE pk=?", (pk,)).fetchone() is None:
            g._n_evidence += 1
        g._write_evidence(rec)
        g._vc.put(pk, rec)

    def __len__(self):
        return self.g._n_evidence

    def values(self):
        g = self.g
        for row in g.db.execute("SELECT pk,subject,relation,principal,object_kind,object_value,polarity,total_count,sources "
                                "FROM evidence ORDER BY rid"):
            yield g._evidence_from_row(row)

    def __iter__(self):
        for (pk,) in self.g.db.execute("SELECT pk FROM evidence ORDER BY rid"):
            yield pk

    def items(self):
        for r in self.values():
            yield r.proposition_key, r


class _AuditLog:
    def __init__(self, g):
        self.g = g

    def append(self, rec):
        self.g.db.execute("INSERT INTO audit(rec) VALUES(?)", (json.dumps(rec, ensure_ascii=False),))
        self.g._n_audit += 1

    def pop(self, i=-1):
        if i != -1:
            raise NotImplementedError("audit log: only the last record can be removed")
        row = self.g.db.execute("SELECT seq, rec FROM audit ORDER BY seq DESC LIMIT 1").fetchone()
        if row is None:
            raise IndexError("pop from empty audit log")
        self.g.db.execute("DELETE FROM audit WHERE seq=?", (row[0],))
        self.g._n_audit -= 1
        return json.loads(row[1])

    def __len__(self):
        return self.g._n_audit

    def __getitem__(self, i):
        n = self.g._n_audit
        if isinstance(i, slice):
            return list(self)[i]
        if i < 0:
            i += n
        if not 0 <= i < n:
            raise IndexError(i)
        row = self.g.db.execute("SELECT rec FROM audit ORDER BY seq LIMIT 1 OFFSET ?", (i,)).fetchone()
        return json.loads(row[0])

    def __iter__(self):
        for (rec,) in self.g.db.execute("SELECT rec FROM audit ORDER BY seq"):
            yield json.loads(rec)

    def __bool__(self):
        return self.g._n_audit > 0


# ---------------------------------------------------------------- the graph on disk
class SQLiteGraph(C4Graph):
    store_kind = "sqlite"

    def __init__(self, path: str = ":memory:", *, cache_size: int = 50000):
        # C4Graph.__init__ is not called: its dicts are replaced by views on the tables.
        self.path = str(path)
        self.db = sqlite3.connect(self.path, check_same_thread=False)
        self.db.execute("PRAGMA foreign_keys=OFF")
        if self.path != ":memory:":
            self.db.execute("PRAGMA journal_mode=WAL")
            self.db.execute("PRAGMA synchronous=NORMAL")
        self.db.execute("PRAGMA temp_store=MEMORY")
        self.db.execute("PRAGMA cache_size=-16000")
        self.db.executescript(_DDL)
        self.db.executescript(_INDEXES)
        self._fc, self._ec, self._vc = _Cache(cache_size), _Cache(cache_size // 2), _Cache(cache_size // 4)
        self.entities = _EntityMap(self)
        self.facts = _FactMap(self)
        self.canonical = _CanonMap(self)
        self.alias_index = _AliasMap(self)
        self._alias_lex = _LexView(self, False)
        self._alias_exact = _LexView(self, True)
        self._slot_index = _KeyView(self, "SELECT slot FROM canonical WHERE subject=? AND relation=? AND principal=?",
                                    lambda k, r: (k[0], k[1], k[2], r[0]))
        self._subject_index = _KeyView(self, "SELECT relation, slot FROM canonical WHERE subject=? AND principal=?",
                                       lambda k, r: (k[0], r[0], k[1], r[1]))
        self._object_index = _KeyView(self, "SELECT subject, slot FROM canonical WHERE relation=? AND principal=? "
                                             "AND object_kind=? AND object_value=?",
                                      lambda k, r: (r[0], k[0], k[1], r[1]))
        self.evidence = _EvidenceMap(self)
        self._evidence_slot_index = _KeyView(self, "SELECT pk FROM evidence WHERE subject=? AND relation=? AND principal=?",
                                             lambda k, r: r[0])
        self.audit = _AuditLog(self)
        self._load_state()
        self.db.commit()

    def _load_state(self):
        self._new_fids: List[str] = []
        self._dirty_lemma: set = set()
        m = dict(self.db.execute("SELECT key, value FROM meta").fetchall())
        if "schema" not in m:
            self.db.execute("INSERT INTO meta VALUES('schema',?)", (SCHEMA_DB,))
        elif m["schema"] != SCHEMA_DB:
            raise ValueError(f"unsupported C4 store schema {m['schema']!r} in {self.path} (expected {SCHEMA_DB})")
        self.order = int(m.get("order", 0))
        self.lexicon_revision = int(m.get("lexicon_revision", 0))
        from .constitution import LEGACY, CONSTITUTION_VERSION
        self.constitutional_mode = str(m.get("constitutional_mode", LEGACY)).upper()
        self.constitution_version = m.get("constitution_version", CONSTITUTION_VERSION)
        self.relation_templates = set(json.loads(m.get("relation_templates", "[]")))
        self.relation_specs = {k: RelationSpec(v.relation, v.cardinality, v.object_mode) for k, v in self.DEFAULT_RELATIONS.items()}
        for x in json.loads(m.get("relation_specs", "[]")):
            spec = RelationSpec(**x)
            self.relation_specs[spec.relation] = spec
        self._n_facts = self.db.execute("SELECT COUNT(*) FROM facts").fetchone()[0]
        self._n_entities = self.db.execute("SELECT COUNT(*) FROM entities").fetchone()[0]
        self._n_canon = self.db.execute("SELECT COUNT(*) FROM canonical").fetchone()[0]
        self._n_evidence = self.db.execute("SELECT COUNT(*) FROM evidence").fetchone()[0]
        self._n_audit = self.db.execute("SELECT COUNT(*) FROM audit").fetchone()[0]
        self._alias_seq = self.db.execute("SELECT COALESCE(MAX(seq),0) FROM aliases").fetchone()[0]

    # ---- rows <-> objects (identity map)
    @staticmethod
    def _fact_row(f):
        return (f.fact_id, f.subject, f.relation, f.object_kind, str(f.object_value), f.origin, f.principal, f.privacy,
                f.status, f.authority, float(f.confidence), int(f.order), f.source_ref, f.correction_of, f.polarity,
                f.source_group)

    def _fact_from_row(self, r):
        f = self._fc.get(r[0])
        if f is not None:
            return f
        f = Fact(fact_id=r[0], subject=r[1], relation=r[2], object_kind=r[3], object_value=r[4], origin=r[5],
                 principal=r[6], privacy=r[7], status=r[8], authority=r[9], confidence=r[10], order=r[11],
                 source_ref=r[12], correction_of=r[13], polarity=r[14], source_group=r[15])
        self._fc.put(r[0], f)
        return f

    def _fact(self, fid):
        f = self._fc.get(fid)
        if f is not None:
            return f
        r = self.db.execute(_FACT_SELECT + "facts f WHERE f.fid=?", (fid,)).fetchone()
        return None if r is None else self._fact_from_row(r)

    def _iter_facts(self, sql, params):
        for r in self.db.execute(sql, params):
            yield self._fact_from_row(r)

    def _entity_from_row(self, r):
        e = self._ec.get(r[0])
        if e is not None:
            return e
        e = Entity(r[0], r[1], r[2], json.loads(r[3]), r[4])
        self._ec.put(r[0], e)
        return e

    def _entity(self, eid):
        if not isinstance(eid, str):
            return None
        e = self._ec.get(eid)
        if e is not None:
            return e
        r = self.db.execute("SELECT eid,kind,label,aliases,created_order FROM entities WHERE eid=?", (eid,)).fetchone()
        return None if r is None else self._entity_from_row(r)

    def _evidence_from_row(self, r):
        rec = self._vc.get(r[0])
        if rec is not None:
            return rec
        sources = _sources_from_json(r[8])
        rec = EvidenceRecord(r[0], int(r[7] or 0), sources, r[1], r[2], r[4], r[5], r[6], r[3])
        self._vc.put(r[0], rec)
        return rec

    def _evidence(self, pk):
        rec = self._vc.get(pk)
        if rec is not None:
            return rec
        r = self.db.execute("SELECT pk,subject,relation,principal,object_kind,object_value,polarity,total_count,sources "
                            "FROM evidence WHERE pk=?", (pk,)).fetchone()
        return None if r is None else self._evidence_from_row(r)

    def _write_evidence(self, rec):
        src = _sources_to_json(rec.sources)
        self.db.execute("INSERT INTO evidence(pk,subject,relation,principal,object_kind,object_value,polarity,total_count,sources) "
                        "VALUES(?,?,?,?,?,?,?,?,?) ON CONFLICT(pk) DO UPDATE SET "
                        "total_count=excluded.total_count, sources=excluded.sources",
                        (rec.proposition_key, rec.subject, rec.relation, rec.principal, rec.object_kind,
                         str(rec.object_value), rec.polarity, int(rec.total_count), src))

    # ---- write-back hooks (the shared logic updates objects in place)
    def _touch_fact(self, f):
        self.db.execute("UPDATE facts SET status=?, correction_of=?, polarity=?, privacy=?, confidence=? WHERE fid=?",
                        (f.status, f.correction_of, f.polarity, f.privacy, float(f.confidence), f.fact_id))

    def _touch_entity(self, e):
        self.db.execute("UPDATE entities SET label=?, aliases=? WHERE eid=?",
                        (e.label, json.dumps(list(e.aliases), ensure_ascii=False), e.entity_id))
        if e.kind == "concept":
            self._dirty_lemma.add(e.entity_id)

    def _touch_evidence(self, rec):
        self._write_evidence(rec)
        self._vc.put(rec.proposition_key, rec)

    # ---- derived indexes are SQL indexes: the shared logic's index maintenance becomes a no-op
    def _index_alias(self, kind, alias, eid):
        self._alias_seq += 1
        self.db.execute("INSERT OR IGNORE INTO aliases VALUES(?,?,?,?)", (alias_norm(kind, alias), kind, eid, self._alias_seq))

    def _index_canonical_add(self, key):
        pass

    def _index_canonical_remove(self, key, fid=None):
        pass

    def _index_evidence_record(self, rec):
        pass

    def _rebuild_compiled_indexes(self):
        pass

    def _relation_in_use(self, r):
        return self.canonical.has_relation(r)

    # ---- reads in one query each
    def resolve(self, label, kind=None):
        if kind is not None:
            return self.alias_index.get((kind, alias_norm(kind, label)))
        hits = {r[0] for r in self.db.execute("SELECT DISTINCT eid FROM aliases WHERE akey=? AND kind NOT IN (?,?,?) LIMIT 2",
                                              (norm(label),) + _STRICT)}
        hits.update(r[0] for r in self.db.execute("SELECT DISTINCT eid FROM aliases WHERE akey=? AND kind IN (?,?,?) LIMIT 2",
                                                  (norm_exact(label),) + _STRICT))
        return next(iter(hits)) if len(hits) == 1 else None

    def label(self, eid):
        e = self._entity(eid)
        return e.label if e is not None else eid

    def _canon_facts(self, where, params, viewer, principal, polarity, scope=None):
        out = []
        for f in self._iter_facts(_FACT_SELECT + "canonical c JOIN facts f ON f.fid=c.fid WHERE " + where, params):
            if (polarity is None or f.polarity == polarity) and self._visible(f, viewer, principal, scope=scope):
                out.append(f)
        out.sort(key=lambda f: f.order)
        return out

    def get_all(self, subject, relation, *, viewer="SELF", principal="SELF", polarity="POS", scope=None):
        return self._canon_facts("c.subject=? AND c.relation=? AND c.principal=?", (subject, rel_norm(relation), principal),
                                 viewer, principal, polarity, scope)

    def facts_about(self, subject, *, viewer="SELF", principal="SELF", polarity=None, scope=None):
        return self._canon_facts("c.subject=? AND c.principal=?", (subject, principal), viewer, principal, polarity, scope)

    def reverse_facts(self, relation, object_value, *, object_kind="literal", viewer="SELF", principal="SELF", polarity="POS", scope=None):
        return self._canon_facts("c.relation=? AND c.principal=? AND c.object_kind=? AND c.object_value=?",
                                 (rel_norm(relation), principal, object_kind, str(object_value)), viewer, principal, polarity, scope)

    def facts_with_relation(self, relation, *, viewer="SELF", principal="SELF", polarity="POS", scope=None):
        return self._canon_facts("c.relation=? AND c.principal=?", (rel_norm(relation), principal), viewer, principal, polarity, scope)

    def _active_sql(self, viewer, principal, origin, exclude_relations):
        vis, vp = _visible_sql(viewer, principal)
        where = vis + " AND f.principal=?"
        params = list(vp) + [principal]
        if origin == "USER_SAID":
            where += " AND f.origin='USER_SAID'"          # literal: lets SQLite use the partial index facts_user
        elif origin is not None:
            where += " AND f.origin=?"
            params.append(origin)
        ex = sorted(set(exclude_relations or ()))
        if ex:
            where += " AND f.relation NOT IN (" + ",".join("?" * len(ex)) + ")"
            params += ex
        return where, params

    def active_facts(self, *, viewer="SELF", principal="SELF", origin=None, exclude_relations=(), newest_first=False,
                     limit=None, lazy=False):
        where, params = self._active_sql(viewer, principal, origin, exclude_relations)
        sql = _FACT_SELECT + "facts f WHERE " + where + " ORDER BY f.ord " + ("DESC" if newest_first else "ASC")
        if limit is not None:
            sql += " LIMIT ?"
            params = params + [int(limit)]
        it = self._iter_facts(sql, tuple(params))
        if getattr(self,'constitutional_mode',LEGACY)==STRICT:
            it=(f for f in it if self._visible(f,viewer,principal,scope=KNOWLEDGE))
        return it if lazy else list(it)

    def count_active(self, *, viewer="SELF", principal="SELF", origin=None, exclude_relations=()):
        if getattr(self,'constitutional_mode',LEGACY)==STRICT:
            return len(self.active_facts(viewer=viewer,principal=principal,origin=origin,exclude_relations=exclude_relations))
        where, params = self._active_sql(viewer, principal, origin, exclude_relations)
        return self.db.execute("SELECT COUNT(*) FROM facts f WHERE " + where, tuple(params)).fetchone()[0]

    def top_subjects(self, *, viewer="SELF", principal="SELF", exclude_relations=(), limit=80):
        if getattr(self,'constitutional_mode',LEGACY)==STRICT:
            from collections import Counter
            return Counter(f.subject for f in self.active_facts(viewer=viewer,principal=principal,exclude_relations=exclude_relations)).most_common(limit)
        where, params = self._active_sql(viewer, principal, None, exclude_relations)
        rows = self.db.execute("SELECT f.subject, COUNT(*) AS n, MIN(f.frow) AS first FROM facts f WHERE " + where +
                               " GROUP BY f.subject ORDER BY n DESC, first ASC LIMIT ?", tuple(params) + (int(limit),))
        return [(s, n) for s, n, _ in rows]

    def subject_count(self, *, viewer="SELF", principal="SELF", exclude_relations=()):
        if getattr(self,'constitutional_mode',LEGACY)==STRICT:
            return len({f.subject for f in self.active_facts(viewer=viewer,principal=principal,exclude_relations=exclude_relations)})
        where, params = self._active_sql(viewer, principal, None, exclude_relations)
        return self.db.execute("SELECT COUNT(DISTINCT f.subject) FROM facts f WHERE " + where, tuple(params)).fetchone()[0]

    # ---- persistence
    def meta_get(self, key, default=None):
        r = self.db.execute("SELECT value FROM meta WHERE key=?", (key,)).fetchone()
        return default if r is None else r[0]

    def meta_put(self, key, value):
        self.db.execute("INSERT INTO meta VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value", (key, str(value)))

    def runtime_state(self):
        """The living runtime's own state kept in this file: the imported block, overlaid by parts saved per turn."""
        raw = self.meta_get("runtime_state")
        state = json.loads(raw) if raw else {}
        for k, v in self.db.execute("SELECT key, value FROM meta WHERE key LIKE 'rs:%'"):
            state[k[3:]] = json.loads(v)
        return state or None

    def _write_graph_meta(self):
        sf = _field_names(RelationSpec)
        self.meta_put("order", int(self.order))
        self.meta_put("lexicon_revision", int(self.lexicon_revision))
        self.meta_put("constitutional_mode", getattr(self,"constitutional_mode","LEGACY"))
        self.meta_put("constitution_version", getattr(self,"constitution_version","C4_CONSTITUTION_V1"))
        self.meta_put("relation_templates", json.dumps(sorted(self.relation_templates), ensure_ascii=False))
        self.meta_put("relation_specs", json.dumps([{n: getattr(x, n) for n in sf} for x in self.relation_specs.values()],
                                                   ensure_ascii=False))

    def flush(self, *, runtime_state=None, **meta):
        """End of a turn: graph meta (+ the runtime's own state) and every change since the last flush in one commit."""
        self._write_graph_meta()
        if runtime_state is not None:
            self.meta_put("runtime_state", json.dumps(runtime_state, ensure_ascii=False, separators=(",", ":")))
        for k, v in meta.items():
            if v is not None:
                self.meta_put(k, json.dumps(v, ensure_ascii=False, separators=(",", ":")))
        self.db.commit()

    def rollback(self):
        """Forget uncommitted changes (cached objects are dropped, the next read comes from disk)."""
        self.db.rollback()
        self._fc, self._ec, self._vc = _Cache(self._fc.size), _Cache(self._ec.size), _Cache(self._vc.size)
        self._load_state()

    def close(self):
        try:
            self.flush()
        finally:
            self.db.close()

    def stats(self):
        out = super().stats()
        out["store"] = "sqlite"
        out["db_path"] = self.path
        return out

    def to_dict(self):
        d = super().to_dict()
        d["audit"] = list(self.audit)
        return d

    def rebuild_evidence_from_facts(self):
        """C4Graph.rebuild_evidence_from_facts for old checkpoints, streamed from the facts table (same records)."""
        return self.rebuild_evidence_from_facts_sql()

    def rebuild_evidence_from_facts_sql(self):
        self.db.execute("DELETE FROM evidence")
        recs: Dict[str, EvidenceRecord] = {}
        for f in self._iter_facts(_FACT_SELECT + "facts f ORDER BY f.ord, f.frow", ()):
            pk = self._prop_key(f.subject, f.relation, f.object_kind, f.object_value, f.polarity, f.principal)
            rec = recs.get(pk)
            if rec is None:
                rec = EvidenceRecord(pk, 0, {}, f.subject, f.relation, f.object_kind, f.object_value, f.polarity, f.principal)
                recs[pk] = rec
            group = str(f.source_ref or f"{f.origin}:{f.principal}")
            src = rec.sources.get(group)
            if src is None:
                src = EvidenceSource(group, f.origin, f.authority, 0, 0.0, f.order, f.order)
                rec.sources[group] = src
            src.count += 1
            src.max_confidence = max(src.max_confidence, float(f.confidence))
            src.last_order = f.order
            rec.total_count += 1
        for rec in recs.values():
            self._write_evidence(rec)
        self._vc = _Cache(self._vc.size)
        self._n_evidence = len(recs)
        return len(recs)

    @classmethod
    def from_dict(cls, d, path=":memory:"):
        g = cls(path)
        g._load_dict(d)
        return g

    def _load_dict(self, d):
        """C4Graph.from_dict into this (empty) disk graph."""
        _bulk_load_part(self, entities=d.get("entities", []))
        _bulk_load_part(self, facts=d.get("facts", []))
        _bulk_load_part(self, canonical=d.get("canonical", []))
        if "evidence" in d:
            _bulk_load_part(self, evidence=d.get("evidence") or [])
        _bulk_load_part(self, audit=d.get("audit", []))
        self.db.execute("UPDATE canonical SET object_kind=(SELECT object_kind FROM facts WHERE facts.fid=canonical.fid), "
                        "object_value=(SELECT object_value FROM facts WHERE facts.fid=canonical.fid)")
        _finish_load(self, {"relation_specs": d.get("relation_specs", []), "relation_templates": d.get("relation_templates", []),
                            "order": d.get("order", 0)})
        self.constitutional_mode=str(d.get("constitutional_mode","LEGACY")).upper()
        self.constitution_version=d.get("constitution_version","C4_CONSTITUTION_V1")
        self.meta_put("constitutional_mode",self.constitutional_mode);self.meta_put("constitution_version",self.constitution_version)
        if "evidence" not in d:
            self.rebuild_evidence_from_facts_sql()
        self.db.commit()
        from .fact_retrieval import build_sqlite_index
        build_sqlite_index(self)            # as after an import: the text and lemma index covers what was loaded


# ---------------------------------------------------------------- bulk load (dict or streamed checkpoint)
# ---------------------------------------------------------------- streaming JSON (bounded memory import)
class _JSONStream:
    def __init__(self, fh, chunk=1 << 20):
        self.fh, self.chunk = fh, chunk
        self.buf, self.pos, self.eof = "", 0, False
        self.dec = json.JSONDecoder()

    def _fill(self):
        if self.eof:
            return False
        data = self.fh.read(self.chunk)
        if not data:
            self.eof = True
            return False
        self.buf = self.buf[self.pos:] + data
        self.pos = 0
        return True

    def _ws(self):
        while True:
            while self.pos < len(self.buf) and self.buf[self.pos] in " \t\r\n":
                self.pos += 1
            if self.pos < len(self.buf) or not self._fill():
                return

    def peek(self):
        self._ws()
        return self.buf[self.pos] if self.pos < len(self.buf) else ""

    def take(self, ch):
        if self.peek() != ch:
            raise ValueError(f"expected {ch!r} at {self.pos}, got {self.peek()!r}")
        self.pos += 1

    def value(self):
        while True:
            self._ws()
            try:
                obj, end = self.dec.raw_decode(self.buf, self.pos)
                if end >= len(self.buf) and not self.eof and not isinstance(obj, (dict, list, str)):
                    raise ValueError("number may continue")
                self.pos = end
                return obj
            except ValueError:
                if not self._fill():
                    raise

    def array(self):
        self.take("[")
        if self.peek() == "]":
            self.pos += 1
            return
        while True:
            yield self.value()
            c = self.peek()
            self.pos += 1
            if c == "]":
                return
            if c != ",":
                raise ValueError(f"bad array separator {c!r}")

    def members(self):
        """Top-level object: (key, value) for scalars, (key, generator) for arrays (consume before the next key)."""
        self.take("{")
        if self.peek() == "}":
            self.pos += 1
            return
        while True:
            key = self.value()
            self.take(":")
            if self.peek() == "[":
                gen = self.array()
                yield key, gen
                for _ in gen:       # unconsumed rest
                    pass
            else:
                yield key, self.value()
            c = self.peek()
            self.pos += 1
            if c == "}":
                return
            if c != ",":
                raise ValueError(f"bad object separator {c!r}")


def _stream_member(z: ZipFile, name: str):
    raw = z.open(name)
    st = _JSONStream(io.TextIOWrapper(raw, encoding="utf-8"))
    st.raw, st.size = raw, max(1, z.getinfo(name).file_size)
    return st


def sha256_file(path, chunk=1 << 20):
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        while True:
            b = fh.read(chunk)
            if not b:
                return h.hexdigest()
            h.update(b)


def import_c4m(c4m_path, db_path, *, with_cold=True, build_index=True, progress=None) -> SQLiteGraph:
    """Stream a compact .c4m checkpoint into a new .c4db (bounded memory). The source file is only read.

    progress(stage, fraction) is called while it works: stage 'graph' / 'history' / 'index' / 'done', fraction 0..1."""
    t0 = time.time()
    tmp = str(db_path) + ".importing"
    for p in (tmp, tmp + "-wal", tmp + "-shm"):
        if os.path.exists(p):
            os.remove(p)
    g = SQLiteGraph(tmp)
    db = g.db
    db.execute("PRAGMA synchronous=OFF")
    db.execute("PRAGMA temp_store=FILE")          # sorting millions of index rows must not happen in RAM
    with ZipFile(c4m_path) as z:
        man = json.loads(z.read("manifest.json"))
        files = set(man.get("files", []))
        parts = {}
        st = _stream_member(z, "graph_hot.json" if "graph_hot.json" in files else "graph.json")
        tick = (lambda: progress("graph", 0.75 * min(1.0, st.raw.tell() / st.size))) if progress else None

        # members arrive in sorted key order: audit, canonical, entities, evidence, facts, order, relation_*, schema
        for key, val in st.members():
            if key == "entities":
                _bulk_load_part(g, entities=val, tick=tick)
            elif key == "facts":
                _bulk_load_part(g, facts=val, tick=tick)
            elif key == "canonical":
                _bulk_load_part(g, canonical=val, tick=tick)
            elif key == "evidence":
                _bulk_load_part(g, evidence=val, tick=tick)
                parts["evidence"] = True
            elif key == "audit":
                _bulk_load_part(g, audit=val, tick=tick)
            else:
                parts[key] = list(val) if not isinstance(val, (str, int, float, dict, type(None))) else val
        if with_cold and "cold/history.json" in files:
            cs = _stream_member(z, "cold/history.json")
            ctick = (lambda: progress("history", 0.75 + 0.05 * min(1.0, cs.raw.tell() / cs.size))) if progress else None
            for key, val in cs.members():
                if key == "facts":
                    _bulk_load_part(g, facts=val, tick=ctick)
                elif key == "audit":
                    _bulk_load_part(g, audit=val, tick=ctick)
        rs = z.read("runtime_state.json").decode("utf-8") if "runtime_state.json" in files else None
        h3 = z.read("h3_templates.json").decode("utf-8") if "h3_templates.json" in files else None
        organs = {n[len("organs/"):-len(".json")]: json.loads(z.read(n)) for n in files if n.startswith("organs/") and n.endswith(".json")}
    db.execute("UPDATE canonical SET object_kind=(SELECT object_kind FROM facts WHERE facts.fid=canonical.fid), "
               "object_value=(SELECT object_value FROM facts WHERE facts.fid=canonical.fid)")
    _finish_load(g, parts)
    if not parts.get("evidence"):
        g.rebuild_evidence_from_facts_sql()
    if rs is not None:
        g.meta_put("runtime_state", rs)
    if h3 is not None:
        g.meta_put("h3", h3)
    g.meta_put("ckpt_meta", json.dumps(man.get("meta") or {}, ensure_ascii=False))
    g.meta_put("organs", json.dumps(organs, ensure_ascii=False))
    g.meta_put("source_c4m_sha256", sha256_file(c4m_path))
    g.meta_put("source_c4m_name", os.path.basename(str(c4m_path)))
    db.commit()
    if build_index:
        from .fact_retrieval import build_sqlite_index
        if progress:
            progress("index", 0.8)
        build_sqlite_index(g, progress=(lambda f: progress("index", 0.8 + 0.2 * f)) if progress else None)
    db.execute("PRAGMA synchronous=NORMAL")
    db.execute("ANALYZE")
    g.meta_put("import_sec", round(time.time() - t0, 2))
    db.commit()
    db.close()
    for p in (str(db_path), str(db_path) + "-wal", str(db_path) + "-shm"):
        if os.path.exists(p):
            os.remove(p)
    os.replace(tmp, db_path)
    for p in (tmp + "-wal", tmp + "-shm"):
        if os.path.exists(p):
            os.remove(p)
    if progress:
        progress("done", 1.0)
    return SQLiteGraph(db_path)


def _bulk_load_part(g, *, entities=None, facts=None, canonical=None, evidence=None, audit=None, batch=5000, tick=None):
    """One streamed array of the checkpoint into its table (same row semantics as _bulk_load)."""
    db = g.db
    if entities is not None:
        ent_rows, alias_rows = [], []

        def fl():
            db.executemany("INSERT OR IGNORE INTO entities(eid,kind,label,aliases,created_order) VALUES(?,?,?,?,?)", ent_rows)
            db.executemany("INSERT INTO aliases VALUES(?,?,?,?) ON CONFLICT(akey,kind,eid) DO UPDATE SET seq=excluded.seq", alias_rows)
            ent_rows.clear()
            alias_rows.clear()

        for x in entities:
            ent_rows.append((x["entity_id"], x["kind"], x["label"], json.dumps(list(x["aliases"]), ensure_ascii=False), int(x["created_order"])))
            for a in x["aliases"]:
                g._alias_seq += 1
                alias_rows.append((alias_norm(x["kind"], a), x["kind"], x["entity_id"], g._alias_seq))
            if len(ent_rows) >= batch:
                fl()
                if tick:
                    tick()
        fl()
    if facts is not None:
        rows = []
        for x in facts:
            rows.append((x["fact_id"], x["subject"], x["relation"], x["object_kind"], str(x["object_value"]), x.get("origin"),
                         x.get("principal"), x.get("privacy"), x.get("status"), x.get("authority"), x.get("confidence"),
                         x.get("order"), x.get("source_ref"), x.get("correction_of"), x.get("polarity", "POS"),
                         x.get("source_group")))
            if len(rows) >= batch:
                if tick:
                    tick()
                db.executemany("INSERT OR IGNORE INTO facts(fid,subject,relation,object_kind,object_value,origin,principal,privacy,status,authority,confidence,ord,source_ref,correction_of,polarity,source_group) VALUES(" + ",".join("?" * 16) + ")", rows)
                rows.clear()
        db.executemany("INSERT OR IGNORE INTO facts(fid,subject,relation,object_kind,object_value,origin,principal,privacy,status,authority,confidence,ord,source_ref,correction_of,polarity,source_group) VALUES(" + ",".join("?" * 16) + ")", rows)
    if canonical is not None:
        rows = []
        for row in canonical:
            s, r, p, slot, fid = (row[0], row[1], row[2], "*", row[3]) if len(row) == 4 else row
            rows.append((s, r, p, slot, fid))
            if len(rows) >= batch:
                if tick:
                    tick()
                db.executemany("INSERT INTO canonical(subject,relation,principal,slot,fid) VALUES(?,?,?,?,?) ON CONFLICT(subject,relation,principal,slot) DO UPDATE SET fid=excluded.fid", rows)
                rows.clear()
        db.executemany("INSERT INTO canonical(subject,relation,principal,slot,fid) VALUES(?,?,?,?,?) ON CONFLICT(subject,relation,principal,slot) DO UPDATE SET fid=excluded.fid", rows)
    if evidence is not None:
        rows = []
        for x in evidence:
            src = _sources_to_json({k: EvidenceSource(**v) for k, v in (x.get("sources") or {}).items()})
            rows.append((x["proposition_key"], x.get("subject", ""), x.get("relation", ""), x.get("principal", ""),
                         x.get("object_kind", ""), x.get("object_value", ""), x.get("polarity", "POS"),
                         int(x.get("total_count", 0)), src))
            if len(rows) >= batch:
                if tick:
                    tick()
                db.executemany("INSERT INTO evidence(pk,subject,relation,principal,object_kind,object_value,polarity,total_count,sources) "
                               "VALUES(?,?,?,?,?,?,?,?,?) ON CONFLICT(pk) DO UPDATE SET total_count=excluded.total_count, sources=excluded.sources", rows)
                rows.clear()
        db.executemany("INSERT INTO evidence(pk,subject,relation,principal,object_kind,object_value,polarity,total_count,sources) "
                               "VALUES(?,?,?,?,?,?,?,?,?) ON CONFLICT(pk) DO UPDATE SET total_count=excluded.total_count, sources=excluded.sources", rows)
    if audit is not None:
        rows = []
        for x in audit:
            rows.append((json.dumps(x, ensure_ascii=False),))
            if len(rows) >= batch:
                if tick:
                    tick()
                db.executemany("INSERT INTO audit(rec) VALUES(?)", rows)
                rows.clear()
        db.executemany("INSERT INTO audit(rec) VALUES(?)", rows)


def _finish_load(g, parts):
    db = g.db
    for x in parts.get("relation_specs") or ():
        spec = RelationSpec(**x)
        g.relation_specs[spec.relation] = spec
    g.relation_templates = set(parts.get("relation_templates") or ())
    g.order = int(parts.get("order", 0))
    from .constitution import LEGACY, CONSTITUTION_VERSION
    g.constitutional_mode=str(parts.get("constitutional_mode",LEGACY)).upper()
    g.constitution_version=parts.get("constitution_version",CONSTITUTION_VERSION)
    g.lexicon_revision = db.execute("SELECT COUNT(*) FROM facts WHERE relation='WORD_FORM' AND status IN " + _ACTIVE_SQL).fetchone()[0]
    for name, attr in (("facts", "_n_facts"), ("entities", "_n_entities"), ("canonical", "_n_canon"),
                       ("evidence", "_n_evidence"), ("audit", "_n_audit")):
        setattr(g, attr, db.execute(f"SELECT COUNT(*) FROM {name}").fetchone()[0])
    g._new_fids, g._dirty_lemma = [], set()
    g._write_graph_meta()


# ---------------------------------------------------------------- streaming export (.c4db -> .c4m)
def _dump(obj) -> bytes:
    return json.dumps(obj, ensure_ascii=False, separators=(",", ":"), sort_keys=True).encode("utf-8")


class _HashingWriter:
    def __init__(self, fh):
        self.fh, self.h = fh, hashlib.sha256()

    def write(self, b: bytes):
        self.h.update(b)
        self.fh.write(b)


def _write_array(w, items):
    w.write(b"[")
    first = True
    for x in items:
        if not first:
            w.write(b",")
        w.write(_dump(x))
        first = False
    w.write(b"]")


def export_c4m(g: SQLiteGraph, c4m_path, *, runtime_state=None, h3=None, meta=None, organs=None, include_cold=True):
    """Write a compact .c4m checkpoint from the disk graph, streamed (bounded memory), atomically."""
    from .checkpoint import SCHEMA_COMPACT
    ef, ff, sf, vf = _field_names(Entity), _field_names(Fact), _field_names(RelationSpec), _field_names(EvidenceSource)
    db = g.db
    g.flush()
    active = "(fid IN (SELECT fid FROM canonical) OR status='SOURCE_ASSERTED')"

    def fact_dicts(where):
        for r in db.execute(_FACT_SELECT + "facts f WHERE " + where + " ORDER BY f.frow", ()):
            d = dict(zip(ff, (r[0], r[1], r[2], r[3], r[4], r[5], r[6], r[7], r[8], r[9], r[10], r[11], r[12], r[13], r[14], r[15])))
            yield d

    def entity_dicts():
        for r in db.execute("SELECT eid,kind,label,aliases,created_order FROM entities ORDER BY rid"):
            yield {"entity_id": r[0], "kind": r[1], "label": r[2], "aliases": json.loads(r[3]), "created_order": r[4]}

    def evidence_dicts():
        for r in db.execute("SELECT pk,subject,relation,principal,object_kind,object_value,polarity,total_count,sources "
                            "FROM evidence ORDER BY rid"):
            vf = _field_names(EvidenceSource)
            yield {"proposition_key": r[0], "total_count": r[7],
                   "sources": {k: {n: getattr(v, n) for n in vf} for k, v in _sources_from_json(r[8]).items()}, "subject": r[1],
                   "relation": r[2], "object_kind": r[4], "object_value": r[5], "polarity": r[6], "principal": r[3]}

    folder = os.path.dirname(os.path.abspath(str(c4m_path)))
    tmp = os.path.join(folder, "." + os.path.basename(str(c4m_path)) + ".tmp")
    if h3 is None:
        h3 = g.meta_get("h3")
    sha = {}
    with ZipFile(tmp, "w", ZIP_DEFLATED) as z:
        with z.open("graph_hot.json", "w", force_zip64=True) as fh:
            w = _HashingWriter(fh)
            w.write(b'{"audit":[],"canonical":')
            _write_array(w, ([s, r, p, slot, fid] for s, r, p, slot, fid in
                             db.execute("SELECT subject,relation,principal,slot,fid FROM canonical ORDER BY rid")))
            w.write(b',"entities":')
            _write_array(w, entity_dicts())
            w.write(b',"evidence":')
            _write_array(w, evidence_dicts())
            w.write(b',"facts":')
            _write_array(w, fact_dicts(active))
            w.write(b',"order":' + _dump(int(g.order)))
            if getattr(g,'constitutional_mode',LEGACY)!=LEGACY:
                w.write(b',"constitutional_mode":' + _dump(getattr(g,'constitutional_mode',LEGACY)))
                w.write(b',"constitution_version":' + _dump(getattr(g,'constitution_version','C4_CONSTITUTION_V1')))
            w.write(b',"relation_specs":' + _dump([{n: getattr(x, n) for n in sf} for x in g.relation_specs.values()]))
            w.write(b',"relation_templates":' + _dump(sorted(g.relation_templates)))
            w.write(b',"schema":"C4_GRAPH_L6_V0.3"}')
            sha["graph_hot.json"] = w.h.hexdigest()
        if include_cold:
            with z.open("cold/history.json", "w", force_zip64=True) as fh:
                w = _HashingWriter(fh)
                w.write(b'{"audit":')
                _write_array(w, iter(g.audit))
                w.write(b',"facts":')
                _write_array(w, fact_dicts("NOT " + active))
                w.write(b',"schema":"C4_GRAPH_COLD_HISTORY_V0.1"}')
                sha["cold/history.json"] = w.h.hexdigest()
        if isinstance(h3, str):
            hb = h3.encode("utf-8")
        else:
            from .dynamic_h3 import DynamicBoundTrace
            h3 = h3 or DynamicBoundTrace()
            hb = _dump({"schema": "H3_DYNAMIC_TEMPLATE_V0.1", "template": {"alpha": h3.t.alpha, "w0": h3.t.w0, "w1": h3.t.w1},
                        "transient_persisted": False})
        z.writestr("h3_templates.json", hb)
        sha["h3_templates.json"] = hashlib.sha256(hb).hexdigest()
        if runtime_state is None:
            runtime_state = g.runtime_state()
        rb = _dump(runtime_state) if runtime_state is not None else None
        if rb is not None:
            z.writestr("runtime_state.json", rb)
            sha["runtime_state.json"] = hashlib.sha256(rb).hexdigest()
        if organs is None:
            organs = json.loads(g.meta_get("organs", "{}") or "{}")
        for name, obj in (organs or {}).items():
            safe = str(name).strip().replace("..", "_").strip("/")
            ob = _dump(obj)
            z.writestr(f"organs/{safe}.json", ob)
            sha[f"organs/{safe}.json"] = hashlib.sha256(ob).hexdigest()
        if meta is None:
            meta = json.loads(g.meta_get("ckpt_meta", "{}") or "{}")
        manifest = {"schema": SCHEMA_COMPACT, "meta": meta, "files": sorted(sha), "sha256": sha, "cold_optional": include_cold}
        z.writestr("manifest.json", json.dumps(manifest, ensure_ascii=False, indent=2, sort_keys=True))
    os.replace(tmp, c4m_path)
    return manifest


def _personal_facts(g: SQLiteGraph):
    """What the person told the child (active USER_SAID facts), with the names of the things they are about."""
    out = []
    for f in g._iter_facts(_FACT_SELECT + "facts f WHERE f.status IN " + _ACTIVE_SQL + " AND f.origin='USER_SAID' ORDER BY f.ord, f.frow", ()):
        se = g._entity(f.subject)
        oe = g._entity(f.object_value) if f.object_kind == "entity" else None
        if se is None or (f.object_kind == "entity" and oe is None):
            continue
        out.append({"s": (se.label, se.kind, list(se.aliases)), "o": (oe.label, oe.kind, list(oe.aliases)) if oe else None,
                    "f": {n: getattr(f, n) for n in _field_names(Fact)}})
    return out


def _replay_personal(g: SQLiteGraph, items):
    for x in items:
        lab, kind, aliases = x["s"]
        sid = g.entity(lab, kind, aliases=[a for a in aliases if a != lab])
        f = x["f"]
        if x["o"] is not None:
            ol, ok, oa = x["o"]
            obj = g.entity(ol, ok, aliases=[a for a in oa if a != ol])
        else:
            obj = f["object_value"]
        g.commit(sid, f["relation"], obj, object_kind=f["object_kind"], origin=f["origin"], principal=f["principal"],
                 privacy=f["privacy"], authority=f["authority"], confidence=f["confidence"], source_ref=f["source_ref"],
                 source_group=f["source_group"], polarity=f["polarity"])


def open_or_import(path, *, db_path=None, progress=None) -> SQLiteGraph:
    """A .c4db opens directly. A .c4m is imported once into a sibling .c4db (re-imported if the .c4m changed).

    New weights never erase the conversation: what the person told the child (USER_SAID facts) is carried into
    the new store, and the previous store is kept as <name>.c4db.bak."""
    path = str(path)
    if path.endswith(".c4db"):
        return SQLiteGraph(path)
    db_path = str(db_path or ((path[:-4] if path.endswith(".c4m") else path) + ".c4db"))
    personal = None
    if os.path.exists(db_path):
        g = SQLiteGraph(db_path)
        if g.meta_get("source_c4m_sha256") == sha256_file(path):
            return g
        personal = _personal_facts(g)
        g.db.close()
        for suffix in ("", "-wal", "-shm"):
            if os.path.exists(db_path + suffix):
                os.replace(db_path + suffix, db_path + ".bak" + suffix)
    g = import_c4m(path, db_path, progress=progress)
    if personal:
        _replay_personal(g, personal)
        g.meta_put("carried_personal_facts", len(personal))
        g.flush()
    return g

from __future__ import annotations
from dataclasses import dataclass
from typing import Optional
from .graph import C4Graph
from .morphology_ru import RussianMorphologyV1
from .reasoner import StructuralReasoner

@dataclass
class PhraseProposal:
    subject:str
    relation:str
    object_kind:str
    object_value:str
    confidence:float
    explanation:str

class RussianTypedPhraseV1:
    """Bounded two-constituent semantic composer.

    It does not know individual colors/properties. It uses admitted type structure:
      modifier IS_A цвет    -> COLOR(head, modifier-label)
      modifier IS_A свойство -> PROPERTY(head, modifier-label)
    Parsing only proposes a relation. Persistence requires an explicit teaching act.
    """
    TYPE_TO_REL={'цвет':'COLOR','свойство':'PROPERTY'}
    def __init__(self,g:C4Graph,morph:Optional[RussianMorphologyV1]=None):
        self.g=g;self.morph=morph or RussianMorphologyV1(g);self.reasoner=StructuralReasoner(g)

    def _resolve(self,s):return self.g.resolve(s) or self.morph.resolve(s)
    def _is_type(self,eid,type_label,principal='USER'):
        tid=self.g.resolve(type_label)
        if not tid:return False
        return self.reasoner.evaluate_is_a(eid,tid,principal=principal,viewer=principal).value=='TRUE'

    def propose_all(self,text:str,principal='USER'):
        toks=[x for x in str(text).strip(' .!?').split() if x]
        if len(toks)<2:return []
        resolved=[]
        for t in toks:
            eid=self._resolve(t)
            if not eid:return []
            resolved.append((t,eid))
        typed=[];heads=[]
        for surface,eid in resolved:
            found=None
            for typ,rel in self.TYPE_TO_REL.items():
                if self._is_type(eid,typ,principal):
                    found=(typ,rel);break
            if found:typed.append((surface,eid,found[0],found[1]))
            else:heads.append((surface,eid))
        # Bounded noun phrase: exactly one non-modifier head and >=1 typed modifiers.
        if len(heads)!=1 or not typed:return []
        head=heads[0][1];out=[]
        seen=set()
        for surface,mod,typ,rel in typed:
            key=(rel,self.g.label(mod))
            if key in seen:continue
            seen.add(key)
            spec=self.g.relation_spec(rel)
            if spec.object_mode in {'entity','either'}:
                ok='entity';val=mod
            else:
                ok='literal';val=self.g.label(mod)
            out.append(PhraseProposal(head,rel,ok,val,1.0,f'{self.g.label(mod)} имеет тип {typ}; head={self.g.label(head)}'))
        return out

    def propose(self,text:str,principal='USER')->Optional[PhraseProposal]:
        xs=self.propose_all(text,principal)
        return xs[0] if len(xs)==1 else None


from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import Optional, Any
import re

from .language_ru import Intent
from .graph import norm


@dataclass
class DiscourseDecision:
    handled: bool
    kind: str = "PASS"
    reply: Optional[str] = None
    confidence: float = 0.0
    reason: str = ""
    normalized: Optional[str] = None

    def to_dict(self):
        return asdict(self)


class RussianDiscourseBridgeV1:
    """Contextual Russian dialogue bridge above the bounded semantic parser.

    This organ is intentionally conservative. It does not create world facts and it
    does not pretend that surface heuristics are semantic proof. Its job is to keep
    ordinary dialogue from collapsing directly from UNKNOWN into a single canned
    fallback when the utterance can be safely classified as a discourse act.

    World/knowledge claims are still owned by the existing semantic parsers and graph.
    """

    SCHEMA = "C4_RUSSIAN_DISCOURSE_BRIDGE_V1"

    _YES = {"да", "ага", "угу", "верно", "точно", "хорошо", "ок", "окей", "ладно"}
    _NO = {"нет", "неа", "не", "неверно"}
    _CONTINUE = {"давай", "продолжай", "дальше", "ещё", "еще", "говори"}
    _STOP = {"не надо", "хватит", "стоп", "остановись", "молчи"}
    _GREETING = {"привет", "здравствуй", "здравствуйте", "добрый день", "добрый вечер", "доброе утро", "хай"}
    _THANKS = {"спасибо", "благодарю", "спс"}
    _BYE = {"пока", "до свидания", "до встречи"}
    _USER_MISUNDERSTANDS = re.compile(
        r"^(?:я\s+)?(?:тебя\s+не\s+понимаю|не\s+понимаю\s+тебя|не\s+понял(?:а)?\s+тебя|не\s+понял(?:а)?[, ]+что\s+ты\s+(?:сказал(?:а)?|имеешь\s+в\s+виду))$",
        re.IGNORECASE,
    )
    _REPHRASE = re.compile(
        r"^(?:а\s+)?(?:как\s+(?:бы\s+)?ты\s+(?:это\s+)?(?:сказал(?:а)?|сформулировал(?:а)?|объяснил(?:а)?|переформулировал(?:а)?)(?:\s+по[- ]?человечески|\s+проще)?|(?:скажи|сформулируй|объясни|переформулируй)\s+(?:это\s+)?(?:проще|по[- ]?человечески))(?:\s*\?)?$",
        re.IGNORECASE,
    )

    _DISCOURSE_PRONOUNS = {
        "я","ты","тебя","тебе","тобой","меня","мне","мной","мой","моя","моё","мое","мои",
        "твой","твоя","твоё","твое","твои","мы","нас","нам","нами","вы","вас","вам","вами",
        "он","она","оно","они","его","ее","её","их","себя","себе","свой","своя","свои"
    }

    # Productive short first-person future/perfective responses to a request to teach/explain.
    # These are discourse-act cues, not stored world knowledge.
    _TEACH_RESPONSE = re.compile(
        r"^(?:я\s+)?(?:научу|объясню|расскажу|покажу|уточню|помогу|попробую\s+объяснить|попробую\s+научить)(?:\s+.+)?$",
        re.IGNORECASE,
    )

    _META_LANGUAGE = re.compile(
        r"^(?:а\s+)?(?:какие|какой|что\s+за|что)\s+"
        r"(?:фраз\w*|слов\w*|вопрос\w*|формулиров\w*|реплик\w*|выражени\w*)\s+"
        r"(?:ты\s+)?(?:знаешь|понимаешь|умеешь\s+понимать|можешь\s+понять)(?:\s*\?)?$",
        re.IGNORECASE,
    )
    _META_CAN = re.compile(
        r"^(?:а\s+)?(?:что|чего)\s+(?:ты\s+)?(?:умеешь|можешь)(?:\s+сейчас)?(?:\s*\?)?$",
        re.IGNORECASE,
    )
    _META_KNOW = re.compile(
        r"^(?:а\s+)?(?:что|чего)\s+(?:ты\s+)?знаешь(?:\s*\?)?$",
        re.IGNORECASE,
    )

    _WHY = re.compile(r"^(?:а\s+)?почему(?:\s+же)?\s*\??$", re.IGNORECASE)
    _WHAT_EXACT = re.compile(r"^(?:а\s+)?(?:что\s+именно|какие\s+именно|кто\s+именно|где\s+именно|когда\s+именно)\s*\??$", re.IGNORECASE)
    _AND_YOU = re.compile(r"^(?:а\s+)?ты\s*\??$", re.IGNORECASE)
    # G316: generic topic speech acts. The verb itself is NOT hardcoded; it must
    # resolve to an existing lexical action whose admitted semantics connect it
    # to communication. Surface form alone never authorizes the classification.
    _TOPIC_PROPOSAL = re.compile(r"^(?:давай|можем)\s+(?P<verb>[а-яёa-z-]+)\s+(?:про|о|об)\s+(?P<topic>.+)$", re.IGNORECASE)
    _TOPIC_QUERY = re.compile(r"^(?:а\s+)?(?:о|об|про)\s+чем\s+(?P<verb>[а-яёa-z-]+)$", re.IGNORECASE)
    _NICKNAME_PERMISSION = re.compile(r"^(?:можно\s+(?:я\s+)?буду|можно)\s+называть\s+тебя\s+.+$", re.IGNORECASE)
    _NICKNAME_DECLARATION = re.compile(r"^(?:я\s+)?буду\s+называть\s+тебя\s+.+$", re.IGNORECASE)

    def _clean(self, text: str) -> str:
        s = re.sub(r"\s+", " ", str(text).strip())
        return s.rstrip(".!?").strip().lower()

    def _last(self, history, speaker=None, kinds=None):
        for row in reversed(list(history or [])):
            if speaker is not None and row.get("speaker") != speaker:
                continue
            if kinds is not None and row.get("kind") not in kinds:
                continue
            return row
        return None

    def _last_c4(self, history):
        return self._last(history, speaker="C4")

    def _last_user(self, history):
        return self._last(history, speaker="USER")

    def _last_c4_requires_user(self, history):
        for row in reversed(list(history or [])):
            if row.get("speaker") != "C4":
                continue
            if row.get("requires_user") or row.get("kind") == "ASK":
                return row
            # A normal reply after the ask closes the immediate adjacency pair.
            if row.get("kind") == "REPLY":
                return None
        return None

    @staticmethod
    def _safe_surface_label(label: str) -> bool:
        x=str(label or "").strip()
        if not x:
            return False
        low=x.lower()
        if low in {"self","user","source","world"}:
            return False
        if re.search(r"(?:^|[_ -])g\d{2,}(?:[_ -]|$)", low):
            return False
        if re.search(r"\bnode(?:[_ -]?[a-z0-9]+)?\b", low):
            return False
        if low.startswith(("ent:","evt:","gap:","rule:","study:","source:")):
            return False
        return True

    def _known_mentions(self, text, dialogue, limit=5):
        """Read-only longest-ngram lookup without leaking discourse pronouns or internal IDs."""
        words = re.findall(r"[A-Za-zА-Яа-яЁё0-9_-]+", str(text))
        out=[];seen=set();max_n=min(4,len(words))
        for n in range(max_n,0,-1):
            for i in range(0,len(words)-n+1):
                toks=words[i:i+n]
                if all(t.lower() in self._DISCOURSE_PRONOUNS for t in toks):
                    continue
                surface=" ".join(toks)
                eid=dialogue.g.resolve(surface) or dialogue.morphology.resolve(surface)
                if not eid or eid in seen:
                    continue
                label=dialogue.g.label(eid)
                if not self._safe_surface_label(label):
                    continue
                seen.add(eid);out.append(label)
                if len(out)>=limit:return out
        return out

    def _resolve_existing(self,surface,dialogue):
        return dialogue.g.resolve(surface) or dialogue.morphology.resolve(surface) or dialogue.retriever.lemma(surface)

    def _is_communication_action(self,surface,dialogue):
        """Return the existing lexical eid only when graph semantics support a communication action."""
        eid=self._resolve_existing(surface,dialogue)
        if not eid:return None
        targets={x for x in (dialogue.g.resolve('общение'),dialogue.g.resolve('разговор'),dialogue.g.resolve('диалог'),dialogue.g.resolve('передача информации')) if x}
        for rel in ('USED_FOR','MEANS','IS_A'):
            for f in dialogue.g.get_all(eid,rel,viewer=dialogue.principal,principal=dialogue.principal):
                if f.object_kind=='entity' and f.object_value in targets:return eid
                txt=norm(dialogue.g.object_surface(f))
                if any(k in txt for k in ('общен','разговор','диалог','передач') ):return eid
        return None

    def _topic_speech_act(self,raw,dialogue):
        s=self._clean(raw)
        m=self._TOPIC_PROPOSAL.match(s)
        if m:
            veid=self._is_communication_action(m.group('verb'),dialogue)
            teid=self._resolve_existing(m.group('topic'),dialogue)
            if veid and teid:
                brief=dialogue._facts_brief(teid,limit=2)
                topic=dialogue.g.label(teid)
                reply=f"Давай. Тема — {topic}."+(f" {brief}" if brief else "")
                return DiscourseDecision(True,'PROPOSE_TOPIC',reply,0.96,'learned_communication_action_with_known_topic',normalized=topic)
        m=self._TOPIC_QUERY.match(s)
        if m:
            veid=self._is_communication_action(m.group('verb'),dialogue)
            if veid:
                # DRIVE may choose a recently available topic; the lexical action
                # that asks for a topic is not itself the topic. Context is AVAIL,
                # never evidence.
                exclude={veid,dialogue.g.resolve('глагол'),dialogue.g.resolve('общение'),dialogue.g.resolve('разговор'),dialogue.g.resolve('диалог')}
                for eid in reversed(getattr(dialogue,'context_eids',[]) or []):
                    if eid in dialogue.g.entities and eid not in {dialogue.user_eid,dialogue.self_eid} and eid not in exclude:
                        topic=dialogue.g.label(eid);brief=dialogue._facts_brief(eid,limit=2)
                        reply=f"Можем продолжить про {topic}."+(f" {brief}" if brief else "")
                        return DiscourseDecision(True,'TOPIC_CHOICE',reply,0.88,'drive_uses_available_recent_topic',normalized=topic)
                return DiscourseDecision(True,'TOPIC_OPEN','У меня сейчас нет выбранной темы. Можем выбрать её вместе.',0.85,'no_current_topic')
            return DiscourseDecision(True,'TOPIC_OPEN','У меня сейчас нет выбранной темы. Можем выбрать её вместе.',0.85,'no_current_topic')
        return None

    def _language_capability_reply(self):
        return (
            "Я понимаю не фиксированный список фраз. У меня есть несколько русских языковых механизмов: "
            "вопросы о знаниях и связях, утверждения, причинные вопросы, прошлые события, ссылки на контекст, "
            "часть местоимений и выученные отношения. Свободная разговорная речь пока шире моего парсера, "
            "поэтому если я не уверена в разборе, я должна это обозначить, а не выдавать непонимание за отсутствие знания."
        )

    def _capability_reply(self):
        return (
            "Сейчас я умею хранить и пересматривать структурированные знания, различать источник и наблюдение, "
            "делать ограниченные причинные и классовые выводы, работать с прошлым, неопределённостью и частью русского языка. "
            "Мои знания могут быть богаче, чем мой текущий разговорный разбор, поэтому непонятая формулировка не означает, что у меня нет нужного знания."
        )

    def interpret(self, text: str, core_intent: Intent, history, dialogue) -> DiscourseDecision:
        raw = str(text).strip()
        s = self._clean(raw)
        if not s:
            return DiscourseDecision(True, "EMPTY", "Я не получила содержательной фразы.", 1.0, "empty_surface")

        # Explicit discourse acts may override a false-positive semantic parse: they are
        # statements about the conversation itself, not world claims.
        if s in self._GREETING:
            return DiscourseDecision(True, "GREETING", "Привет.", 0.99, "social_greeting")
        if s in self._THANKS:
            return DiscourseDecision(True, "THANKS", "Пожалуйста.", 0.99, "social_thanks")
        if s in self._BYE:
            return DiscourseDecision(True, "FAREWELL", "До встречи.", 0.99, "social_farewell")
        if self._NICKNAME_PERMISSION.match(s):
            return DiscourseDecision(True,"NICKNAME_PERMISSION","Да, можешь.",0.97,"other_requests_social_naming_permission")
        if self._NICKNAME_DECLARATION.match(s):
            return DiscourseDecision(True,"NICKNAME_DECLARATION","Хорошо.",0.94,"other_announces_social_naming")
        if self._USER_MISUNDERSTANDS.match(s):
            prev=self._last_c4(history)
            if prev:
                return DiscourseDecision(True, "USER_MISUNDERSTANDS", "Поняла. Мой предыдущий ответ был непонятен. Могу сказать короче или объяснить конкретную часть.", 0.99, "user_reports_not_understanding_c4")
            return DiscourseDecision(True, "USER_MISUNDERSTANDS", "Поняла. Скажи, что именно было непонятно, и я попробую объяснить проще.", 0.98, "user_reports_not_understanding_c4_no_anchor")
        if self._REPHRASE.match(raw):
            return DiscourseDecision(True, "UNRESOLVED_QUESTION", "Понимаю, что это вопрос о переформулировке моей мысли по-человечески. Укажи фразу или предыдущий ответ, который нужно сказать проще.", 0.97, "rephrase_request")
        if self._META_LANGUAGE.match(raw):
            return DiscourseDecision(True, "META_LANGUAGE_CAPABILITY", self._language_capability_reply(), 0.98, "meta_language_query")
        if self._META_CAN.match(raw):
            return DiscourseDecision(True, "META_CAPABILITY", self._capability_reply(), 0.98, "meta_capability_query")
        if self._META_KNOW.match(raw):
            return DiscourseDecision(True,"META_KNOWLEDGE","Я знаю много отдельных структур и связей, но вопрос слишком широкий для полного вывода. Спроси о теме или объекте, и я покажу, что у меня с ним связано.",0.95,"meta_knowledge_query")

        topic_act=self._topic_speech_act(raw,dialogue)
        if topic_act is not None:return topic_act

        # Otherwise Claude's richer kernel-floor semantic parser/retriever gets priority.
        if core_intent is not None and core_intent.kind != "UNKNOWN":
            return DiscourseDecision(False)

        ask = self._last_c4_requires_user(history)

        # Adjacency-pair responses: agreement, rejection, continuation, stop.
        if s in self._YES:
            if ask:
                return DiscourseDecision(True, "ANSWER_ACK", "Хорошо. Продолжай.", 0.95, "short_affirmative_after_ask")
            return DiscourseDecision(True, "ACK", "Хорошо.", 0.92, "short_affirmative")
        if s in self._NO:
            if ask:
                return DiscourseDecision(True, "ANSWER_REJECT", "Поняла. Тогда не буду считать мой вопрос подтверждённым.", 0.95, "short_negative_after_ask")
            return DiscourseDecision(True, "REJECT", "Поняла.", 0.90, "short_negative")
        if s in self._CONTINUE:
            return DiscourseDecision(True, "CONTINUE", "Продолжаю.", 0.94, "continue_act")
        if s in self._STOP:
            return DiscourseDecision(True, "STOP", "Хорошо, остановилась.", 0.97, "stop_act")

        # Elliptical promise/offer to teach after C4 requested information.
        if self._TEACH_RESPONSE.match(s):
            if ask:
                return DiscourseDecision(True, "OFFER_TEACH", "Хорошо. Я слушаю.", 0.98, "elliptical_teaching_offer_after_ask")
            return DiscourseDecision(True, "OFFER_TEACH", "Хорошо. Скажи, чему именно хочешь меня научить.", 0.88, "teaching_offer_without_open_question")

        # Bare follow-ups obtain their meaning from prior discourse rather than from a standalone parser.
        if self._WHY.match(raw):
            prev = self._last_c4(history) or self._last_user(history)
            if prev:
                return DiscourseDecision(True, "WHY_FOLLOWUP", f"Ты спрашиваешь о причине предыдущего высказывания: «{prev.get('text','')}». Я могу объяснить только если у меня есть для него причинная или доказательная цепочка.", 0.83, "bare_why_context")
            return DiscourseDecision(True, "WHY_FOLLOWUP", "Не понимаю, к какому утверждению относится «почему». Уточни объект вопроса.", 0.98, "bare_why_no_context")
        if self._WHAT_EXACT.match(raw):
            if ask:
                return DiscourseDecision(True, "CLARIFY_FOLLOWUP", f"Я имела в виду мой предыдущий вопрос: «{ask.get('text','')}». Если он слишком общий, уточни нужную часть.", 0.92, "bare_clarification_after_ask")
            return DiscourseDecision(True, "CLARIFY_FOLLOWUP", "Нужна предыдущая тема, чтобы понять, что именно ты уточняешь.", 0.95, "bare_clarification_no_anchor")
        if self._AND_YOU.match(raw):
            return DiscourseDecision(True, "RECIPROCAL_FOLLOWUP", "Понимаю это как встречный вопрос ко мне, но мне нужна тема предыдущего вопроса, чтобы ответить точно.", 0.86, "reciprocal_ellipsis")

        # Unclassified language falls through to the kernel-floor retriever/verbalizer.
        # It can return related admitted knowledge or an honest language fallback while
        # preserving receipts and zero-mutation question semantics.
        return DiscourseDecision(False)

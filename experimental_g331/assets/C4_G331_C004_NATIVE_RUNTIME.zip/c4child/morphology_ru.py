from __future__ import annotations
from dataclasses import dataclass
from collections import defaultdict
from typing import Optional, Dict, Tuple, List, Set
import json
from .graph import C4Graph, norm

@dataclass(frozen=True)
class SuffixRule:
    lemma_suffix: str
    form_suffix: str
    support: int

class RussianMorphologyV1:
    """Conservative learned surface->lexeme resolver.

    Ground rules:
    - admitted WORD_FORM aliases are authoritative lexical bindings;
    - unseen forms may only be *proposed* by suffix transforms independently
      demonstrated by >= min_support different lexemes;
    - proposals never create aliases/facts;
    - if the best proposal is not unique, resolution stays UNKNOWN.

    This is intentionally not a full Russian morphological analyzer. It is a
    bounded child-stage mechanism that can grow from teacher-provided examples.
    """
    def __init__(self, graph:C4Graph, min_support:int=2, max_suffix:int=6):
        self.g=graph
        self.min_support=max(2,int(min_support))
        self.max_suffix=max(1,int(max_suffix))
        self._cache_revision=-1
        self._rules:List[SuffixRule]=[]

    @staticmethod
    def _lcp(a:str,b:str)->int:
        n=min(len(a),len(b));i=0
        while i<n and a[i]==b[i]:i+=1
        return i

    def _rebuild(self):
        rev=getattr(self.g,"lexicon_revision",self.g.order)
        # G270: a disk graph keeps the learned rules with the lexicon revision they were computed for.
        key=f"{self.min_support}|{self.max_suffix}|{rev}"
        if hasattr(self.g,"meta_get"):
            try:
                cached=json.loads(self.g.meta_get("morph_rules","null") or "null")
            except Exception:
                cached=None
            if cached and cached.get("key")==key:
                self._rules=[SuffixRule(a,b,int(n)) for a,b,n in cached["rules"]]
                self._cache_revision=rev
                return
        supports:Dict[Tuple[str,str],Set[str]]=defaultdict(set)
        # G270: only lexemes that have WORD_FORM facts can support a rule; ask for those facts directly.
        by_subject:Dict[str,list]=defaultdict(list)
        for f in self.g.facts_with_relation('WORD_FORM',viewer='USER',principal='USER'):
            by_subject[f.subject].append(f)
        for eid,fs in by_subject.items():
            e=self.g.entities.get(eid)
            if e is None or e.kind!='concept':
                continue
            lemma=norm(e.label)
            # WORD_FORM facts are durable evidence. Entity aliases may include
            # non-morphological names/synonyms, so do not infer rules from all aliases.
            for f in fs:
                form=norm(self.g.object_surface(f))
                if not form or form==lemma:continue
                k=self._lcp(lemma,form)
                # Require a lexical stem: tiny overlaps create dangerous rules.
                if k<2:continue
                ls=lemma[k:]; fs=form[k:]
                if len(ls)>self.max_suffix or len(fs)>self.max_suffix:continue
                # At least one side must change; empty suffixes are allowed only for
                # learned additions/removals with real multi-lexeme support.
                if ls==fs:continue
                supports[(ls,fs)].add(eid)
        self._rules=[SuffixRule(a,b,len(v)) for (a,b),v in supports.items() if len(v)>=self.min_support]
        # Prefer stronger and more specific evidence.
        self._rules.sort(key=lambda r:(r.support,len(r.form_suffix)+len(r.lemma_suffix)),reverse=True)
        self._cache_revision=getattr(self.g,"lexicon_revision",self.g.order)
        if hasattr(self.g,"meta_put"):
            self.g.meta_put("morph_rules",json.dumps({"key":key,"rules":[[r.lemma_suffix,r.form_suffix,r.support] for r in self._rules]},
                                                     ensure_ascii=False))

    @property
    def rules(self)->List[SuffixRule]:
        if self._cache_revision!=getattr(self.g,"lexicon_revision",self.g.order):self._rebuild()
        return self._rules

    def _is_explicit_verb(self,eid:str)->bool:
        # Productive verb morphology is allowed only for lexemes with explicit
        # verb evidence.  Russian nouns such as `сеть` also end in -ть; without
        # this guard a learned verb transform (-ть -> -ет/-ют/...) can turn real
        # surfaces like `сеет`/`сеют` into the noun `сеть`.
        if self.g.get(eid,'PREDICATE_RELATION',viewer='USER',principal='USER'):
            return True
        for f in self.g.get_all(eid,'IS_A',viewer='USER',principal='USER'):
            if f.object_kind=='entity' and norm(self.g.object_surface(f))=='глагол':
                return True
        return False

    def resolve(self,surface:str)->Optional[str]:
        # Exact admitted aliases always win.
        hit=self.g.resolve(surface,kind='concept')
        if hit:return hit
        s=norm(surface)
        candidates:Dict[str,Tuple[int,int]]= {}
        for r in self.rules:
            fs=r.form_suffix
            if fs:
                if not s.endswith(fs):continue
                stem=s[:-len(fs)]
            else:
                stem=s
            cand=stem+r.lemma_suffix
            eid=self.g.resolve(cand,kind='concept')
            if not eid:continue
            # Any productive transform that reconstructs an infinitive-like
            # suffix ending in -ть is verb morphology.  Require explicit verb
            # evidence on the candidate instead of guessing lexical POS from
            # orthography.  Exact aliases above remain unaffected.
            if r.lemma_suffix.endswith('ть') and not self._is_explicit_verb(eid):
                continue
            score=(r.support,len(r.form_suffix)+len(r.lemma_suffix))
            if eid not in candidates or score>candidates[eid]:candidates[eid]=score
        if not candidates:return None
        ranked=sorted(candidates.items(),key=lambda kv:kv[1],reverse=True)
        if len(ranked)>1 and ranked[0][1]==ranked[1][1]:return None
        return ranked[0][0]

    def explain(self,surface:str)->dict:
        exact=self.g.resolve(surface,kind='concept')
        if exact:return {'status':'EXACT','entity':exact,'label':self.g.label(exact)}
        eid=self.resolve(surface)
        return {'status':'PROPOSED' if eid else 'UNKNOWN','entity':eid,'label':self.g.label(eid) if eid else None,'rule_count':len(self.rules)}

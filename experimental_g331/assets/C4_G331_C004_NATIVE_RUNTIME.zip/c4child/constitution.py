from __future__ import annotations
from dataclasses import dataclass

STRICT = "STRICT"
LEGACY = "LEGACY"
CONSTITUTION_VERSION = "C4_CONSTITUTION_V1"

# These are explicit bases, not source labels. A source cannot mint one for itself.
COMMIT_BASES = {
    "EPISTEMIC_ADMISSION",
    "EPISTEMIC_REVALIDATION",
    "EPISTEMIC_RETRACTION",
    "VERIFIED_OBSERVATION",
    "VERIFIED_RECEIPT",
    "SYSTEM_MIGRATION",
    "SYSTEM_INVARIANT",
    "LANGUAGE_CONVENTION",
    "HUMAN_TEACHING",
    "SOCIAL_NAMING",
    "SOCIAL_SELF_REPORT",
    "SOCIAL_CORRECTION",
    "SOURCE_SELF_RETRACTION",
}

@dataclass(frozen=True)
class ConstitutionDecision:
    disposition: str   # COMMIT | CLAIM_ONLY | REJECT
    owner: str         # EVAL | COMMIT | DRIVE | MEDIATE
    influence: str     # MASK | VALUE | AVAIL | TRIGGER | STATUS
    reason: str


def evaluate_mutation(*, mode: str, operation: str, origin: str, authority: str,
                      constitutional_basis: str | None = None,
                      verified: bool = False) -> ConstitutionDecision:
    """Deterministic constitutional gate.

    This function does not infer truth and does not create abstractions. It only
    decides whether a proposed durable mutation has a lawful basis. In LEGACY
    mode old checkpoints/tests reproduce their historical behavior. New live
    candidates must explicitly enable STRICT.
    """
    if str(mode).upper() != STRICT:
        return ConstitutionDecision("COMMIT", "COMMIT", "STATUS", "LEGACY_REPLAY")

    basis = str(constitutional_basis or "").upper()
    op = str(operation).upper()
    org = str(origin or "").upper()
    auth = str(authority or "").upper()

    if basis in COMMIT_BASES:
        return ConstitutionDecision("COMMIT", "COMMIT", "STATUS", basis)

    # A verified boundary event may authorize a commit only when the caller marks
    # the boundary verification explicitly. Merely using origin=OBS/RECEIPT is not enough.
    if verified and org == "OBS":
        return ConstitutionDecision("COMMIT", "MEDIATE", "STATUS", "VERIFIED_OBSERVATION")
    if verified and org == "RECEIPT":
        return ConstitutionDecision("COMMIT", "MEDIATE", "STATUS", "VERIFIED_RECEIPT")

    # Retraction/forget is also a canonical mutation. A parser, user sentence or
    # source label cannot directly delete canonical state.
    if op == "FORGET":
        return ConstitutionDecision("REJECT", "COMMIT", "MASK", "NO_LAWFUL_RETRACTION_BASIS")

    # Ordinary source/corpus/user statements are still valuable: record them as
    # source assertions/evidence, but do not install them as world truth.
    if org in {"USER_SAID", "CREATOR_PRIOR", "EXTERNAL_CORPUS", "OBS", "RECEIPT"}:
        return ConstitutionDecision("CLAIM_ONLY", "EVAL", "STATUS", f"SOURCE_ASSERTION:{org}")

    # Unknown mutation origins do not acquire authority by omission.
    return ConstitutionDecision("CLAIM_ONLY", "EVAL", "STATUS", f"UNAUTHORIZED_ORIGIN:{org or auth or 'UNKNOWN'}")

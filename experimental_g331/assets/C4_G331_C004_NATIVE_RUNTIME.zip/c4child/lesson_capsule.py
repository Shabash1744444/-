from __future__ import annotations
from dataclasses import dataclass
from typing import Dict,Any,List
import json,hashlib
from .bootstrap import BootstrapTeacher

SCHEMA='C4_LESSON_CAPSULE_V0.1'

@dataclass
class LessonMetrics:
    semantic_events:int=0
    admitted:int=0
    dedup:int=0
    rejected:int=0
    surfaces:int=0
    probes:int=0
    sensory_anchors:int=0


def stable_lesson_id(title:str)->str:
    return 'lesson:'+hashlib.blake2s(title.encode('utf-8'),digest_size=10).hexdigest()


def validate_capsule(c:Dict[str,Any]):
    if c.get('schema')!=SCHEMA:raise ValueError('bad capsule schema')
    for k in ('lesson_id','title','origin','scope','semantic_events'):
        if k not in c:raise ValueError(f'missing {k}')
    if c['origin'] not in {'CREATOR_PRIOR','EXTERNAL_CORPUS','USER_SAID'}:
        raise ValueError('bad lesson origin')
    return True


def ingest_capsule(graph,capsule:Dict[str,Any],principal='USER')->LessonMetrics:
    validate_capsule(capsule)
    m=LessonMetrics()
    teacher=BootstrapTeacher(graph,principal=principal)
    events=[]
    for i,payload in enumerate(capsule.get('semantic_events',[])):
        ev={
            'schema':'C4_BOOTSTRAP_EVENT_V0.1',
            'event_id':f"{capsule['lesson_id']}:sem:{i}",
            'origin':capsule['origin'],
            'status':'ADMITTED',
            'scope':capsule['scope'],
            'authority':capsule.get('authority','TEACHER'),
            'confidence':float(payload.get('confidence',capsule.get('confidence',1.0))),
            'source_ref':f"{capsule['lesson_id']}:sem:{i}",
            'source_group':capsule['lesson_id'],
            'payload':{k:v for k,v in payload.items() if k!='confidence'},
        }
        events.append(ev)
    bm=teacher.ingest(events)
    m.semantic_events=bm.events;m.admitted=bm.admitted;m.dedup=bm.dedup;m.rejected=bm.rejected
    m.surfaces=len(capsule.get('surfaces',[]));m.probes=len(capsule.get('probes',[]));m.sensory_anchors=len(capsule.get('sensory_anchors',[]))
    return m


def save_capsule(path,c):
    validate_capsule(c)
    with open(path,'w',encoding='utf-8') as f:json.dump(c,f,ensure_ascii=False,indent=2)

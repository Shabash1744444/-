from __future__ import annotations
from dataclasses import dataclass
from typing import Iterable,Dict,Any
from .graph import C4Graph

@dataclass
class BootstrapMetrics:
    events:int=0
    admitted:int=0
    dedup:int=0
    rejected:int=0
    entities_before:int=0
    entities_after:int=0

class BootstrapTeacher:
    """Compiles explicit teacher events into the durable structural graph.
    It never upgrades teacher material to OBS/SELF_EXPERIENCE.
    """
    ALLOWED_ORIGINS={"CREATOR_PRIOR","USER_SAID","EXTERNAL_CORPUS","OBS","RECEIPT"}
    ADMIT_KINDS={"CLAIM","RELATION","CORRECTION"}
    def __init__(self,graph:C4Graph,principal="USER"):
        self.g=graph;self.principal=principal

    def ingest(self,events:Iterable[Dict[str,Any]])->BootstrapMetrics:
        m=BootstrapMetrics(entities_before=len(self.g.entities))
        for ev in events:
            m.events+=1
            try:self._one(ev,m)
            except (ValueError,KeyError,TypeError):m.rejected+=1
        m.entities_after=len(self.g.entities);return m

    def _one(self,ev,m):
        if ev.get("schema") not in {None,"C4_BOOTSTRAP_EVENT_V0.1"}:raise ValueError("bad event schema")
        origin=ev["origin"]
        if origin not in self.ALLOWED_ORIGINS:raise ValueError("bad origin")
        payload=ev["payload"];kind=payload["kind"]
        if kind not in self.ADMIT_KINDS:return
        scope=ev.get("scope",{});principal=scope.get("principal",self.principal);privacy=scope.get("privacy","PUBLIC")
        subj=payload["subject"];rel=payload["relation"];obj=payload["object"]
        sid=subj if subj in self.g.entities else self.g.entity(str(subj),"concept")
        spec=self.g.relation_spec(rel)
        explicit_kind=payload.get("object_kind")
        use_entity = explicit_kind=="entity" or (explicit_kind is None and spec.object_mode=="entity")
        if use_entity:
            oid=obj if obj in self.g.entities else self.g.entity(str(obj),payload.get("object_entity_kind","concept"))
            object_kind="entity";object_value=oid
        else:
            object_kind="literal";object_value=str(obj)
        before=len(self.g.facts)
        kw=dict(origin=origin,principal=principal,privacy=privacy,authority=ev.get("authority","TEACHER"),
                confidence=float(ev.get("confidence",1.0)),source_ref=ev.get("source_ref") or ev.get("event_id"),
                source_group=ev.get("source_group") or ev.get("source_ref") or ev.get("event_id"),
                constitutional_basis=ev.get("constitutional_basis"),verified=bool(ev.get("verified",False)))
        polarity=str(payload.get("polarity","POS")).upper()
        if kind=="CORRECTION":
            self.g.replace_relation(sid,rel,object_value,object_kind=object_kind,polarity=polarity,**kw)
        else:self.g.commit(sid,rel,object_value,object_kind=object_kind,polarity=polarity,**kw)
        if rel=="WORD_FORM" and object_kind=="literal":
            try:self.g.add_alias(sid,str(obj))
            except ValueError:pass
        if len(self.g.facts)==before:m.dedup+=1
        else:m.admitted+=1

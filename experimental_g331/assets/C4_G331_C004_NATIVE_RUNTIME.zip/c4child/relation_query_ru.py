from __future__ import annotations
import re
from .graph import C4Graph,rel_norm
from .morphology_ru import RussianMorphologyV1

class RussianRelationQueryV1:
    """Learned noun-of-relation query surface.

    Example durable lexical fact: QUERY_RELATION(цвет, COLOR).
    Then forms of `цвет` can drive questions such as `Какой цвет у мяча?`
    without a per-relation parser branch.
    """
    def __init__(self,g:C4Graph,morph:RussianMorphologyV1):self.g=g;self.morph=morph
    def _relation_from_surface(self,surface:str,principal='USER'):
        eid=self.g.resolve(surface) or self.morph.resolve(surface)
        if not eid:return None
        f=self.g.get(eid,'QUERY_RELATION',viewer=principal,principal=principal)
        if not f:return None
        return {'relation':rel_norm(f.object_value),'relation_entity':eid}

    def parse(self,text:str,principal='USER'):
        s=str(text).strip().rstrip('.!?')
        m=re.match(r'^как(?:ой|ая|ое|ие)\s+(.+?)\s+у\s+(.+)$',s,flags=re.IGNORECASE)
        if not m:return None
        rel_surface=m.group(1).strip();subject=m.group(2).strip()
        hit=self._relation_from_surface(rel_surface,principal)
        if not hit:return None
        return {'subject':subject,**hit}

    def question_shape(self,text:str):
        """Surface-only relation-noun question shape, even if the noun is unbound."""
        s=str(text).strip().rstrip('.!?')
        m=re.match(r'^как(?:ой|ая|ое|ие)\s+(.+?)\s+у\s+(.+)$',s,flags=re.IGNORECASE)
        if not m:return None
        return {'relation_surface':m.group(1).strip(),'subject':m.group(2).strip()}

    def parse_claim(self,text:str,principal='USER'):
        """Parse learned relation-noun assertions such as `цвет мяча — синий`.

        Relation identity comes only from durable QUERY_RELATION lexical knowledge.
        This method proposes structure; Dialogue still owns persistence/admission.
        """
        s=str(text).strip().rstrip('.!?')
        m=re.match(r'^(.+?)\s*(?:—|-|=|это)\s*(.+)$',s,flags=re.IGNORECASE)
        if not m:return None
        left=m.group(1).strip();obj=m.group(2).strip()
        toks=left.split()
        # Find the shortest learned relation-noun prefix; the rest is the subject.
        for i in range(1,len(toks)):
            rel_surface=' '.join(toks[:i]);subject=' '.join(toks[i:]).strip()
            hit=self._relation_from_surface(rel_surface,principal)
            if hit and subject and obj:
                return {'subject':subject,'object':obj,**hit}
        return None

    def parse_count(self,text:str,principal='USER'):
        s=str(text).strip().rstrip('.!?')
        m=re.match(r'^сколько\s+(.+?)\s+у\s+(.+)$',s,flags=re.IGNORECASE)
        if not m:return None
        hit=self._relation_from_surface(m.group(1).strip(),principal)
        if not hit:return None
        return {'subject':m.group(2).strip(),**hit}

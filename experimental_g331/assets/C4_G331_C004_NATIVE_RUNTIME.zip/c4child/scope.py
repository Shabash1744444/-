from __future__ import annotations

WORLD='WORLD'
KNOWLEDGE='KNOWLEDGE'
REFERENCE_KNOWLEDGE='REFERENCE_KNOWLEDGE'
HUMAN_TEACHING='HUMAN_TEACHING'
LANGUAGE_CONVENTION='LANGUAGE_CONVENTION'
SYSTEM_FACT='SYSTEM_FACT'
SOURCE_ASSERTION='SOURCE_ASSERTION'
OBSERVATION='OBSERVATION'
VERIFIED_OUTCOME='VERIFIED_OUTCOME'
SOCIAL_REPORT='SOCIAL_REPORT'

LANGUAGE_RELATIONS={
    'WORD_FORM','GRAM_GENDER','PREDICATE_RELATION','QUERY_RELATION',
    'PREDICATE_PRESENT_FORM','PREDICATE_PAST_FORM','LETTER_NAME','GROUNDS',
    'SYNONYM','ANTONYM','MEANS'
}
SYSTEM_RELATIONS={'FOUNDATIONAL','RULE'}
SOCIAL_RELATIONS={'NAME','LIKES','HAS','ROLE'}


def fact_scope(graph,f):
    """Derive epistemic scope from durable provenance without rewriting old weights.

    This is deliberately conservative. It is an overlay used to migrate old G309
    semantics before an explicit scope field is added to the storage schema.
    """
    if getattr(f,'status',None)=='SOURCE_ASSERTED':
        return SOURCE_ASSERTION
    auth=str(getattr(f,'authority','') or '').upper()
    origin=str(getattr(f,'origin','') or '').upper()
    rel=str(getattr(f,'relation','') or '').upper()
    sg=str(getattr(f,'source_group','') or '')

    if auth.startswith('EPISTEMIC_'):
        return WORLD
    if auth=='SOCIAL_REPORT':
        return SOCIAL_REPORT
    if rel in LANGUAGE_RELATIONS:
        return LANGUAGE_CONVENTION
    if rel in SYSTEM_RELATIONS:
        return SYSTEM_FACT
    if origin=='OBS':
        return OBSERVATION
    if origin=='RECEIPT':
        return VERIFIED_OUTCOME
    if origin=='EXTERNAL_CORPUS':
        return REFERENCE_KNOWLEDGE
    if origin=='CREATOR_PRIOR':
        return REFERENCE_KNOWLEDGE
    if origin=='USER_SAID':
        # Old guided-training answers were persisted with USER authority but with
        # the explicit USER:USER teaching source group. New strict live claims are
        # SOURCE_ASSERTED and were handled above.
        if auth=='TEACHER' or sg=='USER:USER':
            return HUMAN_TEACHING
        return SOURCE_ASSERTION
    return SOURCE_ASSERTION


def scope_allows(fscope,target):
    target=str(target or KNOWLEDGE).upper()
    if target=='ALL': return True
    if target==KNOWLEDGE:
        return fscope in {WORLD,REFERENCE_KNOWLEDGE,HUMAN_TEACHING,LANGUAGE_CONVENTION,SYSTEM_FACT,OBSERVATION,VERIFIED_OUTCOME,SOCIAL_REPORT}
    if target==WORLD:
        return fscope in {WORLD,OBSERVATION,VERIFIED_OUTCOME}
    if target==REFERENCE_KNOWLEDGE:
        return fscope in {REFERENCE_KNOWLEDGE,HUMAN_TEACHING,WORLD,OBSERVATION,VERIFIED_OUTCOME}
    if target==LANGUAGE_CONVENTION:
        return fscope==LANGUAGE_CONVENTION
    if target==SYSTEM_FACT:
        return fscope==SYSTEM_FACT
    if target==SOURCE_ASSERTION:
        return fscope==SOURCE_ASSERTION
    if target==OBSERVATION:
        return fscope==OBSERVATION
    if target==VERIFIED_OUTCOME:
        return fscope==VERIFIED_OUTCOME
    if target==HUMAN_TEACHING:
        return fscope==HUMAN_TEACHING
    if target==SOCIAL_REPORT:
        return fscope==SOCIAL_REPORT
    return False

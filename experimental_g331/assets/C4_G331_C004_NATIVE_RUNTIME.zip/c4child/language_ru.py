from __future__ import annotations
from dataclasses import dataclass
from typing import Optional
import re

@dataclass
class Intent:
    kind:str
    subject:Optional[str]=None
    relation:Optional[str]=None
    object:Optional[str]=None
    raw:str=""
    polarity:str="POS"

class RussianChildLanguageV0:
    """Bounded compositional Russian organ v0.2. Surface -> intent only; not truth storage."""
    def __init__(self): self.focus=None
    def _m(self,pat,s): return re.match(pat,s,flags=re.IGNORECASE)
    def parse(self,text:str)->Intent:
        raw=text.strip(); s=re.sub(r"\s+"," ",raw).rstrip(".!?")
        # meta/query commands first
        m=self._m(r"^(?:что ты знаешь (?:о|об|про) )(.+)$",s)
        if m:return Intent("ABOUT",subject=m.group(1).strip(),raw=raw)
        m=self._m(r"^(?:откуда ты знаешь(?:,? что)? )(.+)$",s)
        if m:return Intent("PROVENANCE",object=m.group(1).strip(),raw=raw)
        m=self._m(r"^(?:забудь|удали из памяти)[:,]?\s*(.+)$",s)
        if m:return Intent("FORGET_TEXT",object=m.group(1).strip(),raw=raw)
        m=self._m(r"^(?:исправь|нет,?\s*исправь)[:,]?\s*(.+)$",s)
        if m:
            inner=self.parse(m.group(1));inner.kind="CORRECT_"+inner.kind;inner.raw=raw;return inner
        m=self._m(r"^(?:запомни|помни)[:,]?\s*(.+)$",s)
        if m:
            inner=self.parse(m.group(1));inner.kind="REMEMBER_"+inner.kind;inner.raw=raw;return inner
        # G267: everyday question surfaces mapped onto EXISTING intents/relations (no new intent kinds).
        m=self._m(r"^как (меня|тебя|его|её|ее|их) зовут$",s)
        if m:return Intent("QUERY",subject=m.group(1),relation="NAME",raw=raw)
        if self._m(r"^(?:как (?:мне )?тебя (?:называть|звать)|как к тебе обращаться|как твоё имя|как твое имя|какое у тебя имя)$",s):
            return Intent("QUERY",subject="тебя",relation="NAME",raw=raw)
        if self._m(r"^(?:(?:кто ты|ты кто)(?: такой| такая)?(?: вообще| же| такой| такая)?|что ты такое|ты что такое|расскажи о себе|расскажи про себя)$",s):
            return Intent("ABOUT",subject="ты",raw=raw)
        m=self._m(r"^(?:расскажи|расскажите|поведай)(?: мне)?(?: подробнее| немного| что-нибудь| ещё| еще)? (?:о|об|обо|про) (.+)$",s)
        if m:return Intent("ABOUT",subject=m.group(1).strip(),raw=raw)
        m=self._m(r"^(?:что (?:ты |вы )?знаешь|что (?:ты |вы )?знаете|что известно|что ты помнишь|что ты думаешь|что ты считаешь) (?:о|об|обо|про) (.+)$",s)
        if m:return Intent("ABOUT",subject=m.group(1).strip(),raw=raw)
        m=self._m(r"^(?:для чего|зачем) (?:нужен|нужна|нужно|нужны|служит|служат|используют|используется|используются|применяют|применяется) (.+)$",s)
        if m:return Intent("QUERY",subject=m.group(1).strip(),relation="USED_FOR",raw=raw)
        m=self._m(r"^что (?:значит|означает|обозначает)(?: слово| выражение| фраза)? (.+)$",s)
        if m:return Intent("QUERY",subject=m.group(1).strip().strip('«»"'),relation="MEANS",raw=raw)
        m=self._m(r"^(?:какие|какое|каковы) (?:правила|правило|законы|принципы)(?: есть)? (?:у|для) (.+)$",s)
        if m:return Intent("QUERY",subject=m.group(1).strip(),relation="RULE",raw=raw)
        m=self._m(r"^какие у (.+?) (?:правила|законы|принципы)$",s)
        if m:return Intent("QUERY",subject=m.group(1).strip(),relation="RULE",raw=raw)
        if self._m(r"^(?:что ты умеешь|что ты можешь|что умеешь|что можешь)(?: делать)?$",s):
            return Intent("QUERY",subject="ты",relation="CAN",raw=raw)
        # bounded explanation of an is-a proposition
        m=self._m(r"^почему(?: ты считаешь,? что)? (.+?) (?:это|—|-|является) (.+)$",s)
        if m:return Intent("EXPLAIN_QUERY",subject=m.group(1).strip(),relation="IS_A",object=m.group(2).strip(),raw=raw)
        # truth-valued proposition questions
        m=self._m(r"^правда ли,? что (.+?) (?:вызывает|приводит к) (.+)$",s)
        if m:return Intent("CAUSAL_TRUTH_QUERY",subject=m.group(1).strip(),relation="CAUSES",object=m.group(2).strip(),raw=raw)
        m=self._m(r"^правда ли,? что (.+?) (?:это|—|-|является) (.+)$",s)
        if m:return Intent("TRUTH_QUERY",subject=m.group(1).strip(),relation="IS_A",object=m.group(2).strip(),raw=raw)
        m=self._m(r"^правда ли,? что (.+?) не (?:может|умеет) (.+)$",s)
        if m:return Intent("TRUTH_QUERY",subject=m.group(1).strip(),relation="CAN",object=m.group(2).strip(),raw=raw,polarity="NEG")
        m=self._m(r"^правда ли,? что (.+?) (?:может|умеет) (.+)$",s)
        if m:return Intent("TRUTH_QUERY",subject=m.group(1).strip(),relation="CAN",object=m.group(2).strip(),raw=raw)
        m=self._m(r"^правда ли,? что (.+?) используется для (.+)$",s)
        if m:return Intent("TRUTH_QUERY",subject=m.group(1).strip(),relation="USED_FOR",object=m.group(2).strip(),raw=raw)
        m=self._m(r"^правда ли,? что (.+?) имеет свойство (.+)$",s)
        if m:return Intent("TRUTH_QUERY",subject=m.group(1).strip(),relation="PROPERTY",object=m.group(2).strip(),raw=raw)
        m=self._m(r"^(?:что будет|что произойдёт|что произойдет),? если (.+)$",s)
        if m:return Intent("PREDICT_QUERY",subject=m.group(1).strip(),relation="CAUSES",raw=raw)
        m=self._m(r"^если (.+?),? (?:что будет|что произойдёт|что произойдет)$",s)
        if m:return Intent("PREDICT_QUERY",subject=m.group(1).strip(),relation="CAUSES",raw=raw)
        m=self._m(r"^(?:как|каким образом) (.+?) (?:приводит к|вызывает) (.+)$",s)
        if m:return Intent("CAUSE_CHAIN_QUERY",subject=m.group(1).strip(),relation="CAUSES",object=m.group(2).strip(),raw=raw)
        m=self._m(r"^почему (.+)$",s)
        if m:return Intent("CAUSE_QUERY",subject=m.group(1).strip(),relation="CAUSES",raw=raw)
        m=self._m(r"^(?:что является причиной|что вызывает) (.+)$",s)
        if m:return Intent("CAUSE_QUERY",subject=m.group(1).strip(),relation="CAUSES",raw=raw)
        m=self._m(r"^(?:к чему приводит|что происходит из-за) (.+)$",s)
        if m:return Intent("EFFECT_QUERY",subject=m.group(1).strip(),relation="CAUSES",raw=raw)
        # questions
        m=self._m(r"^(?:что может|что умеет)(?: делать)? (.+?)(?: делать)?$",s)
        if m:return Intent("QUERY",subject=m.group(1).strip(),relation="CAN",raw=raw)
        m=self._m(r"^что (.+?) (?:может|умеет|могут|умеют)(?: делать)?$",s)   # G267: «Что она может?»
        if m:return Intent("QUERY",subject=m.group(1).strip(),relation="CAN",raw=raw)
        m=self._m(r"^(?:что|кого) (?!.* не$)(.+?) (?:любит|любят)$",s)
        if m:return Intent("QUERY",subject=m.group(1).strip(),relation="LIKES",raw=raw)
        # G269: first/second person of the core predicates — the speaker and the child talk about themselves
        m=self._m(r"^что (я|ты) (?:люблю|любишь)$",s)
        if m:return Intent("QUERY",subject=m.group(1),relation="LIKES",raw=raw)
        m=self._m(r"^что я (?:умею|могу)(?: делать)?$",s)
        if m:return Intent("QUERY",subject="я",relation="CAN",raw=raw)
        m=self._m(r"^(?:для чего используется|зачем используют) (.+)$",s)
        if m:return Intent("QUERY",subject=m.group(1).strip(),relation="USED_FOR",raw=raw)
        m=self._m(r"^(?:какие свойства у|какое свойство у) (.+)$",s)
        if m:return Intent("QUERY",subject=m.group(1).strip(),relation="PROPERTY",raw=raw)
        patterns=[
            (r"^как зовут (.+)$","NAME"),
            (r"^(?:что любит|кого любит|что нравится|кто нравится) (.+)$","LIKES"),
            (r"^(?:где находится|где находятся|где расположен|где расположена|где расположено|где живёт|где живет|где лежит|где) (.+)$","LOCATION"),
            (r"^(?:что есть у|что у) (.+?)(?: есть)?$","HAS"),
            (r"^(?:кто такой|кто такая|что такое|что такой|что такая) (.+)$","IS_A"),
        ]
        for pat,rel in patterns:
            m=self._m(pat,s)
            if m:return Intent("QUERY",subject=m.group(1).strip(),relation=rel,raw=raw)
        # identity / property / relations
        m=self._m(r"^меня зовут (.+)$",s)
        if m:return Intent("CLAIM",subject="USER",relation="NAME",object=m.group(1).strip(),raw=raw)
        m=self._m(r"^тебя зовут (.+)$",s)
        if m:return Intent("CLAIM",subject="SELF",relation="NAME",object=m.group(1).strip(),raw=raw)
        m=self._m(r"^(я|ты) не (?:люблю|любишь) (.+)$",s)
        if m:return Intent("CLAIM",subject=m.group(1),relation="LIKES",object=m.group(2).strip(),raw=raw,polarity="NEG")
        m=self._m(r"^(я|ты) (?:очень |так |тоже |просто )?(?:люблю|любишь) (.+)$",s)
        if m:return Intent("CLAIM",subject=m.group(1),relation="LIKES",object=m.group(2).strip(),raw=raw)
        m=self._m(r"^(я|ты) не (?:умею|могу|умеешь|можешь) (.+)$",s)
        if m:return Intent("CLAIM",subject=m.group(1),relation="CAN",object=m.group(2).strip(),raw=raw,polarity="NEG")
        m=self._m(r"^(я|ты) (?:тоже |уже )?(?:умею|могу|умеешь|можешь) (.+)$",s)
        if m:return Intent("CLAIM",subject=m.group(1),relation="CAN",object=m.group(2).strip(),raw=raw)
        m=self._m(r"^(.+?) не (?:любит|любят) (.+)$",s)
        if m:return Intent("CLAIM",subject=m.group(1).strip(),relation="LIKES",object=m.group(2).strip(),raw=raw,polarity="NEG")
        m=self._m(r"^(.+?) (?:любит|любят) (.+)$",s)
        if m:return Intent("CLAIM",subject=m.group(1).strip(),relation="LIKES",object=m.group(2).strip(),raw=raw)
        m=self._m(r"^(.+?) (?:находится|расположен|расположена|расположено) (?:в|на) (.+)$",s)
        if m:return Intent("CLAIM",subject=m.group(1).strip(),relation="LOCATION",object=m.group(2).strip(),raw=raw)
        m=self._m(r"^у (.+?) есть (.+)$",s)
        if m:return Intent("CLAIM",subject=m.group(1).strip(),relation="HAS",object=m.group(2).strip(),raw=raw)
        m=self._m(r"^(.+?) не (?:может|умеет) (.+)$",s)
        if m:return Intent("CLAIM",subject=m.group(1).strip(),relation="CAN",object=m.group(2).strip(),raw=raw,polarity="NEG")
        m=self._m(r"^(.+?) (?:может|умеет) (.+)$",s)
        if m:return Intent("CLAIM",subject=m.group(1).strip(),relation="CAN",object=m.group(2).strip(),raw=raw)
        m=self._m(r"^(.+?) используется для (.+)$",s)
        if m:return Intent("CLAIM",subject=m.group(1).strip(),relation="USED_FOR",object=m.group(2).strip(),raw=raw)
        m=self._m(r"^(.+?) имеет свойство (.+)$",s)
        if m:return Intent("CLAIM",subject=m.group(1).strip(),relation="PROPERTY",object=m.group(2).strip(),raw=raw)
        m=self._m(r"^(.+?) не (?:вызывает|приводит к) (.+)$",s)
        if m:return Intent("CLAIM",subject=m.group(1).strip(),relation="CAUSES",object=m.group(2).strip(),raw=raw,polarity="NEG")
        m=self._m(r"^(.+?) (?:вызывает|приводит к) (.+)$",s)
        if m:return Intent("CLAIM",subject=m.group(1).strip(),relation="CAUSES",object=m.group(2).strip(),raw=raw)
        m=self._m(r"^(.+?) не является (.+)$",s)
        if m:return Intent("CLAIM",subject=m.group(1).strip(),relation="IS_A",object=m.group(2).strip(),raw=raw,polarity="NEG")
        m=self._m(r"^(.+?) (?:—|-) (?:это )?не (.+)$",s)       # G269: «X — это не Y» is the same negation
        if m:return Intent("CLAIM",subject=m.group(1).strip(),relation="IS_A",object=m.group(2).strip(),raw=raw,polarity="NEG")
        m=self._m(r"^(.+?) (?:(?:—|-) это|это|—|-|является|относится к) (.+)$",s)   # G269: «X — это Y»: «это» is part of the copula
        if m:return Intent("CLAIM",subject=m.group(1).strip(),relation="IS_A",object=m.group(2).strip(),raw=raw)
        return Intent("UNKNOWN",raw=raw)

    # G267: speech never exposes internal relation codes.
    _POS={"NAME":"{s} зовут {o}.","LIKES":"{s} любит {o}.","LOCATION":"{s} находится: {o}.","HAS":"У {s} есть {o}.",
          "IS_A":"{s} — {o}.","CAN":"{s} может {o}.","USED_FOR":"{s} используется для: {o}.","PROPERTY":"{s}: {o}.",
          "CAUSES":"{s} приводит к: {o}.","MEANS":"«{s}» означает: {o}.","HAS_PART":"У {s} есть часть: {o}.",
          "PART_OF":"{s} — часть: {o}.","RULE":"Правило для {s}: {o}.","ROLE":"{s} — {o}.","OPPOSITE":"{s} — противоположность: {o}.",
          "ANTONYM":"«{s}» — антоним: «{o}».","SYNONYM":"«{s}» — то же, что «{o}».","VALUE":"{s} = {o}.","BEFORE":"{s} — раньше, чем {o}.",
          "AFTER":"{s} — позже, чем {o}.","COLOR":"Цвет {s}: {o}.","HAS_SIDES":"У {s} сторон: {o}.","HAS_CORNERS":"У {s} углов: {o}.",
          "SUCCESSOR":"После {s} идёт {o}."}
    _NEG={"IS_A":"{s} — не {o}.","CAN":"{s} не может {o}.","CAUSES":"{s} не приводит к: {o}.","USED_FOR":"{s} не используется для: {o}.",
          "LIKES":"{s} не любит {o}.","HAS":"У {s} нет {o}."}
    # G269: case frames — which slot of a template needs a non-nominative form (the dialogue supplies the forms from
    # the graph). When a form is not certain, the case-neutral template is used instead of a wrong word form.
    _CASE_FRAME={"LIKES":(None,"acc"),"HAS":("gen",None),"HAS_PART":("gen",None),"COLOR":("gen",None),"RULE":("gen",None),
                 "HAS_SIDES":("gen",None),"HAS_CORNERS":("gen",None),"SUCCESSOR":("gen",None)}
    _CASE_FRAME_NEG={"LIKES":(None,"acc"),"HAS":("gen","gen")}
    _CASELESS={"HAS":"{s} имеет: {o}.","HAS_PART":"{s}: часть — {o}.","COLOR":"{s}: цвет — {o}.","RULE":"{s}: правило — {o}.",
               "HAS_SIDES":"{s}: сторон — {o}.","HAS_CORNERS":"{s}: углов — {o}.","SUCCESSOR":"{s}: следующее — {o}."}
    _CASELESS_NEG={"HAS":"{s} не имеет: {o}."}
    def case_frame(self,relation,polarity="POS"):
        return (self._CASE_FRAME_NEG if polarity=="NEG" else self._CASE_FRAME).get(str(relation).upper(),(None,None))
    def render_fact(self,subject_label,relation,obj,polarity="POS",caseless=False):
        rel=str(relation).upper()
        if caseless:
            t=(self._CASELESS_NEG if polarity=="NEG" else self._CASELESS).get(rel)
            if t:return t.format(s=subject_label,o=obj)
        if polarity=="NEG":
            return self._NEG.get(rel,"{s}: неверно, что {o}.").format(s=subject_label,o=obj)
        return self._POS.get(rel,"{s}: {o}.").format(s=subject_label,o=obj)

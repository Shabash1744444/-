"""G269: the child speaks in case frames — «кошка любит рыбу», «у кошки есть хвост», «собака маленькая».

Singular noun declension and adjective agreement for SPEECH. Nothing here writes to the graph.

  1. A lexeme's admitted WORD_FORM facts are attestations: among candidate forms an attested one wins.
  2. Regular paradigms by ending and gender (GRAM_GENDER fact, else WORD_FORM evidence, else the ending);
     a short table covers irregular high-frequency nouns (fleeting vowels, -мя, мать/дочь/путь).
  3. Animacy (accusative = genitive for masculine animates) comes from the graph: a proper name with a
     grammatical gender, or an IS_A path to человек / животное / птица / … .
  4. When a paradigm is ambiguous and nothing attests a form, the answer is None: the caller keeps a
     case-neutral phrasing instead of inventing a wrong word form.
"""
from __future__ import annotations
import re
from typing import Optional, Dict, Iterable
from .graph import norm

VOWELS = set("аеёиоуыэюя")
SIB = set("жшчщ")
VEL = set("гкх")
CASES = ("nom", "gen", "dat", "acc", "ins", "prep")

# Indeclinable common nouns (loanwords). A label with Latin letters or digits is indeclinable too («у C4 есть …»).
_INDECL = {"кофе", "какао", "кино", "метро", "пальто", "радио", "такси", "кенгуру", "меню", "жюри", "шоссе", "кафе",
           "пианино", "депо", "фото", "авто", "видео", "аудио", "интервью", "пюре", "желе", "эскимо", "домино", "лото",
           "бюро", "ателье", "кимоно", "фламинго", "шимпанзе", "пони", "колибри", "какаду", "эму", "рагу", "хобби",
           "леди", "евро", "сальто", "иглу", "манто", "кашпо", "суши", "спагетти", "киви", "алоэ", "оригами", "ниндзя"}

# Oblique stems of nouns with a fleeting vowel that the regular rules below do not predict.
_FLEET = {"день": "дн", "пень": "пн", "сон": "сн", "рот": "рт", "лоб": "лб", "лёд": "льд", "лед": "льд", "лев": "льв",
          "пёс": "пс", "пес": "пс", "мох": "мх", "ров": "рв", "шов": "шв", "угол": "угл", "узел": "узл", "орёл": "орл",
          "орел": "орл", "козёл": "козл", "козел": "козл", "осёл": "осл", "осел": "осл", "котёл": "котл",
          "котел": "котл", "посол": "посл", "щегол": "щегл", "дятел": "дятл", "пепел": "пепл", "ветер": "ветр",
          "ковёр": "ковр", "ковер": "ковр", "костёр": "костр", "костер": "костр", "шатёр": "шатр", "шатер": "шатр",
          "бобёр": "бобр", "бобер": "бобр", "огонь": "огн", "камень": "камн", "корень": "корн", "ремень": "ремн",
          "кремень": "кремн", "парень": "парн", "гребень": "гребн", "ноготь": "ногт", "коготь": "когт",
          "локоть": "локт", "ломоть": "ломт", "дёготь": "дёгт", "деготь": "дегт", "уголь": "угл", "муравей": "муравь",
          "воробей": "воробь", "соловей": "соловь", "ручей": "ручь", "улей": "уль", "заяц": "зайц", "овёс": "овс",
          "овес": "овс", "любовь": "любв", "церковь": "церкв", "ложь": "лж", "рожь": "рж", "вошь": "вш",
          "лапоть": "лапт", "кашель": "кашл", "хребет": "хребт", "ёж": "еж", "ёрш": "ерш"}
# Polysyllabic -ок/-ец nouns whose vowel stays («урок — урока», «мудрец — мудреца»).
_NO_FLEET = {"урок", "восток", "поток", "сток", "приток", "исток", "отток", "игрок", "порок", "пророк", "знаток",
             "ездок", "седок", "челнок", "чеснок", "курок", "мудрец", "храбрец", "хитрец", "кузнец", "наскок"}
_IRREG = {"мать": {"gen": "матери", "dat": "матери", "acc": "мать", "ins": "матерью", "prep": "матери"},
          "дочь": {"gen": "дочери", "dat": "дочери", "acc": "дочь", "ins": "дочерью", "prep": "дочери"},
          "путь": {"gen": "пути", "dat": "пути", "acc": "путь", "ins": "путём", "prep": "пути"},
          "дитя": {"gen": "дитяти", "dat": "дитяти", "acc": "дитя", "ins": "дитятей", "prep": "дитяти"}}
_MASC_SOFT = {"день", "пень", "конь", "огонь", "камень", "корень", "ремень", "кремень", "парень", "гребень", "олень",
              "тюлень", "ячмень", "ливень", "плетень", "зверь", "царь", "словарь", "букварь", "календарь", "январь",
              "февраль", "апрель", "июнь", "июль", "сентябрь", "октябрь", "ноябрь", "декабрь", "рубль", "руль",
              "король", "учитель", "писатель", "водитель", "строитель", "житель", "родитель", "автомобиль",
              "портфель", "корабль", "журавль", "кашель", "уголь", "ноль", "нуль", "пароль", "контроль", "стиль",
              "профиль", "отель", "шмель", "щавель", "тополь", "гость", "гвоздь", "дождь", "вождь", "медведь",
              "лебедь", "голубь", "ноготь", "локоть", "коготь", "ломоть", "князь", "гусь", "лось", "карась",
              "червь", "циркуль", "спектакль", "фитиль", "кремль", "лапоть", "дёготь", "деготь", "ковыль", "вихрь",
              "пузырь", "богатырь", "монастырь", "волдырь", "рояль", "тюль", "бинокль", "госпиталь", "ансамбль"}
_FEM_SOFT = {"тень", "осень", "лень", "сирень", "ступень", "мигрень", "ткань", "грань", "дань", "лань", "ладонь",
             "бронь", "соль", "боль", "роль", "мысль", "цель", "ель", "мель", "сталь", "даль", "пыль", "модель",
             "деталь", "медаль", "мебель", "мораль", "педаль", "спираль", "шинель", "дверь", "ширь", "степь", "цепь",
             "ось", "рысь", "смесь", "связь", "грязь", "мазь", "рожь", "ночь", "дочь", "мать", "речь", "вещь", "мышь",
             "ложь", "печь", "помощь", "мощь", "дичь", "морковь", "кровь", "любовь", "бровь", "обувь", "церковь",
             "лошадь", "площадь", "тетрадь", "кровать", "грудь", "медь", "ртуть", "суть", "сеть", "смерть", "нить",
             "кость", "часть", "власть", "страсть", "радость", "жизнь", "болезнь", "песнь", "память", "постель",
             "капель", "метель", "акварель", "щель", "вермишель", "карусель", "колыбель", "форель", "дробь", "зыбь",
             "рябь", "скорбь", "глубь", "сыпь", "топь", "верфь", "плоть", "прибыль", "гибель", "мебель", "печать",
             "скатерть", "четверть", "треть", "благодать", "тишь", "глушь", "мелочь", "дрожь", "фальшь", "брошь"}
# Masculine nouns of the -а/-я declension (gender matters for agreement, not for the noun's own endings).
_MASC_A = {"папа", "дедушка", "дядя", "мужчина", "юноша", "слуга", "дедуля", "папочка", "дядька", "мальчишка",
           "парнишка", "воевода", "староста", "судья", "вельможа"}
# Classes whose members are grammatically animate (plants, organs and objects are not).
ANIMATE_CLASSES = ("человек", "люди", "животное", "зверь", "птица", "рыба", "насекомое", "млекопитающее",
                   "пресмыкающееся", "земноводное", "живое существо", "существо", "персонаж", "ребёнок")

_ADJ_NOM = re.compile(r"(?:ый|ий|ой|ая|яя|ое|ее|ые|ие)$")
_CYR = re.compile(r"^[а-яё-]+$")


def _low(w):
    """Lower case WITH ё kept: generation needs it (зверёк — зверька); comparisons use graph.norm."""
    return str(w).strip().lower()


def _syllables(w):
    return sum(ch in VOWELS for ch in w)


def _keep_case(src, out):
    if out is None:
        return None
    return out[:1].upper() + out[1:] if src[:1].isupper() else out


def _fleet(lw):
    """Oblique stem with a fleeting vowel removed, or None if the vowel stays."""
    if lw in _FLEET:
        return _FLEET[lw]
    if lw in _NO_FLEET or _syllables(lw) < 2:
        return None
    if lw.endswith("ёк"):                      # зверёк — зверька, паёк — пайка
        base = lw[:-2]
        return base + ("й" if base[-1:] in VOWELS else "ь") + "к"
    if lw.endswith("ок") and lw[-3:-2] not in VOWELS:   # кусок — куска, щенок — щенка, ребёнок — ребёнка
        return lw[:-2] + "к"
    if lw.endswith(("чек", "шек", "жек", "щек")):        # кусочек — кусочка
        return lw[:-2] + "к"
    if lw.endswith("ец"):                      # отец — отца, боец — бойца, палец — пальца
        base = lw[:-2]
        if base[-1:] in VOWELS:
            return base + "йц"
        if base.endswith("л"):
            return base + "ьц"
        return base + "ц"
    return None


class RussianSpeechFormsV1:
    """Graph-aware word forms for speech. All lookups are read-only; results are cached per graph revision."""

    def __init__(self, graph, reasoner=None, principal="USER"):
        self.g = graph
        self.reasoner = reasoner
        self.principal = principal
        self._rev = None
        self._cache: Dict = {}

    # ------------------------------------------------------------------ evidence from the graph
    def _fresh(self):
        rev = (self.g.order, len(self.g.facts), len(self.g.entities))
        if rev != self._rev:
            self._rev = rev
            self._cache = {}

    def _get(self, eid, rel):
        try:
            return self.g.get_all(eid, rel, viewer=self.principal, principal=self.principal)
        except Exception:
            return []

    def attested(self, eid) -> set:
        """Admitted WORD_FORM surfaces of a lexeme (normalised), plus its label."""
        if not eid or eid not in self.g.entities:
            return set()
        self._fresh()
        key = ("att", eid)
        if key not in self._cache:
            forms = {norm(self.g.object_surface(f)) for f in self._get(eid, "WORD_FORM")}
            forms.add(norm(self.g.label(eid)))
            self._cache[key] = forms
        return self._cache[key]

    def _resolve(self, label):
        try:
            return self.g.resolve(label)
        except Exception:
            return None

    def gender(self, eid=None, label=None) -> Optional[str]:
        """MASC|FEM|NEUT|None for a noun (phrase): the GRAM_GENDER fact, else evidence, else the head's ending."""
        self._fresh()
        if eid is not None and eid in self.g.entities:
            key = ("gen", eid)
            if key in self._cache:
                return self._cache[key]
            out = None
            for f in self._get(eid, "GRAM_GENDER"):
                v = str(f.object_value).upper()
                if v in ("MASC", "FEM", "NEUT"):
                    out = v
                    break
            if out is None:
                out = self._gender_of_label(self.g.label(eid), self.attested(eid))
            self._cache[key] = out
            return out
        return self._gender_of_label(label or "", set())

    def _gender_of_label(self, label, forms):
        toks = str(label).split()
        if not toks:
            return None
        h = self._head_index(toks)
        if h is None:
            return None
        head = toks[h]
        if len(toks) > 1:                       # the head noun may be a concept with its own gender fact
            hid = self._resolve(head)
            if hid and hid in self.g.entities:
                for f in self._get(hid, "GRAM_GENDER"):
                    v = str(f.object_value).upper()
                    if v in ("MASC", "FEM", "NEUT"):
                        return v
                forms = self.attested(hid)
        return self.word_gender(head, forms)

    def word_gender(self, word, forms=()) -> Optional[str]:
        lw = _low(word)
        if not lw or not _CYR.match(lw):
            return None
        if lw in _MASC_A or lw in _MASC_SOFT:
            return "MASC"
        if lw in _FEM_SOFT:
            return "FEM"
        if lw in _INDECL:
            return "MASC" if lw in {"кофе"} else "NEUT"
        a = _ADJ_NOM.search(lw)
        if a and self._subst_adj(lw):
            e = a.group(0)
            return {"ый": "MASC", "ий": "MASC", "ой": "MASC", "ая": "FEM", "яя": "FEM", "ое": "NEUT", "ее": "NEUT"}.get(e)
        if lw.endswith("мя"):
            return "NEUT"
        if lw[-1] in "ая":
            return "FEM"
        if lw[-1] in "оеё":
            return "NEUT"
        if lw.endswith("ь"):
            return self._soft_gender(lw, forms)
        if lw[-1] not in VOWELS or lw.endswith("й"):
            return "MASC"
        return None

    def _soft_gender(self, lw, forms=()):
        if lw in _MASC_SOFT:
            return "MASC"
        if lw in _FEM_SOFT or lw in _IRREG:
            return "FEM" if lw != "путь" else "MASC"
        fs = {norm(x) for x in forms or ()}
        stem = norm(lw[:-1])
        if fs & {stem + "я", stem + "ю", stem + "ем"}:
            return "MASC"
        if norm(lw) + "ю" in fs:
            return "FEM"
        if lw.endswith(("тель", "арь", "ырь", "ень")):
            return "MASC"
        if lw.endswith(("ость", "есть", "знь", "сть", "вь", "ань", "зь", "пь", "бь", "ть", "дь", "шь", "жь", "чь",
                        "щь", "мь", "фь")):
            return "FEM"
        return None

    def animate(self, eid) -> bool:
        if not eid or eid not in self.g.entities:
            return False
        self._fresh()
        key = ("anim", eid)
        if key in self._cache:
            return self._cache[key]
        e = self.g.entities[eid]
        out = False
        if e.kind == "identity":
            out = True
        elif e.label[:1].isupper() and self._get(eid, "GRAM_GENDER"):
            out = True                          # a person's name
        elif self.reasoner is not None:
            for cls in ANIMATE_CLASSES:
                cid = self._resolve(cls)
                if not cid:
                    continue
                if cid == eid:
                    out = True
                    break
                try:
                    v = self.reasoner.evaluate_is_a(eid, cid, principal=self.principal, viewer=self.principal).value
                except Exception:
                    v = None
                if v == "TRUE":
                    out = True
                    break
        self._cache[key] = out
        return out

    # ------------------------------------------------------------------ adjectives
    @staticmethod
    def is_adjective(word) -> bool:
        lw = norm(word)
        return len(lw) >= 4 and " " not in lw and bool(_ADJ_NOM.search(lw)) and bool(_CYR.match(lw))

    @staticmethod
    def adjective_gender(word) -> Optional[str]:
        lw = norm(word)
        m = _ADJ_NOM.search(lw)
        if not m:
            return None
        return {"ый": "MASC", "ий": "MASC", "ой": "MASC", "ая": "FEM", "яя": "FEM", "ое": "NEUT", "ее": "NEUT",
                "ые": "PL", "ие": "PL"}[m.group(0)]

    def _adj_parse(self, word):
        """nominative adjective form -> (stem, kind, stressed) with kind in hard|velar|sib|soft; stressed may be None."""
        lw = _low(word)
        m = _ADJ_NOM.search(lw)
        if not m or len(lw) < 4:
            return None
        end = m.group(0)
        stem = lw[:-2]
        c = stem[-1:]
        k3 = "velar" if c in VEL else ("sib" if c in SIB else None)
        if end == "ый":
            return stem, "hard", False
        if end == "ой":
            return stem, k3 or "hard", True
        if end == "ий":
            return stem, k3 or "soft", False
        if end == "ая":
            return stem, k3 or "hard", None
        if end == "яя":
            return stem, "soft", False
        if end == "ое":
            return stem, k3 or "hard", (True if c in SIB else None)
        if end == "ее":
            return stem, ("sib" if c in SIB else "soft"), False
        if end == "ые":
            return stem, "hard", None
        if end == "ие":
            return stem, k3 or "soft", None
        return None

    def _stress(self, stem, kind):
        """Unknown ending stress of a hard/velar/sibilant adjective: the graph decides (молодой vs пушистый)."""
        self._fresh()
        key = ("stress", stem, kind)
        if key in self._cache:
            return self._cache[key]
        unstressed = stem + ("ый" if kind == "hard" else "ий")
        stressed = stem + "ой"
        out = False
        if self._resolve(stressed) and not self._resolve(unstressed):
            out = True
        self._cache[key] = out
        return out

    def adjective(self, word, case="nom", gender="MASC", animate=False) -> Optional[str]:
        """An adjective in the given case and gender (singular) or 'PL' (nominative plural)."""
        p = self._adj_parse(word)
        if p is None:
            return None
        stem, kind, stressed = p
        if stressed is None and kind in ("hard", "velar", "sib"):
            stressed = self._stress(stem, kind)
        if gender == "PL":
            return _keep_case(word, stem + ("ые" if kind == "hard" else "ие")) if case == "nom" else None
        y = "ы" if kind == "hard" else "и"          # ы after hard consonants, и after velars/sibilants/soft
        soft_o = kind == "soft" or (kind == "sib" and not stressed)
        o = "е" if soft_o else "о"
        if gender == "FEM":
            nom = stem + ("яя" if kind == "soft" else "ая")
            obl = stem + ("ей" if soft_o else "ой")
            forms = {"nom": nom, "gen": obl, "dat": obl, "acc": stem + ("юю" if kind == "soft" else "ую"),
                     "ins": obl, "prep": obl}
        else:
            if gender == "NEUT":
                nom = stem + ("ее" if soft_o else "ое")
            elif stressed and kind != "soft":
                nom = stem + "ой"
            else:
                nom = stem + ("ий" if kind != "hard" else "ый")
            gen = stem + o + "го"
            forms = {"nom": nom, "gen": gen, "dat": stem + o + "му", "ins": stem + y + "м", "prep": stem + o + "м"}
            forms["acc"] = gen if (animate and gender == "MASC") else nom
        return _keep_case(word, forms.get(case))

    def agree(self, word, eid=None, gender=None) -> str:
        """A predicate adjective agreeing with its subject («собака маленькая»); anything else is returned as is."""
        w = str(word).strip()
        if not self.is_adjective(w):
            return w
        wid = self._resolve(w)
        if wid and self._get(wid, "GRAM_GENDER"):
            return w
        if gender is None:
            gender = self.gender(eid) if eid is not None else None
        if gender not in ("MASC", "FEM", "NEUT"):
            return w
        if self.adjective_gender(w) == gender:
            return w
        out = self.adjective(w, "nom", gender)
        return out or w

    # ------------------------------------------------------------------ nouns
    def _subst_adj(self, lw):
        """Substantivised adjectives declined as adjectives: животное, насекомое, взрослый, столовая."""
        if lw.endswith(("ое", "ее", "ый")):
            return len(lw) >= 5
        if lw.endswith(("ая", "яя")):
            return any(ch in VOWELS for ch in lw[:-2]) and len(lw) >= 6
        return False

    def _head_index(self, toks):
        """Index of the head noun: the first token that is not an adjective form («живое существо» -> 1); a final
        token in -ий/-ой is a noun («старый герой»); if every token looks adjectival, the last one is a substantivised
        adjective («домашнее животное»)."""
        if not toks:
            return None
        for i, t in enumerate(toks):
            lt = norm(t)
            if not self.is_adjective(lt):
                return i
            if i == len(toks) - 1 and lt.endswith(("ий", "ой")):
                return i
        return len(toks) - 1

    def noun(self, word, case, gender=None, animate=False, forms=()) -> Optional[str]:
        """One noun in the singular. None when the paradigm is not certain."""
        if case == "nom":
            return word
        lw = _low(word)
        if not lw:
            return None
        if not _CYR.match(lw) or lw in _INDECL:
            return word                          # indeclinable: the same form in every case
        if lw[-1] in "иуыюэ":
            return word                          # nominative singular in -и/-у/-ю: a foreign indeclinable
        fs = {norm(x) for x in forms or ()}
        g = gender or self.word_gender(lw, fs)
        if lw in _IRREG:
            return _keep_case(word, _IRREG[lw].get(case))
        a = _ADJ_NOM.search(lw)
        if a and self._subst_adj(lw) and g in ("MASC", "FEM", "NEUT") and self.adjective_gender(lw) == g:
            return self.adjective(word, case, g, animate)
        if lw.endswith(("ий", "ой")) and fs & {norm(lw[:-2] + e) for e in ("ая", "яя", "ое", "ее", "ого", "его")}:
            return self.adjective(word, case, "MASC", animate)      # an adjective used as a concept name (синий)
        cands = self._noun_candidates(lw, g, animate)
        if not cands:
            return None
        if fs:                                   # an attested form wins over the rule's first guess
            for c in cands:
                if c.get(case) and norm(c[case]) in fs:
                    return _keep_case(word, c[case])
        first = cands[0].get(case)
        if first is None or cands[0].get("_uncertain"):
            return None
        return _keep_case(word, first)

    def _noun_candidates(self, lw, g, animate):
        out = []
        stem = lw[:-1]
        if lw.endswith("мя") and g in (None, "NEUT"):
            s = stem + "ен"
            out.append({"gen": s + "и", "dat": s + "и", "acc": lw, "ins": s + "ем", "prep": s + "и"})
            return out
        if lw[-1] == "а":
            c = stem[-1:]
            out.append({"gen": stem + ("и" if (c in VEL or c in SIB) else "ы"), "dat": stem + "е", "acc": stem + "у",
                        "ins": stem + ("ей" if (c in SIB or c == "ц") else "ой"), "prep": stem + "е"})
            return out
        if lw[-1] == "я":
            if lw.endswith("ия"):
                out.append({"gen": stem + "и", "dat": stem + "и", "acc": stem + "ю", "ins": stem + "ей", "prep": stem + "и"})
            else:
                out.append({"gen": stem + "и", "dat": stem + "е", "acc": stem + "ю", "ins": stem + "ей", "prep": stem + "е"})
            return out
        if lw[-1] in "оеё" and g in (None, "NEUT", "MASC"):
            c = stem[-1:]
            if lw.endswith("ие"):
                f = {"gen": stem + "я", "dat": stem + "ю", "ins": stem + "ем", "prep": stem + "и"}
            elif lw[-1] == "е" and (c in SIB or c == "ц"):
                f = {"gen": stem + "а", "dat": stem + "у", "ins": stem + "ем", "prep": stem + "е"}
            elif lw[-1] == "е":
                f = {"gen": stem + "я", "dat": stem + "ю", "ins": stem + "ем", "prep": stem + "е"}
            elif lw[-1] == "ё":
                f = {"gen": stem + "я", "dat": stem + "ю", "ins": stem + "ём", "prep": stem + "е"}
            else:
                f = {"gen": stem + "а", "dat": stem + "у", "ins": stem + "ом", "prep": stem + "е"}
            f["acc"] = lw
            out.append(f)
            return out
        if lw[-1] == "ь":
            if g == "FEM":
                fl = _fleet(lw)
                s = fl or stem
                out.append({"gen": s + "и", "dat": s + "и", "acc": lw, "ins": lw + "ю", "prep": s + "и"})
                return out
            if g != "MASC":
                return [{"_uncertain": True}]
            fl = _fleet(lw)
            for s in ([fl, stem] if fl else [stem]):
                f = {"gen": s + "я", "dat": s + "ю", "ins": s + "ем", "prep": s + "е"}
                f["acc"] = f["gen"] if animate else lw
                out.append(f)
            return out
        if lw[-1] == "й":
            fl = _fleet(lw)
            for s in ([fl, stem] if fl else [stem]):
                f = {"gen": s + "я", "dat": s + "ю", "ins": s + "ем",
                     "prep": s + ("и" if (lw.endswith("ий") and _syllables(lw) >= 2 and not fl) else "е")}
                f["acc"] = f["gen"] if animate else lw
                out.append(f)
            return out
        if lw[-1] not in VOWELS:
            if g == "FEM":
                return [{"_uncertain": True}]    # a feminine name in a consonant (Нинель, Кармен): indeclinable or not
            fl = _fleet(lw)
            for s in ([fl, lw] if fl else [lw]):
                c = s[-1:]
                stressed_end = _syllables(lw) <= 1 or (fl is not None and lw.endswith(("ец", "ок", "ёк")))
                ins = s + ("ем" if ((c in SIB or c == "ц") and not stressed_end) else "ом")
                f = {"gen": s + "а", "dat": s + "у", "ins": ins, "prep": s + "е"}
                f["acc"] = f["gen"] if animate else lw
                out.append(f)
            return out
        return out

    def phrase(self, label, case, eid=None) -> Optional[str]:
        """A noun phrase («живое существо», «часть велосипеда», «Руслан») in a case; None if not certain."""
        lab = str(label).strip()
        if case == "nom" or not lab:
            return lab
        if re.search(r"[A-Za-z0-9]", lab):
            return lab                           # symbols and Latin-script names are not declined
        toks = lab.split()
        if len(toks) > 4:
            return None
        h = self._head_index(toks)
        if h is None:
            return None
        head, adjs, tail = toks[h], toks[:h], toks[h + 1:]
        if any(t[:1].isupper() for t in tail) or any(not _CYR.match(norm(t)) for t in toks):
            return None
        if eid is not None and len(toks) == 1:
            g = self.gender(eid)
            forms = self.attested(eid)
        else:
            g = self.gender(eid) if eid is not None else None
            hid = self._resolve(head) if len(toks) > 1 else None
            if g is None:
                g = self.gender(hid) if hid else self.word_gender(head)
            forms = self.attested(hid) if hid else set()
        anim = self.animate(eid) if eid is not None else False
        hf = self.noun(head, case, g, anim, forms)
        if hf is None:
            return None
        out = []
        for a in adjs:
            if self.adjective_gender(a) not in (g, None) or g is None:
                return None                      # «гений чистой красоты» is not adjective + noun
            af = self.adjective(a, case, g, anim)
            if af is None:
                return None
            out.append(af)
        return " ".join(out + [hf] + tail)

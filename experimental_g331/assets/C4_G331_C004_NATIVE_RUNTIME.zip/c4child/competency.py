from __future__ import annotations
from .graph import fast_asdict
from dataclasses import dataclass,asdict,field
from typing import Dict,List
import hashlib

OPEN='OPEN';MASTERED='MASTERED'

@dataclass
class CompetencyRequirement:
    requirement_id:str
    kind:str
    subject:str
    relation:str
    object_value:str
    priority:float=0.8
    expected:str='TRUE'

@dataclass
class CompetencyContract:
    competency_id:str
    label:str
    requirements:List[CompetencyRequirement]=field(default_factory=list)
    status:str=OPEN

class CompetencyRegistry:
    SCHEMA='C4_COMPETENCIES_V0.1'
    def __init__(self):self.contracts:Dict[str,CompetencyContract]={}
    @staticmethod
    def make_id(label):return 'comp:'+hashlib.blake2s(str(label).encode('utf-8'),digest_size=8).hexdigest()
    @staticmethod
    def req_id(kind,subject,relation,object_value,expected='TRUE'):
        raw=f'{kind}|{subject}|{relation}|{object_value}|{expected}'.encode('utf-8')
        return 'req:'+hashlib.blake2s(raw,digest_size=8).hexdigest()
    def create(self,label,requirements):
        cid=self.make_id(label);rows=[]
        for r in requirements:
            kind=str(r.get('kind','RELATION'));s=str(r['subject']);rel=str(r['relation']);o=str(r['object_value']);p=float(r.get('priority',0.8));e=str(r.get('expected','TRUE')).upper()
            if e not in {'TRUE','FALSE'}:raise ValueError('bad expected truth')
            rows.append(CompetencyRequirement(self.req_id(kind,s,rel,o,e),kind,s,rel,o,p,e))
        c=CompetencyContract(cid,str(label),rows,OPEN);self.contracts[cid]=c;return c
    def to_dict(self):return {'schema':self.SCHEMA,'contracts':[{'competency_id':c.competency_id,'label':c.label,'status':c.status,'requirements':[fast_asdict(r) for r in c.requirements]} for c in self.contracts.values()]}
    @classmethod
    def from_dict(cls,d):
        x=cls()
        if not d:return x
        for raw in d.get('contracts',[]):
            reqs=[CompetencyRequirement(**r) for r in raw.get('requirements',[])]
            c=CompetencyContract(raw['competency_id'],raw['label'],reqs,raw.get('status',OPEN));x.contracts[c.competency_id]=c
        return x

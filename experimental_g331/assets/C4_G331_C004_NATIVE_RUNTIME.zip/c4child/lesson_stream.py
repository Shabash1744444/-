from __future__ import annotations
from dataclasses import dataclass,asdict,field
from typing import Dict,Any,Optional
import json,hashlib
from .bootstrap import BootstrapTeacher

SCHEMA='C4_LESSON_STREAM_V0.1'

@dataclass
class LessonStreamState:
    lesson_id:Optional[str]=None
    origin:Optional[str]=None
    scope:Dict[str,Any]=field(default_factory=dict)
    authority:str='TEACHER'
    offset:int=0
    tail:str=''
    lines:int=0
    semantic_events:int=0
    admitted:int=0
    dedup:int=0
    rejected:int=0
    surfaces:int=0
    probes:int=0
    sensory_anchors:int=0
    ended:bool=False
    last_chunk_offset:int=-1
    last_chunk_len:int=0
    last_chunk_hash:str=''

class C4LessonStreamIngestor:
    """Incremental structured lesson ingestion.

    Newline-delimited JSON gives the teacher stream explicit semantic-event boundaries,
    so active memory depends on one bounded event line rather than the total lesson size.
    """
    def __init__(self,graph,principal='USER',max_line_bytes=65536):
        self.g=graph;self.principal=principal;self.max_line_bytes=max(1024,int(max_line_bytes));self.state=LessonStreamState()

    def _line(self,line:str):
        raw=line.strip()
        if not raw:return
        if len(raw.encode('utf-8'))>self.max_line_bytes:raise ValueError('lesson event line exceeds max_line_bytes')
        obj=json.loads(raw);self.state.lines+=1
        if self.state.lesson_id is None:
            if obj.get('schema')!=SCHEMA:raise ValueError('first line must be lesson-stream header')
            if obj.get('origin') not in {'CREATOR_PRIOR','EXTERNAL_CORPUS','USER_SAID'}:raise ValueError('bad origin')
            self.state.lesson_id=str(obj['lesson_id']);self.state.origin=str(obj['origin']);self.state.scope=dict(obj.get('scope') or {'principal':self.principal,'privacy':'PRIVATE'});self.state.authority=str(obj.get('authority','TEACHER'));return
        typ=obj.get('type')
        if typ=='END':self.state.ended=True;return
        if self.state.ended:raise ValueError('event after END')
        if typ=='SEM':
            payload=obj['payload'];eid=str(obj.get('id') or f"line:{self.state.lines}")
            ev={'schema':'C4_BOOTSTRAP_EVENT_V0.1','event_id':f'{self.state.lesson_id}:{eid}','origin':self.state.origin,'status':'ADMITTED','scope':self.state.scope,'authority':self.state.authority,'confidence':float(obj.get('confidence',1.0)),'source_ref':f'{self.state.lesson_id}:{eid}','source_group':self.state.lesson_id,'payload':payload}
            before_audit=len(self.g.audit);m=BootstrapTeacher(self.g,principal=self.state.scope.get('principal',self.principal)).ingest([ev])
            self.state.semantic_events+=m.events;self.state.admitted+=m.admitted;self.state.dedup+=m.dedup;self.state.rejected+=m.rejected
            if m.dedup and len(self.g.audit)>before_audit and self.g.audit[-1].get('type')=='DEDUP':self.g.audit.pop()
        elif typ=='SURFACE':self.state.surfaces+=1
        elif typ=='PROBE':self.state.probes+=1
        elif typ=='SENSORY':self.state.sensory_anchors+=1
        else:raise ValueError('unknown lesson event type')

    def append(self,offset:int,payload:str):
        st=self.state;off=int(offset);payload=str(payload);b=payload.encode('utf-8');h=hashlib.sha256(b).hexdigest()
        if off==st.last_chunk_offset and len(b)==st.last_chunk_len:
            if h!=st.last_chunk_hash:raise ValueError('latest chunk replayed with different content')
            return self.status()
        if off<st.offset:
            if off+len(b)<=st.offset:return self.status()
            raise ValueError('overlapping replay past durable offset')
        if off!=st.offset:raise ValueError(f'non-contiguous offset: expected {st.offset}, got {off}')
        combined=st.tail+payload
        # Bound unclosed event memory. Structured lesson writers must newline-terminate events.
        if '\n' not in combined and len(combined.encode('utf-8'))>self.max_line_bytes:raise ValueError('unterminated lesson event exceeds max_line_bytes')
        parts=combined.split('\n');st.tail=parts.pop()
        if len(st.tail.encode('utf-8'))>self.max_line_bytes:raise ValueError('lesson tail exceeds max_line_bytes')
        for line in parts:self._line(line)
        st.offset+=len(b);st.last_chunk_offset=off;st.last_chunk_len=len(b);st.last_chunk_hash=h
        return self.status()

    def end(self):
        if self.state.tail.strip():self._line(self.state.tail);self.state.tail=''
        if not self.state.ended:self._line(json.dumps({'type':'END'}))
        return self.status()

    def status(self):
        d=asdict(self.state);d['active_tail_bytes']=len(self.state.tail.encode('utf-8'));return d
    def runtime_state(self):return {'schema':SCHEMA,'state':asdict(self.state),'max_line_bytes':self.max_line_bytes}
    def load_runtime_state(self,d):
        if not d:return
        if d.get('schema')!=SCHEMA:raise ValueError('bad lesson stream state')
        self.max_line_bytes=int(d.get('max_line_bytes',self.max_line_bytes));self.state=LessonStreamState(**d['state'])

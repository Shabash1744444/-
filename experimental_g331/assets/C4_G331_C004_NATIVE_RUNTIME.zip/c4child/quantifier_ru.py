from __future__ import annotations
import re
from .language_ru import Intent, RussianChildLanguageV0
from .predicate_ru import RussianPredicateLexiconV1

class RussianUniversalClassV1:
    """Bounded universal-class surface.

    `Все собаки могут дышать` is not expanded to every known dog. It becomes the
    existing class fact CAN(собака, дышать), which the structural reasoner may
    inherit to instances. This layer does not add a rule engine.
    """
    ALLOWED={'IS_A','CAN','PROPERTY','USED_FOR'}
    def __init__(self,lang:RussianChildLanguageV0,predicates:RussianPredicateLexiconV1):
        self.lang=lang;self.predicates=predicates

    def parse(self,text:str,principal='USER'):
        s=str(text).strip().rstrip('.!?')
        m=re.match(r'^(?:все|каждый|каждая|каждое)\s+(.+)$',s,flags=re.IGNORECASE)
        if not m:return None
        rest=m.group(1).strip()
        base=self.lang.parse(rest)
        if base.kind=='CLAIM' and base.relation in self.ALLOWED:
            if base.polarity=='POS' or (base.polarity=='NEG' and base.relation in {'CAN','PROPERTY','USED_FOR'}):
                base.raw=text
                return base
        pred=self.predicates.parse_claim(rest,principal=principal)
        if pred is None or pred.relation not in self.ALLOWED or pred.tense=='PAST':
            return None
        if pred.polarity=='NEG' and pred.relation not in {'CAN','PROPERTY','USED_FOR'}:return None
        return Intent('CLAIM',subject=pred.subject,relation=pred.relation,object=pred.object,raw=text,polarity=pred.polarity)

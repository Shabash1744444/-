from __future__ import annotations
from dataclasses import dataclass
import math

@dataclass(frozen=True)
class BinaryTraceTemplate:
    alpha:float=0.99
    w0:float=-12.0
    w1:float=12.0

class DynamicBoundTrace:
    """Shared H3 template keyed by dynamic entity id.
    Parameters are shared; per-entity values are transient state, not new weights.
    Lazy decay keeps query/update cost O(1) in lifetime entity count.
    """
    def __init__(self,template:BinaryTraceTemplate|None=None):
        self.t=template or BinaryTraceTemplate()
        self.state={} # entity_id -> [h0,h1,last_step]
        self.step=0
        self.ops=0

    @property
    def parameter_count(self):return 3
    @property
    def template_count(self):return 1

    def _touch(self,eid):
        rec=self.state.get(eid)
        if rec is None:
            rec=[0.0,0.0,self.step];self.state[eid]=rec;return rec
        dt=self.step-int(rec[2])
        if dt>0:
            f=self.t.alpha**dt;rec[0]*=f;rec[1]*=f;rec[2]=self.step;self.ops+=4
        return rec

    def tick(self,n=1):self.step+=int(n)
    def write(self,eid,value:int):
        if value not in (0,1):raise ValueError('binary value required')
        r=self._touch(str(eid));r[value]+=1.0;self.ops+=1
    def proba(self,eid):
        r=self._touch(str(eid));z=self.t.w0*r[0]+self.t.w1*r[1];self.ops+=3
        z=max(-30.0,min(30.0,z));return 1.0/(1.0+math.exp(-z))
    def read(self,eid):return int(self.proba(eid)>=0.5)
    def drop_transient(self):self.state.clear()

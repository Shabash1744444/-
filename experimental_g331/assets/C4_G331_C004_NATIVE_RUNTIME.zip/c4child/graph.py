from __future__ import annotations
from dataclasses import dataclass, asdict, fields as _dc_fields
from functools import lru_cache
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Iterable
from .constitution import LEGACY, STRICT, CONSTITUTION_VERSION, ConstitutionDecision, evaluate_mutation
from .scope import KNOWLEDGE, SOURCE_ASSERTION, fact_scope, scope_allows
import hashlib, json, os, re

ACTIVE_STATUSES={"ADMITTED","REVISED"}


@lru_cache(maxsize=None)
def _field_names(cls):
    return tuple(f.name for f in _dc_fields(cls))


def fast_asdict(obj):
    """dataclasses.asdict for plain data (scalars, lists, tuples, dicts, nested dataclasses) without its generic deep
    copy machinery — G270: the runtime state is written every turn that changes it, so this is on the hot path."""
    if hasattr(type(obj), "__dataclass_fields__"):
        return {n: fast_asdict(getattr(obj, n)) for n in _field_names(type(obj))}
    if isinstance(obj, list):
        return [fast_asdict(x) for x in obj]
    if isinstance(obj, tuple):
        vals = [fast_asdict(x) for x in obj]
        return type(obj)(*vals) if hasattr(obj, "_fields") else type(obj)(vals)
    if isinstance(obj, dict):
        return {fast_asdict(k): fast_asdict(v) for k, v in obj.items()}
    return obj
FUNCTIONAL="FUNCTIONAL"
SET="SET"


def norm(s:str)->str:
    """Lexical normalization for ordinary concepts/surfaces."""
    return re.sub(r"\s+"," ",str(s).strip().lower().replace("ё","е"))

def norm_exact(s:str)->str:
    """Exact symbolic normalization. Case/space fold only; preserves ё/e and symbol identity."""
    return re.sub(r"\s+"," ",str(s).strip().lower())

STRICT_IDENTITY_KINDS={"symbol","phoneme","grapheme"}

def alias_norm(kind:str,s:str)->str:
    return norm_exact(s) if kind in STRICT_IDENTITY_KINDS else norm(s)


def rel_norm(s:str)->str:
    return norm(s).upper().replace(" ","_")


def stable_id(kind:str,label:str)->str:
    raw=f"{kind}:{alias_norm(kind,label)}".encode("utf-8")
    return f"{kind}:{hashlib.blake2s(raw,digest_size=8).hexdigest()}"

@dataclass
class Entity:
    entity_id:str
    kind:str
    label:str
    aliases:List[str]
    created_order:int

@dataclass
class RelationSpec:
    relation:str
    cardinality:str=FUNCTIONAL
    object_mode:str="literal"  # literal|entity|either

@dataclass
class Fact:
    fact_id:str
    subject:str
    relation:str
    object_kind:str
    object_value:str
    origin:str
    principal:str
    privacy:str
    status:str
    authority:str
    confidence:float
    order:int
    source_ref:Optional[str]=None
    correction_of:Optional[str]=None
    polarity:str="POS"
    source_group:Optional[str]=None

@dataclass
class EvidenceSource:
    source_group:str
    origin:str
    authority:str
    count:int=0
    max_confidence:float=0.0
    first_order:int=0
    last_order:int=0

@dataclass
class EvidenceRecord:
    proposition_key:str
    total_count:int=0
    sources:Dict[str,EvidenceSource]=None
    subject:str=''
    relation:str=''
    object_kind:str=''
    object_value:str=''
    polarity:str='POS'
    principal:str=''
    def __post_init__(self):
        if self.sources is None:self.sources={}

class C4Graph:
    """Durable structural graph.

    G270: this class is the in-memory store. ``SQLiteGraph`` (store_sqlite.py) keeps the same logic on disk; the
    environment variable C4_GRAPH_STORE=sqlite makes ``C4Graph()`` return a disk-backed graph (used to run the whole
    test-suite against the disk store).

    L6 changes:
    - relations explicitly declare FUNCTIONAL vs SET cardinality;
    - relation objects may be typed entity bindings;
    - canonical storage is keyed by a relation slot, so multi-valued facts do not
      masquerade as corrections;
    - explicit replacement remains available for actual revision.
    """
    DEFAULT_RELATIONS={
        "NAME": RelationSpec("NAME",FUNCTIONAL,"literal"),
        "LOCATION": RelationSpec("LOCATION",FUNCTIONAL,"either"),
        "COLOR": RelationSpec("COLOR",FUNCTIONAL,"literal"),
        "WHEELS": RelationSpec("WHEELS",FUNCTIONAL,"literal"),
        "VALUE": RelationSpec("VALUE",FUNCTIONAL,"literal"),
        "LIKES": RelationSpec("LIKES",SET,"either"),
        "HAS": RelationSpec("HAS",SET,"either"),
        "IS_A": RelationSpec("IS_A",SET,"entity"),
        "PART_OF": RelationSpec("PART_OF",SET,"entity"),
        "CAN": RelationSpec("CAN",SET,"either"),
        "PROPERTY": RelationSpec("PROPERTY",SET,"either"),
        "OPPOSITE": RelationSpec("OPPOSITE",SET,"entity"),
        "CAUSES": RelationSpec("CAUSES",SET,"either"),
        "BEFORE": RelationSpec("BEFORE",SET,"either"),
        "AFTER": RelationSpec("AFTER",SET,"either"),
        "MEANS": RelationSpec("MEANS",SET,"entity"),
        "SYNONYM": RelationSpec("SYNONYM",SET,"entity"),
        "ANTONYM": RelationSpec("ANTONYM",SET,"entity"),
        "WORD_FORM": RelationSpec("WORD_FORM",SET,"literal"),
        "HAS_PART": RelationSpec("HAS_PART",SET,"entity"),
        "USED_FOR": RelationSpec("USED_FOR",SET,"either"),
        "FOUNDATIONAL": RelationSpec("FOUNDATIONAL",FUNCTIONAL,"literal"),
        "RULE": RelationSpec("RULE",SET,"literal"),
        "ROLE": RelationSpec("ROLE",SET,"entity"),
        "SUCCESSOR": RelationSpec("SUCCESSOR",FUNCTIONAL,"entity"),
        "HAS_SIDES": RelationSpec("HAS_SIDES",FUNCTIONAL,"literal"),
        "HAS_CORNERS": RelationSpec("HAS_CORNERS",FUNCTIONAL,"literal"),
        "GRAM_GENDER": RelationSpec("GRAM_GENDER",FUNCTIONAL,"literal"),
        "PREDICATE_RELATION": RelationSpec("PREDICATE_RELATION",FUNCTIONAL,"literal"),
        "QUERY_RELATION": RelationSpec("QUERY_RELATION",FUNCTIONAL,"literal"),
        "PREDICATE_PRESENT_FORM": RelationSpec("PREDICATE_PRESENT_FORM",SET,"literal"),
        "PREDICATE_PAST_FORM": RelationSpec("PREDICATE_PAST_FORM",SET,"literal"),
        "EVENT_PREDICATE": RelationSpec("EVENT_PREDICATE",FUNCTIONAL,"literal"),
        "EVENT_SUBJECT": RelationSpec("EVENT_SUBJECT",FUNCTIONAL,"entity"),
        "EVENT_OBJECT": RelationSpec("EVENT_OBJECT",FUNCTIONAL,"either"),
        "EVENT_TENSE": RelationSpec("EVENT_TENSE",FUNCTIONAL,"literal"),
        "EVENT_POLARITY": RelationSpec("EVENT_POLARITY",FUNCTIONAL,"literal"),
    }

    def __new__(cls,*args,**kwargs):
        if cls is C4Graph and os.environ.get("C4_GRAPH_STORE","").lower()=="sqlite":
            from .store_sqlite import SQLiteGraph
            return object.__new__(SQLiteGraph)
        return object.__new__(cls)

    # G270: storage hooks. The in-memory store holds the objects themselves, so nothing is written back here.
    def _touch_fact(self,f:"Fact")->None:pass
    def _touch_entity(self,e:"Entity")->None:pass
    def _touch_evidence(self,rec:"EvidenceRecord")->None:pass
    def flush(self,**kw)->None:pass
    def close(self)->None:pass
    store_kind="memory"

    def __init__(self):
        self.entities:Dict[str,Entity]={}
        self.alias_index:Dict[Tuple[str,str],str]={}
        # Derived/non-durable alias indexes. They are rebuilt from entities on load.
        self._alias_lex:Dict[str,set[str]]={}
        self._alias_exact:Dict[str,set[str]]={}
        self.facts:Dict[str,Fact]={}
        # (subject, relation, principal, slot) -> fact_id
        self.canonical:Dict[Tuple[str,str,str,str],str]={}
        # Derived/non-durable canonical indexes.
        self._slot_index:Dict[Tuple[str,str,str],set[Tuple[str,str,str,str]]]={}
        self._subject_index:Dict[Tuple[str,str],set[Tuple[str,str,str,str]]]={}
        self._object_index:Dict[Tuple[str,str,str,str],set[Tuple[str,str,str,str]]]={}
        self.order=0
        self.relation_templates=set()
        self.relation_specs:Dict[str,RelationSpec]={k:RelationSpec(v.relation,v.cardinality,v.object_mode) for k,v in self.DEFAULT_RELATIONS.items()}
        self.audit=[]
        self.evidence:Dict[str,EvidenceRecord]={}
        self._evidence_slot_index:Dict[Tuple[str,str,str],set[str]]={}
        # Derived cache epoch for language morphology; unrelated life events do not touch it.
        self.lexicon_revision=0
        # Constitution is executable policy, not an ordinary mutable graph fact.
        # LEGACY exists only to replay historical checkpoints/tests. New live artifacts
        # explicitly persist STRICT in the checkpoint.
        self.constitutional_mode=LEGACY
        self.constitution_version=CONSTITUTION_VERSION
        self.hardened_gate=False  # Experimental candidate: prevent source-origin WORLD mutation via forged basis.

    def _index_alias(self,kind:str,alias:str,eid:str)->None:
        target=self._alias_exact if kind in STRICT_IDENTITY_KINDS else self._alias_lex
        key=norm_exact(alias) if kind in STRICT_IDENTITY_KINDS else norm(alias)
        target.setdefault(key,set()).add(eid)

    def _index_canonical_add(self,key:Tuple[str,str,str,str])->None:
        s,r,p,_=key
        self._slot_index.setdefault((s,r,p),set()).add(key)
        self._subject_index.setdefault((s,p),set()).add(key)
        fid=self.canonical.get(key)
        if fid is not None and fid in self.facts:
            f=self.facts[fid]
            self._object_index.setdefault((r,p,f.object_kind,str(f.object_value)),set()).add(key)

    def _index_canonical_remove(self,key:Tuple[str,str,str,str],fid=None)->None:
        s,r,p,_=key
        if fid is None: fid=self.canonical.get(key)
        if fid is not None and fid in self.facts:
            f=self.facts[fid]; oi=self._object_index.get((r,p,f.object_kind,str(f.object_value)))
            if oi is not None:
                oi.discard(key)
                if not oi:self._object_index.pop((r,p,f.object_kind,str(f.object_value)),None)
        a=self._slot_index.get((s,r,p))
        if a is not None:
            a.discard(key)
            if not a:self._slot_index.pop((s,r,p),None)
        b=self._subject_index.get((s,p))
        if b is not None:
            b.discard(key)
            if not b:self._subject_index.pop((s,p),None)

    def _canonical_set(self,key:Tuple[str,str,str,str],fid:str)->None:
        old=self.canonical.get(key)
        if old is not None:self._index_canonical_remove(key,old)
        self.canonical[key]=fid
        self._index_canonical_add(key)

    def _canonical_pop(self,key:Tuple[str,str,str,str]):
        if key not in self.canonical:return None
        fid=self.canonical.get(key)
        self._index_canonical_remove(key,fid)
        return self.canonical.pop(key)

    def _rebuild_compiled_indexes(self)->None:
        self._alias_lex={};self._alias_exact={};self._slot_index={};self._subject_index={};self._object_index={}
        for e in self.entities.values():
            for a in e.aliases:self._index_alias(e.kind,a,e.entity_id)
        for key in self.canonical:self._index_canonical_add(key)

    def register_relation(self,relation:str,cardinality:str=FUNCTIONAL,object_mode:str="literal"):
        r=rel_norm(relation)
        if cardinality not in {FUNCTIONAL,SET}: raise ValueError("bad cardinality")
        if object_mode not in {"literal","entity","either"}: raise ValueError("bad object_mode")
        old=self.relation_specs.get(r)
        spec=RelationSpec(r,cardinality,object_mode)
        if old and (old.cardinality!=spec.cardinality or old.object_mode!=spec.object_mode):
            # relation semantics are schema, not a silently mutable runtime preference
            if self._relation_in_use(r):
                raise ValueError(f"cannot change active relation schema for {r}")
        self.relation_specs[r]=spec
        return spec

    def _relation_in_use(self,r:str)->bool:
        return any(k[1]==r for k in self.canonical)

    def relation_spec(self,relation:str)->RelationSpec:
        r=rel_norm(relation)
        return self.relation_specs.get(r,RelationSpec(r,FUNCTIONAL,"literal"))

    def entity(self,label:str,kind:str="concept",aliases:Optional[List[str]]=None)->str:
        key=(kind,alias_norm(kind,label))
        if key in self.alias_index:
            eid=self.alias_index[key]
        else:
            eid=stable_id(kind,label)
            if eid not in self.entities:
                self.order+=1
                self.entities[eid]=Entity(eid,kind,str(label).strip(),[],self.order)
        vals=[label]+(aliases or [])
        e=self.entities[eid];changed=False
        for a in vals:
            ak=(kind,alias_norm(kind,a))
            if self.alias_index.get(ak)!=eid:self.alias_index[ak]=eid
            self._index_alias(kind,a,eid)
            if a not in e.aliases:e.aliases.append(a);changed=True
        if changed:self._touch_entity(e)
        return eid

    def add_alias(self,eid:str,alias:str)->None:
        if eid not in self.entities: raise KeyError(eid)
        e=self.entities[eid];ak=(e.kind,alias_norm(e.kind,alias))
        other=self.alias_index.get(ak)
        if other is not None and other!=eid:
            raise ValueError(f"alias collision: {alias}")
        self.alias_index[ak]=eid;self._index_alias(e.kind,alias,eid)
        if alias not in e.aliases:e.aliases.append(alias);self._touch_entity(e)

    def resolve(self,label:str,kind:Optional[str]=None)->Optional[str]:
        if kind is not None:return self.alias_index.get((kind,alias_norm(kind,label)))
        hits=set(self._alias_lex.get(norm(label),()))
        hits.update(self._alias_exact.get(norm_exact(label),()))
        return next(iter(hits)) if len(hits)==1 else None

    def label(self,eid:str)->str:
        return self.entities[eid].label if eid in self.entities else eid

    def _prop_key(self,subject,relation,object_kind,object_value,polarity,principal):
        raw=f"{subject}|{rel_norm(relation)}|{object_kind}|{object_value}|{str(polarity).upper()}|{principal}".encode('utf-8')
        return 'prop:'+hashlib.blake2s(raw,digest_size=12).hexdigest()

    def _index_evidence_record(self,rec:EvidenceRecord)->None:
        self._evidence_slot_index.setdefault((rec.subject,rec.relation,rec.principal),set()).add(rec.proposition_key)

    def _record_evidence(self,subject,relation,object_kind,object_value,polarity,principal,origin,authority,confidence,source_group=None,source_ref=None):
        pk=self._prop_key(subject,relation,object_kind,object_value,polarity,principal)
        rec=self.evidence.get(pk)
        if rec is None:
            rec=EvidenceRecord(pk,0,{},str(subject),rel_norm(relation),str(object_kind),str(object_value),str(polarity).upper(),str(principal));self.evidence[pk]=rec;self._index_evidence_record(rec)
        group=str(source_group or source_ref or f'{origin}:{principal}')
        src=rec.sources.get(group)
        if src is None:
            src=EvidenceSource(group,str(origin),str(authority),0,0.0,self.order,self.order);rec.sources[group]=src
        src.count+=1;src.max_confidence=max(src.max_confidence,float(confidence));src.last_order=self.order
        rec.total_count+=1
        self._touch_evidence(rec)
        return rec

    def evidence_summary(self,subject,relation,object_value,*,object_kind='literal',polarity='POS',principal='SELF'):
        pk=self._prop_key(subject,relation,object_kind,str(object_value),polarity,principal);rec=self.evidence.get(pk)
        if rec is None:return {'proposition_key':pk,'total_count':0,'independent_sources':0,'sources':[]}
        return {'proposition_key':pk,'total_count':rec.total_count,'independent_sources':len(rec.sources),
                'sources':[asdict(x) for x in sorted(rec.sources.values(),key=lambda z:z.source_group)]}

    def _fact_source_group(self,f:Fact):
        return str(f.source_group or f.source_ref or f'{f.origin}:{f.principal}')

    def proposition_source_stances(self,subject,relation,object_value,*,object_kind='literal',principal='SELF'):
        latest={}
        for pol in ('POS','NEG'):
            pk=self._prop_key(subject,relation,object_kind,str(object_value),pol,principal);rec=self.evidence.get(pk)
            if not rec:continue
            for group,src in rec.sources.items():
                cur=latest.get(group)
                if cur is None or src.last_order>cur['last_order']:
                    latest[group]={'source_group':group,'polarity':pol,'last_order':src.last_order,'origin':src.origin,'authority':src.authority}
        return list(latest.values())

    def proposition_source_conflict(self,subject,relation,object_value,*,object_kind='literal',principal='SELF'):
        return len({x['polarity'] for x in self.proposition_source_stances(subject,relation,object_value,object_kind=object_kind,principal=principal)})>1

    def functional_source_stances(self,subject,relation,*,principal='SELF'):
        """Latest active positive value claimed by each source for a FUNCTIONAL slot.

        G298: a later NEG of the source's currently selected value retracts that
        source stance.  It does not resurrect an older value that had already been
        superseded, and a NEG of some other value does not erase the current one.
        Evidence history remains intact; this method only reconstructs the source's
        current slot stance for conflict reporting.
        """
        rel=rel_norm(relation);events={}
        for pk in self._evidence_slot_index.get((subject,rel,principal),()):
            rec=self.evidence[pk]
            for group,src in rec.sources.items():
                events.setdefault(group,[]).append((int(src.last_order),rec.polarity,rec.object_kind,rec.object_value,src))
        out=[]
        for group,rows in events.items():
            stance=None
            for order,pol,ok,ov,src in sorted(rows,key=lambda x:x[0]):
                if pol=='POS':
                    stance=(ok,ov,src,order)
                elif stance is not None and stance[0]==ok and stance[1]==ov:
                    stance=None
            if stance is not None:
                ok,ov,src,order=stance
                out.append({'source_group':group,'object_kind':ok,'object_value':ov,'last_order':order,'origin':src.origin,'authority':src.authority})
        return out

    def functional_source_conflict(self,subject,relation,*,principal='SELF'):
        st=self.functional_source_stances(subject,relation,principal=principal)
        return len({(x['object_kind'],x['object_value']) for x in st})>1

    def rebuild_evidence_from_facts(self):
        """Minimal backward-compatible migration.

        Old checkpoints did not preserve duplicate counts, so migration records exactly
        one known support item per historical fact and never invents lost repetitions.
        """
        self.evidence={};self._evidence_slot_index={}
        for f in sorted(self.facts.values(),key=lambda z:z.order):
            pk=self._prop_key(f.subject,f.relation,f.object_kind,f.object_value,f.polarity,f.principal)
            rec=self.evidence.get(pk)
            if rec is None:
                rec=EvidenceRecord(pk,0,{},f.subject,f.relation,f.object_kind,f.object_value,f.polarity,f.principal);self.evidence[pk]=rec;self._index_evidence_record(rec)
            group=str(f.source_ref or f'{f.origin}:{f.principal}')
            src=rec.sources.get(group)
            if src is None:
                src=EvidenceSource(group,f.origin,f.authority,0,0.0,f.order,f.order);rec.sources[group]=src
            src.count+=1;src.max_confidence=max(src.max_confidence,float(f.confidence));src.last_order=f.order;rec.total_count+=1
            self._touch_evidence(rec)
        return len(self.evidence)

    def _fact_id(self,subject,relation,principal,order):
        raw=f"{subject}|{relation}|{principal}|{order}".encode()
        return "fact:"+hashlib.blake2s(raw,digest_size=10).hexdigest()

    def _obj_key(self,object_kind:str,object_value:str)->str:
        return f"{object_kind}:{norm(object_value)}"

    def _slot(self,relation:str,object_kind:str,object_value:str,polarity="POS")->str:
        spec=self.relation_spec(relation)
        if polarity=="NEG":return "NEG:"+self._obj_key(object_kind,object_value)
        return "*" if spec.cardinality==FUNCTIONAL else self._obj_key(object_kind,object_value)

    def set_constitutional_mode(self,mode:str):
        m=str(mode or LEGACY).upper()
        if m not in {LEGACY,STRICT}:raise ValueError("bad constitutional mode")
        self.constitutional_mode=m
        self.audit.append({"order":int(self.order),"type":"CONSTITUTION_MODE","mode":m,"version":self.constitution_version})
        return m

    def _hardened_mutation(self, *, operation, subject, relation, origin, authority,
                           constitutional_basis, verified):
        """Opt-in common mutation boundary for new/live experiments.

        Origins/bases are untrusted caller metadata. This policy deliberately
        refuses raw OBS/RECEIPT/WORLD promotion until an independently verified
        boundary mechanism exists. It never turns a claim into a world fact.
        """
        if not getattr(self,"hardened_gate",False):
            return None
        org=str(origin or '').upper();auth=str(authority or '').upper()
        basis=str(constitutional_basis or '').upper();rel=rel_norm(relation)
        op=str(operation or '').upper()
        if org in {'USER_SAID','CREATOR_PRIOR','EXTERNAL_CORPUS','OBS','RECEIPT','SIMULATION','MODEL'}:
            # Social self-report is a fact about a reporting relationship, not WORLD.
            ent=self.entities.get(subject)
            identity=(ent.label.upper() if ent and ent.kind=='identity' else '')
            social=(org=='USER_SAID' and auth=='SOCIAL_REPORT' and (
                (basis in {'SOCIAL_NAMING','SOCIAL_CORRECTION','SOCIAL_SELF_REPORT'} and
                 rel=='NAME' and identity in {'SELF','USER'}) or
                (basis=='SOCIAL_SELF_REPORT' and rel in {'LIKES','HAS','ROLE'} and identity=='USER')))
            # Linguistic conventions are separately scoped and don't make WORLD claims.
            from .scope import LANGUAGE_RELATIONS
            linguistic=(org=='USER_SAID' and auth=='TEACHER' and
                        basis=='LANGUAGE_CONVENTION' and rel in LANGUAGE_RELATIONS)
            if social or linguistic:
                return None
            if op=='FORGET':
                return ConstitutionDecision('REJECT','COMMIT','MASK','HARDENED_UNTRUSTED_RETRACTION')
            return ConstitutionDecision('CLAIM_ONLY','EVAL','STATUS','HARDENED_UNGROUNDED_SOURCE')
        if org=='SYSTEM' and auth=='SYSTEM' and basis in {'SYSTEM_INVARIANT'}:
            return None
        if op=='FORGET':
            return ConstitutionDecision('REJECT','COMMIT','MASK','HARDENED_UNAUTHORIZED_RETRACTION')
        return ConstitutionDecision('CLAIM_ONLY','EVAL','STATUS','HARDENED_UNKNOWN_MUTATION_ORIGIN')

    def _record_claim_only(self,subject,relation,object_value,*,object_kind="literal",
                           origin="USER_SAID",principal="SELF",privacy="PRIVATE",authority="USER",
                           confidence=1.0,source_ref=None,source_group=None,polarity="POS",
                           requested_operation="COMMIT",decision_reason="SOURCE_ASSERTION"):
        """Persist the assertion/evidence without installing it in canonical truth."""
        self.order+=1
        rel=rel_norm(relation);spec=self.relation_spec(rel);polarity=str(polarity).upper()
        if polarity not in {"POS","NEG"}:raise ValueError("bad polarity")
        if object_kind not in {"literal","entity"}:raise ValueError("bad object_kind")
        if spec.object_mode=="entity" and object_kind!="entity":raise ValueError(f"{rel} requires entity object")
        if spec.object_mode=="literal" and object_kind!="literal":raise ValueError(f"{rel} requires literal object")
        incoming_group=str(source_group or source_ref or f'{origin}:{principal}')
        self.relation_templates.add(rel)
        fid=self._fact_id(subject,rel,principal,self.order)
        f=Fact(fact_id=fid,subject=subject,relation=rel,object_kind=object_kind,object_value=str(object_value),origin=origin,principal=principal,privacy=privacy,
               status="SOURCE_ASSERTED",authority=authority,confidence=float(confidence),order=self.order,source_ref=source_ref,correction_of=None,polarity=polarity,source_group=incoming_group)
        self.facts[fid]=f
        self._record_evidence(subject,rel,object_kind,str(object_value),polarity,principal,origin,authority,confidence,incoming_group,source_ref)
        self.audit.append({"order":self.order,"type":"CONSTITUTION_CLAIM_ONLY","fact_id":fid,"requested_operation":requested_operation,
                           "owner":"EVAL","influence":"STATUS","reason":decision_reason,"constitution":self.constitution_version})
        return f

    def _commit_unchecked(self,subject:str,relation:str,object_value:str,*,object_kind="literal",
               origin="USER_SAID",principal="SELF",privacy="PRIVATE",authority="USER",
               confidence=1.0,source_ref=None,source_group=None,polarity="POS")->Fact:
        self.order+=1
        rel=rel_norm(relation);spec=self.relation_spec(rel);polarity=str(polarity).upper()
        if polarity not in {"POS","NEG"}:raise ValueError("bad polarity")
        if object_kind not in {"literal","entity"}: raise ValueError("bad object_kind")
        incoming_group=str(source_group or source_ref or f'{origin}:{principal}')
        if spec.object_mode=="entity" and object_kind!="entity":
            raise ValueError(f"{rel} requires entity object")
        if spec.object_mode=="literal" and object_kind!="literal":
            raise ValueError(f"{rel} requires literal object")
        self.relation_templates.add(rel)
        slot=self._slot(rel,object_kind,str(object_value),polarity)
        key=(subject,rel,principal,slot)
        prev_id=self.canonical.get(key);correction_of=None
        if prev_id:
            prev=self.facts[prev_id]
            if prev.status in ACTIVE_STATUSES and prev.object_value==str(object_value) and prev.object_kind==object_kind and prev.polarity==polarity:
                self._record_evidence(subject,rel,object_kind,str(object_value),polarity,principal,origin,authority,confidence,incoming_group,source_ref)
                self.audit.append({"order":self.order,"type":"DEDUP","fact_id":prev_id});return prev
            # Functional positive values share one canonical slot. Defer different-value
            # handling to the source-aware block below instead of last-write-wins here.
            if not (spec.cardinality==FUNCTIONAL and polarity=='POS' and prev.polarity=='POS'):
                prev.status="TOMBSTONED";self._touch_fact(prev);correction_of=prev.fact_id;self._canonical_pop(key)
        # Same source may revise its own stance. Independent-source disagreement is
        # evidence conflict, not a silent canonical correction.
        for old_key in list(self._slot_index.get((subject,rel,principal),())):
            old_fid=self.canonical[old_key]
            old=self.facts[old_fid]
            if old.status in ACTIVE_STATUSES and old.object_kind==object_kind and old.object_value==str(object_value) and old.polarity!=polarity:
                if self._fact_source_group(old)==incoming_group:
                    old.status="TOMBSTONED";self._touch_fact(old);correction_of=old.fact_id;self._canonical_pop(old_key)
                else:
                    self._record_evidence(subject,rel,object_kind,str(object_value),polarity,principal,origin,authority,confidence,incoming_group,source_ref)
                    self.audit.append({"order":self.order,"type":"EVIDENCE_CONFLICT","fact_id":old.fact_id,"incoming_polarity":polarity,"source_group":incoming_group})
                    return old
        # A positive FUNCTIONAL relation only auto-replaces the same source's previous
        # value. Another source creates disagreement evidence instead.
        if spec.cardinality==FUNCTIONAL and polarity=="POS":
            for old_key in list(self._slot_index.get((subject,rel,principal),())):
                old_fid=self.canonical[old_key]
                old=self.facts[old_fid]
                if old.status in ACTIVE_STATUSES and old.polarity=="POS" and not (old.object_kind==object_kind and old.object_value==str(object_value)):
                    if self._fact_source_group(old)==incoming_group:
                        old.status="TOMBSTONED";self._touch_fact(old);correction_of=old.fact_id;self._canonical_pop(old_key)
                    else:
                        self._record_evidence(subject,rel,object_kind,str(object_value),polarity,principal,origin,authority,confidence,incoming_group,source_ref)
                        self.audit.append({"order":self.order,"type":"FUNCTIONAL_EVIDENCE_CONFLICT","fact_id":old.fact_id,"incoming_object":str(object_value),"source_group":incoming_group})
                        return old
        fid=self._fact_id(subject,rel,principal,self.order)
        f=Fact(fact_id=fid,subject=subject,relation=rel,object_kind=object_kind,object_value=str(object_value),origin=origin,principal=principal,privacy=privacy,
               status="REVISED" if correction_of else "ADMITTED",authority=authority,confidence=float(confidence),order=self.order,source_ref=source_ref,correction_of=correction_of,polarity=polarity,source_group=incoming_group)
        self.facts[fid]=f;self._canonical_set(key,fid)
        if rel=="WORD_FORM":self.lexicon_revision+=1
        self._record_evidence(subject,rel,object_kind,str(object_value),polarity,principal,origin,authority,confidence,incoming_group,source_ref)
        self.audit.append({"order":self.order,"type":"COMMIT","fact_id":fid,"correction_of":correction_of,"slot":slot,"polarity":polarity})
        return f


    def commit(self,subject:str,relation:str,object_value:str,*,object_kind="literal",
               origin="USER_SAID",principal="SELF",privacy="PRIVATE",authority="USER",
               confidence=1.0,source_ref=None,source_group=None,polarity="POS",
               constitutional_basis=None,verified=False)->Fact:
        decision=self._hardened_mutation(operation="COMMIT",subject=subject,relation=relation,origin=origin,
                                         authority=authority,constitutional_basis=constitutional_basis,verified=verified)
        if decision is None:
            decision=evaluate_mutation(mode=getattr(self,'constitutional_mode',LEGACY),operation="COMMIT",origin=origin,authority=authority,
                                       constitutional_basis=constitutional_basis,verified=bool(verified))
        if decision.disposition=="COMMIT":
            f=self._commit_unchecked(subject,relation,object_value,object_kind=object_kind,origin=origin,principal=principal,privacy=privacy,authority=authority,
                                     confidence=confidence,source_ref=source_ref,source_group=source_group,polarity=polarity)
            if getattr(self,'constitutional_mode',LEGACY)==STRICT:
                self.audit.append({"order":self.order,"type":"CONSTITUTION_COMMIT","fact_id":f.fact_id,"owner":decision.owner,"influence":decision.influence,
                                   "basis":decision.reason,"constitution":self.constitution_version})
            return f
        if decision.disposition=="CLAIM_ONLY":
            return self._record_claim_only(subject,relation,object_value,object_kind=object_kind,origin=origin,principal=principal,privacy=privacy,authority=authority,
                                           confidence=confidence,source_ref=source_ref,source_group=source_group,polarity=polarity,
                                           requested_operation="COMMIT",decision_reason=decision.reason)
        raise ValueError(decision.reason)

    def commit_entity(self,subject:str,relation:str,object_label_or_id:str,*,object_kind="concept",**kw)->Fact:
        oid=object_label_or_id if object_label_or_id in self.entities else self.entity(object_label_or_id,object_kind)
        return self.commit(subject,relation,oid,object_kind="entity",**kw)

    def replace_relation(self,subject:str,relation:str,object_value:str,*,object_kind="literal",principal="SELF",
                         constitutional_basis=None,verified=False,**kw)->Fact:
        origin=kw.get("origin","USER_SAID");authority=kw.get("authority","USER")
        decision=self._hardened_mutation(operation="REPLACE",subject=subject,relation=relation,origin=origin,
                                         authority=authority,constitutional_basis=constitutional_basis,verified=verified)
        if decision is None:
            decision=evaluate_mutation(mode=getattr(self,'constitutional_mode',LEGACY),operation="REPLACE",origin=origin,authority=authority,
                                       constitutional_basis=constitutional_basis,verified=bool(verified))
        if decision.disposition!="COMMIT":
            return self._record_claim_only(subject,relation,object_value,object_kind=object_kind,principal=principal,
                                           origin=origin,privacy=kw.get("privacy","PRIVATE"),authority=authority,confidence=kw.get("confidence",1.0),
                                           source_ref=kw.get("source_ref"),source_group=kw.get("source_group"),polarity=kw.get("polarity","POS"),
                                           requested_operation="REPLACE",decision_reason=decision.reason)
        rel=rel_norm(relation)
        replaced=[]
        for k in list(self._slot_index.get((subject,rel,principal),())):
            fid=self.canonical[k]
            f0=self.facts[fid];f0.status="TOMBSTONED";self._touch_fact(f0);replaced.append(fid);self._canonical_pop(k)
        f=self._commit_unchecked(subject,rel,object_value,object_kind=object_kind,principal=principal,**kw)
        if replaced:
            f.status="REVISED"; f.correction_of=max(replaced,key=lambda fid:self.facts[fid].order);self._touch_fact(f)
            self.audit.append({"order":self.order,"type":"REPLACE_RELATION","fact_id":f.fact_id,"replaced":replaced})
        return f

    def _forget_unchecked(self,subject:str,relation:str,*,principal="SELF",object_kind:Optional[str]=None,object_value:Optional[str]=None)->bool:
        rel=rel_norm(relation);hits=[]
        for k in list(self._slot_index.get((subject,rel,principal),())):
            fid=self.canonical[k]
            f=self.facts[fid]
            if object_value is not None and not (f.object_value==str(object_value) and (object_kind is None or f.object_kind==object_kind)):continue
            hits.append((k,fid))
        self.order+=1
        if not hits:
            self.audit.append({"order":self.order,"type":"FORGET_MISS","subject":subject,"relation":rel});return False
        for k,fid in hits:
            self._canonical_pop(k);f0=self.facts[fid];f0.status="TOMBSTONED";self._touch_fact(f0)
        if rel=="WORD_FORM":self.lexicon_revision+=1
        self.audit.append({"order":self.order,"type":"FORGET","fact_ids":[fid for _,fid in hits]});return True

    def forget(self,subject:str,relation:str,*,principal="SELF",object_kind:Optional[str]=None,object_value:Optional[str]=None,
               origin="SYSTEM",authority="SYSTEM",constitutional_basis=None,verified=False)->bool:
        decision=self._hardened_mutation(operation="FORGET",subject=subject,relation=relation,origin=origin,
                                         authority=authority,constitutional_basis=constitutional_basis,verified=verified)
        if decision is None:
            decision=evaluate_mutation(mode=getattr(self,'constitutional_mode',LEGACY),operation="FORGET",origin=origin,authority=authority,
                                       constitutional_basis=constitutional_basis,verified=bool(verified))
        if decision.disposition!="COMMIT":
            self.order+=1
            self.audit.append({"order":self.order,"type":"CONSTITUTION_BLOCK_FORGET","subject":subject,"relation":rel_norm(relation),
                               "owner":decision.owner,"influence":decision.influence,"reason":decision.reason,"constitution":self.constitution_version})
            return False
        ok=self._forget_unchecked(subject,relation,principal=principal,object_kind=object_kind,object_value=object_value)
        if getattr(self,'constitutional_mode',LEGACY)==STRICT:
            self.audit.append({"order":self.order,"type":"CONSTITUTION_FORGET","subject":subject,"relation":rel_norm(relation),
                               "owner":decision.owner,"influence":decision.influence,"basis":decision.reason,"constitution":self.constitution_version})
        return ok

    def retract_latest_source_assertion(self,*,source_group,principal="SELF",origin="USER_SAID",authority="USER",
                                       constitutional_basis="SOURCE_SELF_RETRACTION"):
        """Retract the latest assertion event from the same source without asserting its opposite.

        This only changes STATUS on SOURCE_ASSERTED history. Canonical truth is untouched.
        Multiple facts produced from one utterance (same source_ref) retract together.
        """
        decision=evaluate_mutation(mode=getattr(self,'constitutional_mode',LEGACY),operation="CLAIM_RETRACT",origin=origin,authority=authority,
                                   constitutional_basis=constitutional_basis,verified=False)
        if decision.disposition!="COMMIT":
            return []
        cand=[f for f in self.facts.values() if f.principal==principal and f.status=="SOURCE_ASSERTED" and self._fact_source_group(f)==str(source_group)]
        if not cand:return []
        last=max(cand,key=lambda f:f.order);ref=last.source_ref
        hits=[f for f in cand if (ref is not None and f.source_ref==ref) or (ref is None and f.fact_id==last.fact_id)]
        self.order+=1
        for f in hits:
            f.status="RETRACTED";self._touch_fact(f)
        self.audit.append({"order":self.order,"type":"SOURCE_ASSERTION_RETRACT","fact_ids":[f.fact_id for f in hits],
                           "source_group":str(source_group),"owner":"COMMIT","influence":"STATUS","basis":decision.reason,
                           "constitution":self.constitution_version})
        return [f.fact_id for f in hits]

    def atomic_rebind_latest_relation(self,*,from_subject:str,to_subject:str,relation:str,source_group:str,
                                      principal="SELF",origin="USER_SAID",authority="SOCIAL_REPORT",
                                      constitutional_basis="SOCIAL_CORRECTION",source_ref=None):
        """Atomically rebind the latest source-owned functional relation to another subject.

        The correction carries no new object value: it may only reuse the value from the
        concrete prior claim it corrects.  This prevents a deictic correction such as
        «не меня, а тебя» from inventing a new name.
        """
        decision=evaluate_mutation(mode=getattr(self,'constitutional_mode',LEGACY),operation="REPLACE",origin=origin,authority=authority,
                                   constitutional_basis=constitutional_basis,verified=False)
        if decision.disposition!="COMMIT":
            self.order+=1;self.audit.append({"order":self.order,"type":"CONSTITUTION_BLOCK_REBIND","from":from_subject,"to":to_subject,
                                              "relation":rel_norm(relation),"reason":decision.reason})
            return None
        rel=rel_norm(relation);spec=self.relation_spec(rel)
        if spec.cardinality!=FUNCTIONAL:
            self.order+=1;self.audit.append({"order":self.order,"type":"REBIND_REJECT","reason":"NON_FUNCTIONAL_RELATION","relation":rel})
            return None
        group=str(source_group)
        cand=[]
        for key in list(self._slot_index.get((from_subject,rel,principal),())):
            fid=self.canonical.get(key);f=self.facts.get(fid) if fid else None
            if f and f.status in ACTIVE_STATUSES and self._fact_source_group(f)==group and f.polarity=='POS':cand.append((key,f))
        if not cand:
            self.order+=1;self.audit.append({"order":self.order,"type":"REBIND_MISS","from":from_subject,"to":to_subject,"relation":rel,"source_group":group})
            return None
        old_key,old=max(cand,key=lambda kf:kf[1].order)
        # The object is inherited from the concrete old claim; correction text cannot supply another one.
        new=self._commit_unchecked(to_subject,rel,old.object_value,object_kind=old.object_kind,origin=origin,principal=principal,
                                   privacy=old.privacy,authority=authority,confidence=old.confidence,
                                   source_ref=source_ref or old.source_ref,source_group=group,polarity=old.polarity)
        # If target admission was blocked by independent functional conflict, _commit_unchecked
        # returns the conflicting old target fact.  Do not destroy the source claim in that case.
        if new.subject!=to_subject or new.object_value!=old.object_value:
            self.audit.append({"order":self.order,"type":"REBIND_REJECT","reason":"TARGET_CONFLICT","from_fact":old.fact_id,"target_fact":new.fact_id})
            return None
        if self.canonical.get(old_key)==old.fact_id:self._canonical_pop(old_key)
        old.status="TOMBSTONED";self._touch_fact(old)
        if new.fact_id!=old.fact_id:
            new.correction_of=old.fact_id
            if new.status=="ADMITTED":new.status="REVISED"
            self._touch_fact(new)
        txid="tx:"+hashlib.blake2s(f"{old.fact_id}|{new.fact_id}|{self.order}".encode(),digest_size=8).hexdigest()
        self.audit.append({"order":self.order,"type":"ATOMIC_RELATION_REBIND","transaction_id":txid,"from_fact":old.fact_id,"to_fact":new.fact_id,
                           "from_subject":from_subject,"to_subject":to_subject,"relation":rel,"object_value":old.object_value,
                           "owner":"COMMIT","influence":"STATUS","basis":decision.reason,"constitution":self.constitution_version})
        return {"transaction_id":txid,"from_fact":old.fact_id,"to_fact":new.fact_id,"object_value":old.object_value}

    def _visible(self,f:Fact,viewer,principal,scope=None)->bool:
        if f.status not in ACTIVE_STATUSES:return False
        if f.privacy=="PRIVATE" and f.origin not in {"CREATOR_PRIOR","EXTERNAL_CORPUS","OBS","RECEIPT"} and viewer not in {principal,"CREATOR"}:return False
        if getattr(self,'constitutional_mode',LEGACY)==STRICT:
            return scope_allows(fact_scope(self,f),scope or KNOWLEDGE)
        return True

    def fact_scope(self,f:Fact)->str:
        return fact_scope(self,f)

    def get_all(self,subject:str,relation:str,*,viewer="SELF",principal="SELF",polarity="POS",scope=None)->List[Fact]:
        rel=rel_norm(relation);out=[]
        for key in self._slot_index.get((subject,rel,principal),()):
            f=self.facts[self.canonical[key]]
            if (polarity is None or f.polarity==polarity) and self._visible(f,viewer,principal,scope=scope):out.append(f)
        return sorted(out,key=lambda f:f.order)

    def get(self,subject:str,relation:str,*,viewer="SELF",principal="SELF",polarity="POS",scope=None)->Optional[Fact]:
        vals=self.get_all(subject,relation,viewer=viewer,principal=principal,polarity=polarity,scope=scope)
        return vals[-1] if vals else None

    def truth(self,subject:str,relation:str,object_value:str,*,object_kind="literal",viewer="SELF",principal="SELF",scope=None)->str:
        rel=rel_norm(relation);target=str(object_value)
        for pol,val in (("POS","TRUE"),("NEG","FALSE")):
            for f in self.get_all(subject,rel,viewer=viewer,principal=principal,polarity=pol,scope=scope):
                if f.object_kind==object_kind and f.object_value==target:return val
        return "UNKNOWN"

    def facts_about(self,subject:str,*,viewer="SELF",principal="SELF",polarity=None,scope=None)->List[Fact]:
        out=[]
        for key in self._subject_index.get((subject,principal),()):
            f=self.facts[self.canonical[key]]
            if (polarity is None or f.polarity==polarity) and self._visible(f,viewer,principal,scope=scope):out.append(f)
        return sorted(out,key=lambda x:x.order)

    def reverse_facts(self,relation:str,object_value:str,*,object_kind="literal",viewer="SELF",principal="SELF",polarity="POS",scope=None)->List[Fact]:
        rel=rel_norm(relation);out=[]
        for key in self._object_index.get((rel,principal,object_kind,str(object_value)),()):
            fid=self.canonical.get(key)
            if fid is None:continue
            f=self.facts[fid]
            if (polarity is None or f.polarity==polarity) and self._visible(f,viewer,principal,scope=scope):out.append(f)
        return sorted(out,key=lambda f:f.order)

    def source_assertions(self,subject=None,relation=None,*,principal=None):
        rel=rel_norm(relation) if relation else None;out=[]
        for f in self.facts.values():
            if fact_scope(self,f)!=SOURCE_ASSERTION:continue
            if subject is not None and f.subject!=subject:continue
            if rel is not None and f.relation!=rel:continue
            if principal is not None and f.principal!=principal:continue
            out.append(f)
        return sorted(out,key=lambda x:x.order)

    def scope_stats(self):
        from collections import Counter
        c=Counter()
        for f in self.facts.values():c[fact_scope(self,f)]+=1
        return dict(c)

    # ---- G270: queries the organs use instead of scanning every fact (indexed in the disk store)
    def facts_with_relation(self,relation:str,*,viewer="SELF",principal="SELF",polarity="POS")->List[Fact]:
        rel=rel_norm(relation);out=[]
        for key,fid in self.canonical.items():
            if key[1]!=rel or key[2]!=principal:continue
            f=self.facts[fid]
            if (polarity is None or f.polarity==polarity) and self._visible(f,viewer,principal):out.append(f)
        return sorted(out,key=lambda f:f.order)

    def active_facts(self,*,viewer="SELF",principal="SELF",origin=None,exclude_relations=(),newest_first=False,limit=None,lazy=False):
        """Visible ADMITTED/REVISED facts of one principal (optionally of one origin), in commit order."""
        ex=set(exclude_relations or ());out=[]
        for f in self.facts.values():
            if f.status not in ACTIVE_STATUSES or f.principal!=principal or f.relation in ex:continue
            if origin is not None and f.origin!=origin:continue
            if not self._visible(f,viewer,principal):continue
            out.append(f)
        out.sort(key=lambda f:f.order,reverse=bool(newest_first))
        out=out[:limit] if limit is not None else out
        return iter(out) if lazy else out

    def count_active(self,*,viewer="SELF",principal="SELF",origin=None,exclude_relations=()):
        return len(self.active_facts(viewer=viewer,principal=principal,origin=origin,exclude_relations=exclude_relations))

    def subject_count(self,*,viewer="SELF",principal="SELF",exclude_relations=()):
        return len({f.subject for f in self.active_facts(viewer=viewer,principal=principal,exclude_relations=exclude_relations)})

    def top_subjects(self,*,viewer="SELF",principal="SELF",exclude_relations=(),limit=80):
        """(subject, number of its visible active facts), most described first."""
        from collections import Counter
        cnt=Counter(f.subject for f in self.active_facts(viewer=viewer,principal=principal,exclude_relations=exclude_relations))
        return cnt.most_common(limit)

    def object_surface(self,f:Fact)->str:
        return self.label(f.object_value) if f.object_kind=="entity" else f.object_value

    def stats(self):
        return {"entities":len(self.entities),"active_facts":len(self.canonical),"fact_history":len(self.facts),
                "relation_templates":len(self.relation_templates),"relation_schemas":len(self.relation_specs),"evidence_records":len(self.evidence)}

    def to_dict(self):
        # G269: same content as dataclasses.asdict, without its recursive deep copy (2-3x faster checkpoints/autosave)
        ef=_field_names(Entity);ff=_field_names(Fact);sf=_field_names(RelationSpec);rf=_field_names(EvidenceRecord);vf=_field_names(EvidenceSource)
        def ent(x):
            d={n:getattr(x,n) for n in ef};d["aliases"]=list(x.aliases);return d
        def ev(x):
            d={n:getattr(x,n) for n in rf}
            d["sources"]={k:{n:getattr(v,n) for n in vf} for k,v in (x.sources or {}).items()}
            return d
        out={
            "schema":"C4_GRAPH_L6_V0.3","order":self.order,
            "entities":[ent(x) for x in self.entities.values()],
            "facts":[{n:getattr(x,n) for n in ff} for x in self.facts.values()],
            "canonical":[[s,r,p,slot,fid] for (s,r,p,slot),fid in self.canonical.items()],
            "relation_templates":sorted(self.relation_templates),
            "relation_specs":[{n:getattr(x,n) for n in sf} for x in self.relation_specs.values()],
            "evidence":[ev(x) for x in self.evidence.values()],
            "audit":self.audit,
        }
        # Preserve byte-identical legacy export. Constitution metadata is serialized
        # only for an explicitly constitutional live candidate.
        if getattr(self,"constitutional_mode",LEGACY)!=LEGACY:
            out["constitutional_mode"]=getattr(self,"constitutional_mode",LEGACY)
            out["constitution_version"]=getattr(self,"constitution_version",CONSTITUTION_VERSION)
        if getattr(self,"hardened_gate",False):out["hardened_gate"]=True
        return out

    @classmethod
    def from_dict(cls,d):
        g=cls()
        if g.store_kind!="memory":          # G270: a disk-backed graph loads the same dict into its tables
            g._load_dict(d);return g
        g.order=int(d["order"])
        for x in d["entities"]:
            e=Entity(**x);g.entities[e.entity_id]=e
            for a in e.aliases:
                g.alias_index[(e.kind,alias_norm(e.kind,a))]=e.entity_id
                g._index_alias(e.kind,a,e.entity_id)
        for x in d["facts"]:
            f=Fact(**x);g.facts[f.fact_id]=f
        # v0.1 compatibility: [s,r,p,fid] -> functional slot
        g.canonical={}
        for row in d["canonical"]:
            if len(row)==4:
                s,r,p,fid=row;slot="*"
            else:
                s,r,p,slot,fid=row
            key=(s,r,p,slot);g.canonical[key]=fid;g._index_canonical_add(key)
        g.relation_templates=set(d.get("relation_templates",[]))
        for x in d.get("relation_specs",[]):
            spec=RelationSpec(**x);g.relation_specs[spec.relation]=spec
        g.evidence={};g._evidence_slot_index={}
        if 'evidence' in d:
            for x in d.get('evidence',[]):
                sources={k:EvidenceSource(**v) for k,v in (x.get('sources') or {}).items()}
                rec=EvidenceRecord(x['proposition_key'],int(x.get('total_count',0)),sources,x.get('subject',''),x.get('relation',''),x.get('object_kind',''),x.get('object_value',''),x.get('polarity','POS'),x.get('principal',''));g.evidence[rec.proposition_key]=rec;g._index_evidence_record(rec)
        else:
            g.rebuild_evidence_from_facts()
        g.lexicon_revision=sum(1 for f in g.facts.values() if f.relation=="WORD_FORM" and f.status in ACTIVE_STATUSES)
        g.audit=list(d.get("audit",[]));g.constitutional_mode=str(d.get("constitutional_mode",LEGACY)).upper();g.constitution_version=d.get("constitution_version",CONSTITUTION_VERSION);g.hardened_gate=bool(d.get("hardened_gate",False));return g

    def save(self,path):
        Path(path).write_text(json.dumps(self.to_dict(),ensure_ascii=False,separators=(",",":")),encoding="utf-8")
    @classmethod
    def load(cls,path):
        return cls.from_dict(json.loads(Path(path).read_text(encoding="utf-8")))

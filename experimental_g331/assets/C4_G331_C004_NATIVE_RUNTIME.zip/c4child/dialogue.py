from __future__ import annotations
import re
from .graph import C4Graph, norm, SET
from .language_ru import RussianChildLanguageV0, Intent
from .reasoner import StructuralReasoner
from .definition import DefinitionComposer
from .morphology_ru import RussianMorphologyV1
from .phrase_ru import RussianTypedPhraseV1
from .predicate_ru import RussianPredicateLexiconV1
from .relation_query_ru import RussianRelationQueryV1
from .quantifier_ru import RussianUniversalClassV1
from .oracles import ExactMathOracle
from .inflect_ru import RussianSpeechFormsV1
from .fact_retrieval import AdmittedFactRetriever, TECHNICAL_RELATIONS, STOPWORDS, stems as _stems, content_tokens, stem as _stem, stem_full as _stem_full
from .graph import ACTIVE_STATUSES
from collections import Counter

ENTITY_OBJECT_RELATIONS={"IS_A","PART_OF","OPPOSITE","CAUSES"}
PRONOUNS={"он","она","оно","они","его","ему","им","нём","нем","него","её","ее","ей","ею","ней","неё","нее","их","им","ими","них","этот","эта","это"}
_MASC_PRONOUNS={"он","его","ему","им","нём","нем","него"}
_FEM_PRONOUNS={"она","её","ее","ей","ею","ней","неё","нее"}
_NEUT_PRONOUNS={"оно"}
_PLURAL_PRONOUNS={"они","их","им","ими","них"}
_HUMAN_LABEL=re.compile(r"^[A-Za-zА-Яа-яЁё0-9 ,.'-]{2,32}$")
# «X — это?» / «X — это что?» ask for a definition, not for the truth of «X IS_A это».
_EMPTY_COPULA_OBJECTS={"","это","что","кто","такое","что такое","кто такой","кто такая","что это","кто это"}

class C4ChildDialogue:
    def __init__(self,graph=None,principal="USER"):
        self.g=graph or C4Graph();self.lang=RussianChildLanguageV0();self.principal=principal
        self.user_eid=self.g.entity("USER","identity",aliases=["я","меня","рус"])
        self.self_eid=self.g.entity("SELF","identity",aliases=["ты","тебя","c4"])
        self.last_claim=None
        self.focus_eid=None
        self.focus_stack=[]
        # G316: semantic anchors selected from the continuous life-line. These are
        # AVAIL/EVAL hints only; they never authorize graph mutation.
        self.context_eids=[]
        self.reasoner=StructuralReasoner(self.g)
        self.definitions=DefinitionComposer(self.g)
        self.morphology=RussianMorphologyV1(self.g)
        self.phrases=RussianTypedPhraseV1(self.g,self.morphology)
        self.predicates=RussianPredicateLexiconV1(self.g,self.morphology)
        self.relation_queries=RussianRelationQueryV1(self.g,self.morphology)
        self.quantified=RussianUniversalClassV1(self.lang,self.predicates)
        self.speech=RussianSpeechFormsV1(self.g,self.reasoner,principal)    # G269: case frames and agreement in speech
        # G267: the kernel gets the floor (read-only access + per-answer receipts for «почему?/подробнее»).
        self.retriever=AdmittedFactRetriever(self.g)
        self.last_used=[]          # fact_ids the last answer actually rested on
        self.last_explain=None     # explanation text for the last truth answer
        self.more=None             # {'label','items'} remainder of a bounded answer
        self.prev_stems=[]         # content stems of the previous user surface (discourse context)
        self.last_reply_kind=None  # ANSWER|FLOOR|SOCIAL|NOT_UNDERSTOOD for the transport layer
        self.last_unknown_words=[]
        # G269: a word being taught, the child's own open question / self-check, signals for the runtime
        self.teach_root=None       # entity whose meaning is being taught
        self.pending_ask=None      # {'label','eid'}: the child asked «Что такое X?»
        self.pending_confirm=None  # {'subject','relation','object'}: the child asked «Значит, X — Y?»
        self.gap_requests=[]       # gaps the runtime should register for this turn
        self.asked_in_reply=[]     # entity ids the child already asked about in this reply
        self.deferred_asks=[]      # «не знаю»: ask again later
        self._overview_cache=None
        self.last_spine_transaction=None

    def _touch_focus(self,eid):
        if not eid or eid in {self.user_eid,self.self_eid}:return
        self.focus_eid=eid
        self.focus_stack=[x for x in self.focus_stack if x!=eid]
        self.focus_stack.append(eid)
        self.focus_stack=self.focus_stack[-12:]

    def set_context_entities(self,eids):
        """Install read-only semantic anchors chosen from the runtime life-line.

        CONTEXT != EVIDENCE: these ids affect retrieval/deixis only. No entity is
        created and no fact/status is changed here.
        """
        out=[]
        for eid in eids or ():
            if eid in self.g.entities and eid not in {self.user_eid,self.self_eid} and eid not in out:
                out.append(eid)
        self.context_eids=out[-24:]

    def _pronoun_candidate(self,n):
        if n in _MASC_PRONOUNS:wanted="MASC"
        elif n in _FEM_PRONOUNS:wanted="FEM"
        elif n in _NEUT_PRONOUNS:wanted="NEUT"
        else:wanted=None
        # Referential priority: a parser focus that is ALSO present in the recent
        # life-line is strongest; generic context comes next; stale historical focus
        # is only a last fallback. This prevents a class object (Антон -> человек)
        # from stealing «он», without letting old focus override the current story.
        recent=set(self.context_eids)
        stale=[e for e in self.focus_stack if e not in recent]
        generic=[e for e in self.context_eids if e not in self.focus_stack]
        focused=[e for e in self.focus_stack if e in recent]
        pool=list(dict.fromkeys(stale+generic+focused))
        if wanted:
            for eid in reversed(pool):
                # Do not apply noun gender heuristics to lexical predicates. A verb
                # ending in -ть is not a feminine discourse referent.
                if self.g.get(eid,'PREDICATE_RELATION',viewer=self.principal,principal=self.principal):continue
                kinds=[norm(self.g.object_surface(f)) for f in self.g.get_all(eid,'IS_A',viewer=self.principal,principal=self.principal)]
                if 'глагол' in kinds:continue
                # Gender resolution is EVAL over admitted morphology; it does not
                # create a GRAM_GENDER fact merely to resolve a pronoun.
                if self.speech.gender(eid=eid)==wanted:return eid
        if n in {"этот","эта","это"}:return self.context_eids[-1] if self.context_eids else self.focus_eid
        if n in _PLURAL_PRONOUNS:return None
        return self.context_eids[-1] if self.context_eids else self.focus_eid

    _MY_FORMS={"мой":"твой","моя":"твоя","моё":"твоё","мое":"твое","мои":"твои","моего":"твоего","моей":"твоей","моему":"твоему",
               "мою":"твою","моим":"твоим","моём":"твоём","моем":"твоем","моих":"твоих","моими":"твоими"}
    _PERSPECTIVE={**_MY_FORMS,**{v:k for k,v in _MY_FORMS.items()}}

    def _perspective(self,label):
        """«моя дочь» from the user is «твоя дочь» for the child (and «твой X» is the child's «мой X»)."""
        if not isinstance(label,str):return label
        toks=label.strip().split()
        if len(toks)>=2 and toks[0].lower() in self._PERSPECTIVE:
            return " ".join([self._PERSPECTIVE[toks[0].lower()]]+toks[1:])
        return label

    def _eid(self,label,update_focus=False):
        n=norm(label)
        if n in {"я","user","меня","мне"}:eid=self.user_eid
        elif n in {"ты","self","тебя"}:eid=self.self_eid
        elif n in PRONOUNS:
            eid=self._pronoun_candidate(n)
            if eid is None:
                # Do not create a durable concept for an unresolved pronoun.
                return None
        else:
            hit=self.g.resolve(label) or self.morphology.resolve(label)
            eid=hit or self.g.entity(label,"concept")
        if update_focus:self._touch_focus(eid)
        return eid

    def _obj(self,it:Intent):
        # Relation schema, not Russian surface code, owns object typing.
        spec=self.g.relation_spec(it.relation)
        if spec.object_mode=="entity":
            return "entity", self._eid(it.object,update_focus=False)
        if spec.object_mode=="literal":
            return "literal", it.object
        # `either` remains conservative: historically entity-semantic relations may
        # bind an existing concept, otherwise the surface stays literal.
        if it.relation in ENTITY_OBJECT_RELATIONS:
            return "entity", self._eid(it.object,update_focus=False)
        obj=self._perspective(it.object) if it.relation in {"LIKES","HAS"} else it.object
        hit=self.g.resolve(obj) or self.morphology.resolve(obj)
        return ("entity",hit) if hit else ("literal",obj)

    def _claim(self,it:Intent,origin="USER_SAID",replace=False):
        out=self._commit_claim(it,origin,replace)
        if isinstance(out,str):return out
        s,facts=out
        rendered=" ".join(self._render(s,f) for f in facts)
        if rendered.startswith(("Тебя ","Меня ","Ты ","Ты:","Я ","Я:","У ")):rendered=rendered[:1].lower()+rendered[1:]
        if facts and all(getattr(f,"status",None)=="SOURCE_ASSERTED" for f in facts):
            return f"Приняла как твоё утверждение: {rendered} Источник сохранён, но подтверждённым фактом это не стало."
        return f"Запомнила: {rendered} Источник: ты мне это сообщил."

    def _commit_claim(self,it:Intent,origin="USER_SAID",replace=False,human_teaching=False):
        s=self._eid(self._perspective(it.subject),update_focus=True)     # G269: «моя дочь» is the child's «твоя дочь»
        if s is None:return "Не понимаю, к кому или к чему относится местоимение. Уточни."
        ok,ov=self._obj(it)
        if ok=="entity" and ov is None:return "Не понимаю ссылку на объект. Уточни."
        basis=None;authority="USER"
        if str(it.relation).upper()=="NAME" and s in {self.user_eid,self.self_eid}:
            basis="SOCIAL_SELF_REPORT" if s==self.user_eid else "SOCIAL_NAMING"
            authority="SOCIAL_REPORT"
        elif s==self.user_eid and str(it.relation).upper() in {"LIKES","HAS","ROLE"}:
            basis="SOCIAL_SELF_REPORT";authority="SOCIAL_REPORT"
        else:
            # A source statement becomes human-teaching knowledge only when the
            # utterance explicitly declares teaching OR semantically answers the
            # exact open subject. Adjacency alone is never sufficient.
            pa=getattr(self,'pending_ask',None)
            matches_open=bool(pa and pa.get('eid')==s)
            explicit_teach=str(getattr(it,'kind','')).upper()=="REMEMBER_CLAIM"
            if origin=="USER_SAID" and (human_teaching or matches_open or explicit_teach):
                basis="HUMAN_TEACHING";authority="TEACHER"
        kw=dict(origin=origin,principal=self.principal,privacy="PRIVATE",authority=authority,source_ref=it.raw,source_group=f"USER:{self.principal}",
                constitutional_basis=basis)
        spec=self.g.relation_spec(it.relation)
        parts=[it.object]
        if spec.cardinality==SET and not replace:
            parts=[]
            for x in re.split(r"\s+и\s+|,\s*",it.object):
                x=re.sub(r"^(?:либо|или|а\s+также)\s+","",x.strip(),flags=re.IGNORECASE)
                if x:parts.append(x)
        facts=[]
        if len(parts)>1:
            for part in parts:
                pit=Intent(it.kind,it.subject,it.relation,part,it.raw,it.polarity);pok,pov=self._obj(pit)
                facts.append(self.g.commit(s,it.relation,pov,object_kind=pok,polarity=it.polarity,**kw))
        else:
            if replace:facts=[self.g.replace_relation(s,it.relation,ov,object_kind=ok,polarity=it.polarity,**kw)]
            else:facts=[self.g.commit(s,it.relation,ov,object_kind=ok,polarity=it.polarity,**kw)]
        if getattr(self,'pending_ask',None) and self.pending_ask.get('eid')==s and basis=="HUMAN_TEACHING":
            self.pending_ask=None
        self.last_claim=(s,it.relation)
        return s,facts

    def _event_claim(self,it:Intent,tense="PAST"):
        s=self._eid(it.subject,update_focus=True)
        if s is None:return "Не понимаю, к кому относится событие. Уточни."
        spec=self.g.relation_spec(it.relation)
        # G304: a positive conjunction on a SET-valued predicate can be safely
        # decomposed into proposition-events, but only when the whole surface is
        # not already a known lexical entity.  NEGATED CONJUNCTION is deliberately
        # NOT distributed: `не любил чай и сок` does not license two independent
        # negative propositions without explicit scope evidence.
        parts=[it.object]
        if it.polarity=="POS" and spec.cardinality==SET:
            whole=self.g.resolve(it.object) or self.morphology.resolve(it.object)
            if whole is None:
                xs=[x.strip() for x in re.split(r"\s+и\s+|,\s*",it.object) if x.strip()]
                if len(xs)>1:parts=xs
        kw=dict(origin="USER_SAID",principal=self.principal,privacy="PRIVATE",authority="USER",source_ref=it.raw,source_group=f"USER:{self.principal}")
        made=0
        for idx,part in enumerate(parts):
            pit=Intent(it.kind,it.subject,it.relation,part,it.raw,it.polarity)
            ok,ov=self._obj(pit)
            if ok=="entity" and ov is None:return "Не понимаю объект события. Уточни."
            import hashlib
            raw=f"{self.g.order+1}|{s}|{it.relation}|{ok}|{ov}|{tense}|{it.raw}|{idx}".encode('utf-8')
            lab="episode:"+hashlib.blake2s(raw,digest_size=8).hexdigest()
            e=self.g.entity(lab,"event")
            self.g.commit(e,"EVENT_PREDICATE",it.relation,object_kind="literal",**kw)
            self.g.commit(e,"EVENT_SUBJECT",s,object_kind="entity",**kw)
            self.g.commit(e,"EVENT_OBJECT",ov,object_kind=ok,**kw)
            self.g.commit(e,"EVENT_TENSE",tense,object_kind="literal",**kw)
            self.g.commit(e,"EVENT_POLARITY",it.polarity,object_kind="literal",**kw)
            made+=1
        if str(tense).upper()=="FUTURE":
            return "Запомнила это как сообщение о будущем, а не как текущее состояние и не как подтверждённый исход."
        return "Запомнила это как прошлый эпизод, а не как текущее состояние."

    # G268: facts about USER/SELF are spoken from the child's side: «Ты — мой создатель.», «Я люблю …».
    _DEIXIS_POS={"USER":{"IS_A":"Ты — {o}.","ROLE":"Ты — {o}.","LIKES":"Ты любишь {o}.","CAN":"Ты можешь {o}.","HAS":"У тебя есть {o}.",
                         "LOCATION":"Ты находишься: {o}.","PROPERTY":"Ты: {o}."},
                 "SELF":{"IS_A":"Я — {o}.","ROLE":"Я — {o}.","LIKES":"Я люблю {o}.","CAN":"Я могу {o}.","HAS":"У меня есть {o}.",
                         "LOCATION":"Я нахожусь: {o}.","PROPERTY":"Я: {o}."}}
    _DEIXIS_NEG={"USER":{"IS_A":"Ты — не {o}.","ROLE":"Ты — не {o}.","LIKES":"Ты не любишь {o}.","CAN":"Ты не можешь {o}.","HAS":"У тебя нет {o}."},
                 "SELF":{"IS_A":"Я — не {o}.","ROLE":"Я — не {o}.","LIKES":"Я не люблю {o}.","CAN":"Я не могу {o}.","HAS":"У меня нет {o}."}}

    def _render(self,s,f):
        if f.relation=="NAME" and f.polarity=="POS" and s in {self.user_eid,self.self_eid}:
            return ("Тебя" if s==self.user_eid else "Меня")+f" зовут {self.g.object_surface(f)}."
        sc,oc=self.lang.case_frame(f.relation,f.polarity)
        o=self._obj_case(f,oc,strict=(oc=="gen")) if oc else self.g.object_surface(f)
        if s in {self.user_eid,self.self_eid}:
            who="USER" if s==self.user_eid else "SELF";o=self.g.object_surface(f) if o is None else o
            if f.relation=="PROPERTY" and self.speech.is_adjective(o):
                return ("Ты " if who=="USER" else "Я ")+("не " if f.polarity=="NEG" else "")+self.speech.agree(o,gender=self._deixis_gender(s))+"."
            forms=self._DEIXIS_POS[who] if f.polarity=="POS" else self._DEIXIS_NEG[who]
            default=("Ты: {o}." if who=="USER" else "Я: {o}.") if f.polarity=="POS" else ("Ты: неверно, что {o}." if who=="USER" else "Я: неверно, что {o}.")
            return forms.get(f.relation,default).format(o=o)
        if f.relation=="PROPERTY":return self._property_sentence(s,f)
        L=self.g.label(s)
        if sc or o is None:
            Lc=self.speech.phrase(L,sc,eid=s) if sc else L
            if Lc is None or o is None:
                return self.lang.render_fact(L,f.relation,self.g.object_surface(f),f.polarity,caseless=True)
            L=Lc
        return self.lang.render_fact(L,f.relation,o,f.polarity)

    # G269: speech forms. The stored fact keeps the concept; the sentence needs its word in the frame's case.
    def _obj_case(self,f,case,strict=False):
        if f.object_kind=="entity" and f.object_value in {self.user_eid,self.self_eid}:
            me=f.object_value==self.self_eid
            return ("я" if me else "ты") if (not case or case=="nom") else ("меня" if me else "тебя")
        o=str(self.g.object_surface(f))
        if not case or case=="nom" or f.object_kind!="entity":return o
        said=self._as_said(f)
        if said:return said
        form=self.speech.phrase(o,case,eid=f.object_value)
        return form if (form is not None or strict) else o

    def _as_said(self,f):
        """The object as the speaker said it, recovered from the fact's own source sentence: «рыбу» for кошка LIKES
        рыба (stored as the concept), «книги» for USER LIKES книга. Read-only re-parse of the receipt."""
        src=f.source_ref
        if not isinstance(src,str) or not src or len(src)>200 or f.object_kind!="entity":return None
        try:it=self.lang.parse(src)
        except Exception:return None
        if it.relation!=f.relation or not it.object:return None
        for part in [x.strip() for x in re.split(r"\s+и\s+|,\s*",str(it.object)) if x.strip()]:
            if (self.g.resolve(part) or self.morphology.resolve(part))==f.object_value:return part
        return None

    def _deixis_gender(self,s):
        if s==self.self_eid:return "FEM"           # the child speaks of itself in the feminine («запомнила»)
        f=self.g.get(self.user_eid,"NAME",viewer=self.principal,principal=self.principal)
        nid=self.g.resolve(f.object_value) if f else None
        return self.speech.gender(nid) if nid else None

    def _speech_obj(self,f):
        """An object surface ready for a grouped sentence: accusative after «любит», agreeing predicate adjectives."""
        o=str(self.g.object_surface(f)).strip().rstrip('.')
        _,oc=self.lang.case_frame(f.relation,f.polarity)
        if oc=="acc":return self._obj_case(f,"acc")
        if f.relation=="PROPERTY" and len(o.split())==1 and self.speech.is_adjective(o):
            return self.speech.agree(o,gender=self._deixis_gender(f.subject)) if f.subject in {self.user_eid,self.self_eid} else self.speech.agree(o,f.subject)
        return o

    def _property_sentence(self,s,f):
        o=str(self.g.object_surface(f)).strip().rstrip('.')
        if len(o.split())==1 and self.speech.is_adjective(o):
            return f"{self.g.label(s)} {'не ' if f.polarity=='NEG' else ''}{self.speech.agree(o,s)}."
        return self.lang.render_fact(self.g.label(s),"PROPERTY",o,f.polarity)

    def _subj_word(self,s):
        return "ты" if s==self.user_eid else ("я" if s==self.self_eid else self.g.label(s))

    def _group_sentence(self,s,rel,objs,joiner=", "):
        """One sentence for several values of one relation of one subject, in the relation's case frame."""
        o=joiner.join(objs)
        if s in {self.user_eid,self.self_eid}:
            who="USER" if s==self.user_eid else "SELF"
            form=self._DEIXIS_POS[who].get(rel)
            return form.format(o=o) if form else (("Ты" if who=="USER" else "Я")+f": {o}.")
        L=self.g.label(s)
        if rel=="HAS":
            Lg=self.speech.phrase(L,"gen",eid=s)
            if Lg is not None:return f"У {Lg} есть {o}."
        return self._SUMMARY_FORM.get(rel,"{s}: {o}.").format(s=L,o=o)

    # ------------------------------------------------------------------ G267: the kernel gets the floor
    MAX_ITEMS=6
    _ORIGIN_RU={"USER_SAID":"ты мне это сообщил","CREATOR_PRIOR":"знание от создателя","EXTERNAL_CORPUS":"учебный корпус",
                "OBS":"моё наблюдение","RECEIPT":"квитанция действия","SIM":"симуляция","REPLAY":"повтор"}
    _REL_Q={"IS_A":"что такое «{x}»","NAME":"как зовут «{x}»","LIKES":"что любит «{x}»","LOCATION":"где «{x}»",
            "HAS":"что есть у «{x}»","CAN":"что может «{x}»","USED_FOR":"для чего нужно «{x}»","PROPERTY":"какие свойства у «{x}»",
            "MEANS":"что значит «{x}»","RULE":"какие правила у «{x}»","CAUSES":"что вызывает «{x}»"}

    def _rid(self,label,update_focus=False,loose=False,_flip=True):
        """Resolve-only identity lookup for every question path: a question never creates an entity.

        loose=True adds a unique inflection-tolerant match over existing concept labels (not used for yes/no truth)."""
        if label is None:return None
        flipped=self._perspective(label) if _flip else label
        if flipped!=label:
            hit=self._rid(flipped,update_focus=update_focus,loose=loose,_flip=False)
            if hit is not None:return hit
        n=norm(label).strip(' «»"\'')
        if n in {"я","user","меня","мне","мной"}:eid=self.user_eid
        elif n in {"ты","self","тебя","тебе","тобой","себя","себе"}:eid=self.self_eid
        elif n in PRONOUNS:
            eid=self._pronoun_candidate({"его":"он","него":"он","её":"она","ее":"она","неё":"она","нее":"она","их":"они","них":"они"}.get(n,n))
        else:
            eid=self.g.resolve(label) or self.morphology.resolve(label)
            if eid is None and loose:eid=self.retriever.lemma(str(label))
        if eid and update_focus:self._touch_focus(eid)
        return eid

    def _qobj(self,it:Intent):
        """Resolve-only mirror of _obj for questions."""
        spec=self.g.relation_spec(it.relation)
        if spec.object_mode=="literal":return "literal",it.object
        if spec.object_mode=="entity" or it.relation in ENTITY_OBJECT_RELATIONS:return "entity",self._rid(it.object)
        hit=self._rid(it.object)
        return ("entity",hit) if hit else ("literal",it.object)

    def _semantic_facts(self,eid):
        return [f for f in self.g.facts_about(eid,viewer=self.principal,principal=self.principal)
                if f.relation not in TECHNICAL_RELATIONS and 'sha256=' not in str(f.object_value)]

    def _subphrase_entity(self,text,update_focus=False,prefer=None):
        """Most specific known entity named inside `text` (longest span; ties -> preferred, more knowledge, later). Read-only."""
        words=re.findall(r"[\w-]+",str(text))
        for n in range(min(len(words),6),0,-1):
            found=[]
            for i in range(len(words)-n+1):
                span=" ".join(words[i:i+n]);sn=norm(span)
                if n==1 and (sn in STOPWORDS or sn in PRONOUNS or len(sn)<3):continue
                eid=self.g.resolve(span) or self.morphology.resolve(span)
                if eid and eid not in {self.user_eid,self.self_eid}:
                    found.append((bool(prefer(eid)) if prefer else False,len(self._semantic_facts(eid)),i,eid))
            if found:
                eid=max(found)[-1]
                if update_focus:self._touch_focus(eid)
                return eid
        return None

    _DEIXIS={"я","меня","мне","мной","ты","тебя","тебе","тобой","себя","себе","self","user"}

    def _self_concept(self):
        """The concept SELF is bound to by name through its aliases (alias `c4` -> concept C4).

        Deictic aliases (ты/тебя) are skipped: a stray concept named «ты» is not the system's identity."""
        best=None
        for a in self.g.entities[self.self_eid].aliases:
            if norm(a) in self._DEIXIS:continue
            eid=self.g.resolve(a,'concept') or self.morphology.resolve(a)
            if eid and eid!=self.self_eid and self.g.entities[eid].kind=='concept':
                score=len(self._semantic_facts(eid))
                if best is None or score>best[0]:best=(score,eid)
        return best[1] if best else None

    @staticmethod
    def _cap(t):
        t=str(t);return t[:1].upper()+t[1:]

    @staticmethod
    def _codey(o):
        """Formal invariant notation (A != B) is kept but spoken after natural-language knowledge."""
        o=str(o)
        return '!=' in o or '->' in o or (bool(re.search(r"\b[A-Z_]{3,}\b",o)) and not re.search(r"[а-яё]{3,}",o.lower()))

    def _item_text(self,f,with_subject=True):
        o=str(self.g.object_surface(f)).strip()
        if f.relation=="PROPERTY" and f.polarity=="POS" and len(o.split())>=4:
            return f"{self.g.label(f.subject)}: {o.rstrip('.')}." if with_subject else self._cap(o.rstrip('.'))+"."
        return self._render(f.subject,f)

    def _bounded(self,label,items,*,limit=None,sep=" ",end=""):
        """items: [(text, fact_id)]. Shows `limit`, keeps the rest for «подробнее», records receipts."""
        limit=limit or self.MAX_ITEMS
        shown,rest=items[:limit],items[limit:]
        self.more={'label':label,'items':rest} if rest else None
        self.last_used=[fid for _,fid in shown if fid]
        texts=[t if (i==0 or sep!=" ") else self._cap(t) for i,(t,_) in enumerate(shown)]
        txt=sep.join(texts)+end
        if rest:txt+=f" …и ещё {len(rest)}. Скажи «подробнее», чтобы продолжить."
        return txt

    # How one subject's admitted facts are spoken (grouped by relation, no internal codes).
    _SUMMARY_FORM={"IS_A":"{s} — {o}.","ROLE":"{s} — {o}.","MEANS":"«{s}» означает: {o}.","CAN":"{s} может {o}.",
                   "USED_FOR":"{s} используется для: {o}.","HAS_PART":"{s}: части — {o}.","PART_OF":"{s} входит в: {o}.",
                   "HAS":"{s} имеет: {o}.","CAUSES":"{s} приводит к: {o}.","RULE":"{s}: правила — {o}.","PROPERTY":"{s}: {o}.",
                   "LIKES":"{s} любит {o}.","LOCATION":"{s} находится: {o}.","COLOR":"{s}: цвет — {o}.","VALUE":"{s} = {o}.",
                   "OPPOSITE":"{s}: противоположность — {o}.","ANTONYM":"{s}: антоним — {o}.","SYNONYM":"{s}: синоним — {o}."}

    def _facts_brief(self,eid,limit=3,capitalize=False):
        """Readable bounded summary of the admitted, visible, non-technical facts about one entity (read-only)."""
        fs=self._semantic_facts(eid)
        if not fs:return None
        order={r:i for i,r in enumerate(self._SUMMARY_FORM)}
        def key(f):
            o=self.g.object_surface(f)
            return (f.polarity!="POS",self._codey(o),f.relation=="PROPERTY" and len(str(o).split())>=4,order.get(f.relation,len(order)),f.order)
        fs.sort(key=key)
        limit=limit or self.MAX_ITEMS
        shown,rest=fs[:limit],fs[limit:]
        L=self.g.label(eid);groups={};singles=[];codes=[]
        for f in shown:
            o=str(self.g.object_surface(f)).strip().rstrip('.')
            if f.relation=="PROPERTY" and f.polarity=="POS" and self._codey(o):
                codes.append(o);continue
            if f.polarity!="POS" or f.relation not in self._SUMMARY_FORM:
                singles.append((self._render(f.subject,f),None));continue
            if f.relation=="PROPERTY" and len(o.split())>=4:
                singles.append((self._cap(o)+".",f"{L}: {o}."));continue
            groups.setdefault(f.relation,[]).append(self._speech_obj(f))
        chunks=[]
        for rel,form in self._SUMMARY_FORM.items():
            if rel in groups:
                chunks.append(self._group_sentence(eid,rel,list(dict.fromkeys(groups[rel])),"; " if rel in {"MEANS","RULE"} else ", "))
        for i,(t,named) in enumerate(singles):
            chunks.append(named if (named and not chunks) else t)
        if codes:chunks.append(("Формальные различения: " if chunks else f"{L}: формальные различения — ")+"; ".join(codes)+".")
        chunks=[c if i==0 else self._cap(c) for i,c in enumerate(chunks)]
        self.last_used=[f.fact_id for f in shown]
        self.more={'label':L,'items':[(self._item_text(f),f.fact_id) for f in rest]} if rest else None
        txt=" ".join(chunks)
        if capitalize:txt=self._cap(txt)
        if rest:txt+=f" …и ещё {len(rest)}. Скажи «подробнее», чтобы продолжить."
        return txt

    def _definition(self,s):
        d=self.definitions.compose(s,viewer=self.principal,principal=self.principal)
        if not d.direct_types and not d.properties:return None
        if not d.direct_types:return self._facts_brief(s,limit=self.MAX_ITEMS,capitalize=True)
        words={'HAS_PART':'Части','USED_FOR':'Используется для','CAN':'Может','PROPERTY':'Свойства','COLOR':'Цвет'}
        props=sorted(d.properties,key=lambda p:(DefinitionComposer.DETAIL_RELATIONS.index(p['relation']),self._codey(p['value'])))
        shown,rest=props[:self.MAX_ITEMS],props[self.MAX_ITEMS:]
        roles=[f for f in self.g.get_all(s,"ROLE",viewer=self.principal,principal=self.principal)]
        chunks=[self._cap(f"{d.label} — "+", ".join(d.direct_types)+".")]
        if roles:chunks.append(self._cap(f"{d.label} — "+", ".join(self.g.object_surface(f) for f in roles)+"."))
        grouped={}
        for p in shown:grouped.setdefault(p['relation'],[]).append(self.speech.agree(p['value'],s) if p['relation']=="PROPERTY" else p['value'])
        for rel in DefinitionComposer.DETAIL_RELATIONS:
            if grouped.get(rel):chunks.append(f"{words[rel]}: "+", ".join(dict.fromkeys(grouped[rel]))+".")
        if d.derived_types:chunks.append("Из известных связей также следует: "+", ".join(d.derived_types)+".")
        prop_ids={p['fact_id'] for p in d.properties}
        self.last_used=[x for x in d.fact_ids if x not in prop_ids]+[f.fact_id for f in roles]+[p['fact_id'] for p in shown]
        self.more={'label':d.label,'items':[(p['value'],p['fact_id'],words[p['relation']].lower()) for p in rest]} if rest else None
        if rest:chunks.append(f"…и ещё {len(rest)}. Скажи «подробнее», чтобы продолжить.")
        return " ".join(chunks)

    def _is_question(self,text):
        t=norm(text)
        return t.endswith('?') or bool(re.match(r"^(?:что|кто|как|где|когда|почему|зачем|какой|какая|какое|какие|сколько|чей|чья|ли|разве|правда ли)\b",t))

    def _is_elliptic(self,text):
        toks=set(re.findall(r"[\w-]+",norm(text)));n=len(_stems(text))
        return n==0 or (bool(toks & PRONOUNS) and n<=2)

    @staticmethod
    def _strict_names(text):
        """Capitalised non-initial Cyrillic words are names: match them by full stem, not by the short key."""
        out={}
        for i,w in enumerate(re.findall(r"[\w-]+",str(text))):
            lw=w.lower()
            if i>0 and w[:1].isupper() and re.search(r"[а-яё]",lw) and lw not in STOPWORDS:out[_stem(lw)]=_stem_full(lw)
        return out

    _SECOND_PERSON={"ты","тебя","тебе","тобой","твой","твоя","твоё","твое","твои","твоего","твоей","твоему","твоим","твоих","твою"}

    def _context_floor_text(self,*,limit=3,preferred_eid=None):
        """Speak existing knowledge about recent life-line anchors, read-only.

        This is semantic availability, not evidence and not an inferred answer.
        """
        ordered=[]
        if preferred_eid in self.g.entities:ordered.append(preferred_eid)
        ordered.extend(e for e in reversed(self.context_eids) if e!=preferred_eid)
        for eid in ordered:
            if eid not in self.g.entities:continue
            fs=self._semantic_facts(eid)
            if not fs:continue
            order={r:i for i,r in enumerate(self._SUMMARY_FORM)}
            fs.sort(key=lambda f:(f.polarity!="POS",self._codey(self.g.object_surface(f)),order.get(f.relation,len(order)),f.order))
            items=[];seen=set()
            for f in fs:
                t=self._item_text(f)
                if t in seen:continue
                seen.add(t);items.append((t,f.fact_id))
            if items:
                return self._bounded(self.g.label(eid),items,limit=limit)
        return None

    def _floor_text(self,text,*,limit=3,context=True,names_from=None):
        """Admitted knowledge lexically related to `text`. Elliptic turns («Он исчез?») borrow the previous surface;
        second-person words («кто тебя создал») anchor the search at the concept SELF is bound to."""
        q=_stems(text);selfref=[]
        if context and self._is_elliptic(text):
            toks=[x for x in re.findall(r"[\w-]+",norm(text)) if x in PRONOUNS]
            preferred=self._pronoun_candidate(toks[-1]) if toks else None
            direct=self._context_floor_text(limit=limit,preferred_eid=preferred)
            if direct:return direct
            if self.prev_stems:q=list(dict.fromkeys(q+self.prev_stems))
        if set(re.findall(r"[\w-]+",norm(text))) & self._SECOND_PERSON:
            c=self._self_concept()
            if c:selfref=_stems(self.g.label(c));q=list(dict.fromkeys(q+selfref))
        if not q:return None
        strict={k:v for k,v in self._strict_names(names_from or text).items() if k in q}
        hits=self.retriever.search(q,viewer=self.principal,principal=self.principal,limit=limit+6,strict=strict,
                                   no_subject_bonus=selfref,min_coverage=0.6 if len(q)<=3 else 0.5)
        items=[];seen=set()
        for _,fid in hits:
            t=self._item_text(self.g.facts[fid])
            if t not in seen:seen.add(t);items.append((t,fid))
        if not items:return None
        return self._bounded("эту тему",items,limit=limit)

    def _unknown_with_floor(self,it,s=None):
        x=self.g.label(s) if s else re.split(r",\s*",str(it.subject or '').strip())[0]
        lead="Не знаю, "+self._REL_Q.get(it.relation,"что сказать про «{x}»").format(x=x)+"."
        if s is not None:
            brief=self._facts_brief(s,limit=3)
            if brief:return f"{lead} Про «{x}» знаю: {brief}"
        return self._lead_with_floor(lead,it)

    def _lead_with_floor(self,lead,it,*,causal=None):
        """An honest «не знаю» that still gives the kernel the floor: related admitted knowledge, framed as related.

        SIMILARITY != IDENTITY: nothing retrieved here is presented as the answer to the asked proposition."""
        if causal and it.subject:
            causes=lambda e:self.reasoner.direct_causes_of(e,principal=self.principal,viewer=self.principal)
            effects=lambda e:self.reasoner.direct_effects_of(e,principal=self.principal,viewer=self.principal)
            sub=self._subphrase_entity(it.subject,prefer=lambda e:causes(e) or effects(e))
            if sub is not None:
                lab=self.g.label(sub);xs,ys=causes(sub),effects(sub)
                cs=lambda fs:[(self.g.label(f.subject),f.fact_id) for f in fs]
                es=lambda fs:[(self.g.object_surface(f),f.fact_id) for f in fs]
                if causal=="CAUSES_OF" and xs:return f"{lead} Знаю, что вызывает «{lab}»: "+self._bounded(lab,cs(xs),sep=", ",end=".")
                if causal=="EFFECTS_OF" and ys:return f"{lead} Знаю, к чему приводит «{lab}»: "+self._bounded(lab,es(ys),sep=", ",end=".")
                if causal=="CAUSES_OF" and ys:return f"{lead} Причин «{lab}» в моих знаниях нет; знаю только, к чему «{lab}» приводит: "+self._bounded(lab,es(ys),sep=", ",end=".")
                if causal=="EFFECTS_OF" and xs:return f"{lead} Последствий «{lab}» в моих знаниях нет; знаю только, что вызывает «{lab}»: "+self._bounded(lab,cs(xs),sep=", ",end=".")
        floor=self._floor_text(it.raw or it.subject or '')
        if floor:
            self.last_reply_kind="FLOOR"
            return f"{lead} По теме знаю: {floor}"
        sub=self._subphrase_entity(it.subject) if it.subject else None
        if sub is not None:
            lab=self.g.label(sub)
            brief=self._facts_brief(sub,limit=3)
            if brief:
                self.last_reply_kind="FLOOR"
                return f"{lead} Про «{lab}» знаю: {brief}"
        return lead+" Можешь меня этому научить."

    _LIGHT_VERBS=r"(?:происходит|происходят|бывает|бывают|случается|случаются|возникает|возникают|появляется|появляются|идёт|идет|идут|начинается|начинаются|наступает|наступают|получается|получаются)"

    def _causal_target(self,subj):
        t=self._rid(subj,update_focus=True,loose=True)
        if t is None:
            core=re.sub(rf"^{self._LIGHT_VERBS}\s+|\s+{self._LIGHT_VERBS}$","",subj,flags=re.IGNORECASE).strip()
            if core and core!=subj:t=self._rid(core,update_focus=True,loose=True)
        return t

    def _cause_answer(self,it):
        subj=str(it.subject or '').strip()
        target=self._causal_target(subj)
        if target is not None:
            lab=self.g.label(target)
            xs=self.reasoner.direct_causes_of(target,principal=self.principal,viewer=self.principal)
            if xs:return "Непосредственные известные причины: "+self._bounded(lab,[(self.g.label(f.subject),f.fact_id) for f in xs],sep=", ",end=".")
            lead=f"Не знаю, что вызывает «{lab}»."
            ys=self.reasoner.direct_effects_of(target,principal=self.principal,viewer=self.principal)
            if ys:return f"{lead} Знаю только, к чему «{lab}» приводит: "+self._bounded(lab,[(self.g.object_surface(f),f.fact_id) for f in ys],sep=", ",end=".")
            brief=self._facts_brief(target,limit=3)
            return f"{lead} Про «{lab}» знаю: {brief}" if brief else lead+" Можешь меня этому научить."
        why=norm(it.raw or '').startswith('почему')
        lead=f"Не знаю, почему {subj}." if why else f"Не знаю, что вызывает «{subj}»."
        return self._lead_with_floor(lead,it,causal="CAUSES_OF")

    def _effect_answer(self,it):
        subj=str(it.subject or '').strip()
        cause=self._causal_target(subj)
        if cause is not None:
            lab=self.g.label(cause)
            xs=self.reasoner.direct_effects_of(cause,principal=self.principal,viewer=self.principal)
            if xs:return "Известные непосредственные последствия: "+self._bounded(lab,[(self.g.object_surface(f),f.fact_id) for f in xs],sep=", ",end=".")
            lead=f"Не знаю, к чему приводит «{lab}»."
            brief=self._facts_brief(cause,limit=3)
            return f"{lead} Про «{lab}» знаю: {brief}" if brief else lead+" Можешь меня этому научить."
        return self._lead_with_floor(f"Не знаю, к чему приводит «{subj}».",it,causal="EFFECTS_OF")

    def _predict_answer(self,it):
        s=self._rid(it.subject,update_focus=True,loose=True)
        pred=self.reasoner.predict_effects(s,principal=self.principal,viewer=self.principal,horizon=2) if s else []
        if not pred:
            return self._lead_with_floor("Не знаю точно, что произойдёт: прямой причинной модели для этого у меня нет.",it)
        self.last_used=list(dict.fromkeys(f.fact_id for x in pred for f in x.path))
        direct=[self.g.label(x.effect) for x in pred if x.depth==1];later=[self.g.label(x.effect) for x in pred if x.depth>1]
        chunks=["Это симуляция по известным причинным связям, а не наблюдение."]
        if direct:chunks.append("Сначала ожидаю: " + ", ".join(direct[:self.MAX_ITEMS]) + ".")
        if later:chunks.append("Дальше по цепочке возможно: " + ", ".join(later[:self.MAX_ITEMS]) + ".")
        return " ".join(chunks)

    def _about(self,it):
        out=self._about_core(it)
        if re.match(r"^\s*что ты (?:думаешь|считаешь)",str(it.raw or ''),flags=re.IGNORECASE) and not out.startswith("Пока ничего"):
            return "Своих мнений у меня нет, есть знания. "+out
        return out

    def _about_core(self,it):
        subj=str(it.subject or '').strip()
        s=self._rid(subj,update_focus=True,loose=True)
        if s==self.self_eid:return self._about_self()
        if s==self.user_eid:return self._about_user()
        if s is not None:
            brief=self._facts_brief(s,limit=self.MAX_ITEMS,capitalize=True)
            if brief:return brief
            return f"Про «{self.g.label(s)}» я пока ничего не знаю, кроме самого слова. Можешь меня научить."
        floor=self._floor_text(subj,limit=4,context=False,names_from=it.raw)
        if floor:
            self.last_reply_kind="FLOOR"
            return f"Отдельного понятия для этого у меня нет, но в знаниях есть: {floor}"
        sub=self._subphrase_entity(subj,update_focus=True)
        if sub is not None:
            brief=self._facts_brief(sub,limit=self.MAX_ITEMS)
            if brief:
                self.last_reply_kind="FLOOR"
                return f"Про «{self.g.label(sub)}» знаю: {brief}"
        return "Пока ничего не знаю об этом. Можешь меня этому научить."

    def _truth_answer(self,subject,relation,obj,polarity,raw):
        """Shared yes/no evaluator. Resolve-only; replies stay exactly Да./Нет./Не знаю./conflict wording."""
        pit=Intent("TRUTH_QUERY",subject=subject,relation=relation,object=obj,raw=raw,polarity=polarity)
        s=self._rid(pit.subject,update_focus=True);ok,ov=self._qobj(pit)
        if s is None:return "Не знаю."
        if s==self.self_eid and not self.g.get_all(s,pit.relation,viewer=self.principal,principal=self.principal,polarity=None):
            s=self._self_concept() or s
        if ok=="entity" and ov is None:
            ev=self._pair_evidence(s,obj)
            if ev:
                self.last_used=[f.fact_id for f in ev]
                return "Не знаю. Но у меня есть знание: "+"; ".join(self._item_text(f).rstrip('.') for f in ev)+"."
            return "Не знаю."
        if pit.relation=="IS_A" and ok=="entity":
            source_conflict=self.g.proposition_source_conflict(s,pit.relation,ov,object_kind=ok,principal=self.principal)
            r=self.reasoner.evaluate_is_a(s,ov,principal=self.principal,viewer=self.principal)
            v=r.value
            ex=self.reasoner.explain_is_a(s,ov,principal=self.principal,viewer=self.principal)
            if ex.get('steps'):
                self.last_used=[z['fact_id'] for z in ex['steps']]
                chain=", а ".join(f"{z['subject']} — {z['object']}" for z in ex['steps'])
                self.last_explain=("Потому что "+chain+". Это вывод по цепочке, а не отдельное наблюдение.") if ex.get('derived') else ("Это прямое знание: "+chain+".")
            elif ex.get('direct_negative'):
                z=ex['direct_negative'];self.last_used=[z['fact_id']]
                self.last_explain=f"Потому что у меня есть знание: {z['subject']} — не {z['object']}."
            elif v=="TRUE":
                self.last_explain="Это один и тот же объект, отдельная цепочка не нужна."
            elif v=="UNKNOWN":
                self.last_explain="У меня нет ни прямого знания, ни цепочки классов, которые это подтверждают или опровергают."
        else:
            # An `either` object may have been stored as a literal before a same-named entity existed (or vice
            # versa): both readings name the same surface, so the first decisive one answers. Read-only.
            readings=[(ok,ov)]
            if self.g.relation_spec(pit.relation).object_mode=="either" and pit.relation not in ENTITY_OBJECT_RELATIONS:
                alt=("literal",str(obj).strip()) if ok=="entity" else ("entity",self._rid(obj))
                if alt[1] and alt!=(ok,ov):readings.append(alt)
            for rk,rv in readings:
                v=self._eval_relation_truth(s,pit.relation,rk,rv)
                if v!="UNKNOWN":ok,ov=rk,rv;break
            else:
                ok,ov=readings[0];v=self._eval_relation_truth(s,pit.relation,ok,ov)
            source_conflict=None
        if pit.polarity=="NEG":v={"TRUE":"FALSE","FALSE":"TRUE","UNKNOWN":"UNKNOWN","CONFLICT":"CONFLICT"}[v]
        base={"TRUE":"Да.","FALSE":"Нет.","UNKNOWN":"Не знаю.","CONFLICT":"В моих знаниях есть противоречие."}[v]
        if source_conflict is None:
            source_conflict=self.g.proposition_source_conflict(s,pit.relation,ov,object_kind=ok,principal=self.principal)
            # G295: for FUNCTIONAL relations, disagreement about another value is still
            # relevant to a specific yes/no query.  Do not hide slot-level source
            # disagreement just because the queried proposition itself has no POS/NEG
            # polarity conflict.  This is presentation/read semantics only; no fact is
            # created, replaced, or negated here.
            if (not source_conflict and
                self.g.relation_spec(pit.relation).cardinality=="FUNCTIONAL"):
                source_conflict=self.g.functional_source_conflict(s,pit.relation,principal=self.principal)
        if source_conflict:return "Источники расходятся. Каноническое состояние сейчас: "+base
        if v=="UNKNOWN":
            ev=self._pair_evidence(s,obj)
            if ev:
                self.last_used=[f.fact_id for f in ev]
                return "Не знаю. Но у меня есть знание: "+"; ".join(self._item_text(f).rstrip('.') for f in ev)+"."
        return base

    def _eval_relation_truth(self,s,rel,ok,ov):
        """Truth of one typed reading + receipts/explanation for «почему?»."""
        self.last_explain=None
        if rel in ({"CAN","PROPERTY","USED_FOR"} | getattr(__import__('c4child.reasoner',fromlist=['ALGEBRA_RELATIONS']),'ALGEBRA_RELATIONS',set())):
            rr=self.reasoner.evaluate_relation(s,rel,ov,object_kind=ok,principal=self.principal,viewer=self.principal)
            self.last_used=list(dict.fromkeys([f.fact_id for f in (rr.path or []) if f]+([rr.direct.fact_id] if rr.direct else [])))
            if rr.derived and rr.path and rr.direct:
                chain=" → ".join([self.g.label(rr.path[0].subject)]+[self.g.label(e.object_value) for e in rr.path])
                self.last_explain=(f"Это унаследованный вывод по классам: {chain}; у класса «{self.g.label(rr.direct.subject)}» "
                                   f"есть знание: {self._item_text(rr.direct).rstrip('.')}. Это вывод, а не наблюдение.")
            elif getattr(rr,'rule_id',None):
                self.last_explain=f"Это вывод по выученному правилу ({rr.rule_id}), а не прямое знание."
            elif rr.derived and rr.path and rel in getattr(__import__('c4child.reasoner',fromlist=['ALGEBRA_RELATIONS']),'ALGEBRA_RELATIONS',set()):
                sf=rr.path[0]
                self.last_explain=(f"Это структурный вывод из обратной/симметричной связи: {self._item_text(sf).rstrip('.')}. "
                                   "Вывод не записан как отдельный факт.")
            return rr.value
        self.last_used=[f.fact_id for f in self.g.get_all(s,rel,viewer=self.principal,principal=self.principal,polarity=None)
                        if f.object_kind==ok and f.object_value==str(ov)]
        return self.g.truth(s,rel,ov,object_kind=ok,viewer=self.principal,principal=self.principal)

    def _pair_evidence(self,s,obj_text,limit=2):
        """Literal admitted facts about the SAME subject that mention the asked object (e.g. C4: «не человек»).
        They are shown, never converted into Да/Нет: UNKNOWN != FALSE."""
        want=set(_stems(obj_text))
        if not want:return []
        need=max(1,(len(want)+1)//2);out=[]
        for f in self._semantic_facts(s):
            if len(want & set(_stems(self.g.object_surface(f))))>=need:out.append(f)
        out.sort(key=lambda f:(self._codey(self.g.object_surface(f)),f.order))
        return out[:limit]

    def _yes_no_question(self,it):
        """«Кошка — это животное?» is a TRUTH question; «город — это?» is a definition question. Read-only."""
        obj=re.sub(r"^(?:это|это же|ли)\s+","",str(it.object or '').strip(),flags=re.IGNORECASE).strip()
        if it.relation=="IS_A" and norm(obj).strip(' ?') in _EMPTY_COPULA_OBJECTS:
            return self._query(Intent("QUERY",subject=it.subject,relation="IS_A",raw=it.raw))
        if it.relation=="IS_A" and len(obj.split())==1 and self.speech.is_adjective(obj) and self._rid(it.subject) is not None:
            lt=self._literal_truth(str(it.subject).split()+[obj],it.polarity,it.raw)
            if lt is not None:return lt
        if self._rid(it.subject) is None:
            floor=self._floor_text(it.raw or str(it.subject or ''))
            if floor:
                self.last_reply_kind="FLOOR"
                return "Не знаю. По теме знаю: "+floor
            return "Не знаю."
        return self._truth_answer(it.subject,it.relation,obj,it.polarity,it.raw)

    def _about_self(self):
        name=self.g.get(self.self_eid,"NAME",viewer=self.principal,principal=self.principal)
        c=self._self_concept()
        head=("Я — "+self.g.label(c) if c else "Я — эта система")+(f"; ты зовёшь меня {name.object_value}" if name else "")+"."
        body=self._definition(c) if c else None
        return head+(" "+body if body else "")

    def _about_user(self,yes=True):
        name=self.g.get(self.user_eid,"NAME",viewer=self.principal,principal=self.principal)
        # G270: a count and the three latest, asked from the store (not a scan of every fact)
        n_told=self.g.count_active(viewer=self.principal,principal=self.principal,origin="USER_SAID",exclude_relations=TECHNICAL_RELATIONS)
        told=list(reversed(self.g.active_facts(viewer=self.principal,principal=self.principal,origin="USER_SAID",
                                               exclude_relations=TECHNICAL_RELATIONS,newest_first=True,limit=3)))
        self.last_used=[f.fact_id for f in told[-3:]]
        own=[f for f in self._semantic_facts(self.user_eid) if f.relation!="NAME"][:4]
        head=(("Да. " if yes else "")+f"Тебя зовут {name.object_value}.") if name else ("Как тебя зовут, я не знаю, но помню о тебе." if own else "Как тебя зовут, я не знаю: ты мне этого не говорил.")
        if own:
            head+=" "+" ".join(self._render(self.user_eid,f) for f in own)
            self.last_used=list(dict.fromkeys([f.fact_id for f in own]+self.last_used))
        if told:head+=f" Всего ты сообщил мне фактов: {n_told}."
        elif not name:head+=" Можно сказать: «запомни: меня зовут …»."
        return head

    _POSS_YOUR={"твой","твоя","твоё","твое","твои"}
    _POSS_MY={"мой","моя","моё","мое","мои"}
    _POSS_FLIP={"твой":"мой","твоя":"моя","твоё":"моё","твое":"мое","твои":"мои","мой":"твой","моя":"твоя","моё":"твоё","мое":"твое","мои":"твои"}

    def _deictic_intents(self,text):
        """«Я твой создатель», «ты моя помощница», «я Руслан, твой создатель»: zero-copula statements about the two
        speakers. Possessives are stored from the child's side (твой -> мой), so «ты — мой создатель» reads right later.
        All chunks must be understood, otherwise nothing is proposed. Proposes Intents only; _claim owns persistence."""
        raw=str(text).strip()
        if raw.endswith('?'):return []
        payload=raw.rstrip('.! ');mode="CLAIM"
        m=re.match(r"^(?:запомни|помни)[:,]?\s*(.+)$",payload,flags=re.IGNORECASE)
        if m:mode="REMEMBER_CLAIM";payload=m.group(1).strip()
        m=re.match(r"^(я|ты)\s+(?:—\s*|-\s*|это\s+)?(.+)$",payload,flags=re.IGNORECASE)
        if not m:return []
        who=m.group(1).lower();out=[]
        for chunk in re.split(r",\s*|\s+и\s+(?=(?:твой|твоя|твоё|твое|твои|мой|моя|моё|мое|мои)\b)",m.group(2).strip()):
            words=chunk.split()
            if not words:return []
            p=words[0].lower()
            if len(words)>=2 and ((who=="я" and p in self._POSS_YOUR) or (who=="ты" and p in self._POSS_MY)):
                out.append(Intent(mode,subject=who,relation="ROLE",object=self._POSS_FLIP[p]+" "+" ".join(words[1:]),raw=raw))
            elif len(words)<=2 and re.fullmatch(r"[А-ЯЁA-Z][\w-]*(?:\s+[А-ЯЁA-Z][\w-]*)?",chunk.strip()):
                out.append(Intent(mode,subject=who,relation="NAME",object=chunk.strip(),raw=raw))
            else:
                return []
        return out

    def _who_is_my(self,poss,x,fallback=True):
        """«Кто твой создатель?» — reverse lookup over ROLE/IS_A facts that name the child's (or the user's) X. Read-only."""
        mine=norm(poss) in self._POSS_YOUR            # «твой X» from the user = the child's X
        marks=self._POSS_MY if mine else self._POSS_YOUR
        want=set(_stems(x))
        if not want:return None
        c=self._self_concept();clab=norm(self.g.label(c)) if (c and mine) else None
        hits=[]
        for fid in self.retriever.candidates(want):
            f=self.g.facts[fid]
            if f.relation not in {"ROLE","IS_A"} or f.polarity!="POS" or f.principal!=self.principal or not self.g._visible(f,self.principal,self.principal):continue
            o=norm(self.g.object_surface(f));toks=set(re.findall(r"[\w-]+",o))
            if not (want & set(_stems(o))):continue
            if (toks & marks) or (clab and clab in toks):hits.append(f)
        if not hits:
            if not fallback:return None
            return self._lead_with_floor(f"Не знаю, кто {self._PERSPECTIVE.get(norm(poss),'мой' if mine else 'твой')} {x}.",Intent("QUERY",subject=x,relation="ROLE",raw=x))
        hits.sort(key=lambda f:(f.subject not in {self.user_eid,self.self_eid},f.order))
        return self._bounded(x,[(self._render(f.subject,f),f.fact_id) for f in hits],limit=4)

    def _self_user_query(self,it,s):
        if it.relation in {"LIKES","CAN"} and (s==self.user_eid or (s==self.self_eid and it.relation=="LIKES")):
            fs=self.g.get_all(s,it.relation,viewer=self.principal,principal=self.principal)
            if fs:return self._relation_answer(s,it.relation,fs,[])
            verb={"LIKES":("любишь","люблю"),"CAN":("умеешь","умею")}[it.relation]
            if s==self.user_eid:return f"Не знаю, что ты {verb[0]}: ты мне этого не говорил."
            return f"Не знаю: мне пока никто не говорил, что я {verb[1]}."
        if s==self.user_eid and it.relation=="NAME":
            f=self.g.get(s,"NAME",viewer=self.principal,principal=self.principal)
            if f:self.last_used=[f.fact_id];return f"Тебя зовут {f.object_value}."
            return "Не знаю, как тебя зовут. Скажи: «запомни: меня зовут …»."
        if s!=self.self_eid:return None
        c=self._self_concept()
        if it.relation=="NAME":
            f=self.g.get(s,"NAME",viewer=self.principal,principal=self.principal)
            if f:self.last_used=[f.fact_id];return f"Меня зовут {f.object_value}."
            return "Отдельного имени мне не давали. "+(f"Я — {self.g.label(c)}." if c else "")
        if it.relation=="CAN":
            fs=[f for x in (s,c) if x for f in self.g.get_all(x,"CAN",viewer=self.principal,principal=self.principal)]
            fs+=[f for f in (self.g.get_all(c,"PROPERTY",viewer=self.principal,principal=self.principal) if c else [])
                 if str(self.g.object_surface(f)).startswith("может ")]
            if not fs:return None
            items=[(str(self.g.object_surface(f)).removeprefix("может ").rstrip('.'),f.fact_id) for f in fs]
            return "Я могу: "+self._bounded("мои умения",items,sep="; ",end=".")
        if c and not self.g.get_all(s,it.relation,viewer=self.principal,principal=self.principal):
            return self._query_entity(c,it)
        return None

    def _semantic_source_retraction(self,raw0):
        """Retract the speaker's latest source assertion when the utterance itself
        denotes self-correction/retraction in the learned language graph.

        This is semantic, not an exact phrase switch: any learned verb linked to
        `отзыв утверждения` or `самокоррекция утверждения` can trigger it.
        """
        raw=str(raw0).strip();m=re.match(r"^я\s+([A-Za-zА-Яа-яЁё-]+)",raw,flags=re.IGNORECASE)
        if not m:return None
        surface=m.group(1)
        eid=self.g.resolve(surface) or self.morphology.resolve(surface) or self.retriever.lemma(surface)
        if not eid:return None
        targets={x for x in (self.g.resolve('отзыв утверждения'),self.g.resolve('самокоррекция утверждения')) if x}
        if not targets:return None
        hit=False
        for rel in ('MEANS','USED_FOR','IS_A'):
            for f in self.g.get_all(eid,rel,viewer=self.principal,principal=self.principal):
                if f.object_kind=='entity' and f.object_value in targets:hit=True;break
            if hit:break
        if not hit:return None
        ids=self.g.retract_latest_source_assertion(source_group=f"USER:{self.principal}",principal=self.principal,
                                                   origin='USER_SAID',authority='USER',constitutional_basis='SOURCE_SELF_RETRACTION')
        if ids:
            self.last_used=[]
            return ('CORRECTION','Поняла. Твоё предыдущее утверждение отозвано; противоположное автоматически истинным не считаю.')
        return ('CORRECTION','Поняла, но у меня нет предыдущего твоего утверждения, которое можно отозвать.')

    def _semantic_spine_meta(self,raw0):
        """Non-authoritative guards for nested speech, temporal social claims and deictic correction.

        These patterns classify the speech act before the ordinary pending-question path.
        They never infer world truth from the surface.
        """
        self.last_spine_transaction=None
        raw=str(raw0).strip();low=norm(raw)
        # Nested/quoted speech is content of the outer event, not an instruction with
        # the quote's mutation authority.  A quote alone is also treated as quoted speech.
        q=list(re.finditer(r'«([^»]*)»|“([^”]*)”|"([^"]*)"',raw))
        if q:
            outside=re.sub(r'«[^»]*»|“[^”]*”|"[^"]*"',' ',raw).strip(' ,:;.-')
            framed=(not outside) or bool(re.search(r'\b(фраз|цитат|пример|провер|сказал|сказала|написал|написала|слова)\w*\b',outside,flags=re.IGNORECASE))
            if framed:
                return ("META_QUOTE","Поняла это как цитату или пример. Содержимое цитаты само по себе ничего не меняет в моём состоянии знаний.")
        # Past social naming is a historical report, never a replacement of the current NAME slot.
        m=re.match(r'^\s*(?:раньше|прежде|ранее)\s+(меня|тебя)\s+звали\s+(.+?)\s*[.!?]*$',raw,flags=re.IGNORECASE)
        if m:
            who='тебя' if m.group(1).lower()=='меня' else 'меня'
            return ("SOCIAL_TEMPORAL",f"Поняла как сообщение о прошлом: {who} раньше называли {m.group(2).strip()}. Текущее имя из этого не меняю.")
        # Epistemic modal: preserve as hypothesis; do not promote to current social state.
        m=re.match(r'^\s*(?:может(?:\s+быть)?|возможно|наверное|вероятно)\s*,?\s*(меня|тебя)\s+зовут\s+(.+?)\s*[.!?]*$',raw,flags=re.IGNORECASE)
        if m:
            who='тебя' if m.group(1).lower()=='меня' else 'меня'
            return ("HYPOTHESIS",f"Сохранила это только как предположение: возможно, {who} зовут {m.group(2).strip()}. Текущее имя не меняю.")
        # A functional current name cannot safely choose between two alternatives in one source act.
        m=re.match(r'^\s*(меня|тебя)\s+зовут\s+(.+?)\s*[.!?]*$',raw,flags=re.IGNORECASE)
        if m and re.search(r'\s+(?:и|или)\s+',m.group(2),flags=re.IGNORECASE):
            vals=[x.strip() for x in re.split(r'\s+(?:и|или)\s+',m.group(2),flags=re.IGNORECASE) if x.strip()]
            if len(vals)>1 and len(set(norm(x) for x in vals))>1:
                return ("ASK_CLARIFICATION","Здесь указано несколько разных имён. Я не буду выбирать одно по позиции. Уточни, какое имя относится к текущему состоянию.")
        # Contrastive correction: carry the value from the concrete prior source claim;
        # the correction surface is not allowed to invent a value.
        m=re.match(r'^\s*не\s+(меня|тебя)\s*,?\s*а\s+(меня|тебя)\s*[.!?]*$',raw,flags=re.IGNORECASE)
        if m and m.group(1).lower()!=m.group(2).lower():
            from_eid=self.user_eid if m.group(1).lower()=='меня' else self.self_eid
            to_eid=self.user_eid if m.group(2).lower()=='меня' else self.self_eid
            tx=self.g.atomic_rebind_latest_relation(from_subject=from_eid,to_subject=to_eid,relation='NAME',
                                                    source_group=f"USER:{self.principal}",principal=self.principal,
                                                    origin='USER_SAID',authority='SOCIAL_REPORT',
                                                    constitutional_basis='SOCIAL_CORRECTION',source_ref=raw)
            if tx:
                self.last_spine_transaction=dict(tx)
                who='тебе' if to_eid==self.self_eid else 'тебе как пользователю'
                return ("CORRECTION",f"Исправила конкретную прошлую привязку: значение перенесено {who}. Нового имени из фразы не придумывала.")
            return ("CORRECTION","Поняла исправление, но не нашла однозначной прошлой привязки, которую можно законно перенести.")
        return None

    def _meta_turn(self,raw0):
        t=norm(raw0).strip(' !?.,')
        name=self.g.get(self.user_eid,"NAME",viewer=self.principal,principal=self.principal)
        retract=self._semantic_source_retraction(raw0)
        if retract is not None:return retract
        if re.match(r"^(?:привет|приветик|приветствую|здравствуй|здравствуйте|добрый (?:день|вечер)|доброе утро|хай|хей)(?:[ ,!]+[\w-]+)?$",t):
            return ("SOCIAL",f"Привет, {name.object_value}!" if name else "Привет!")
        if re.match(r"^(?:спасибо|спасибо большое|благодарю|спс|пасиб[оа]?)(?:[ ,!]+.*)?$",t):return ("SOCIAL","Пожалуйста.")
        if re.match(r"^(?:ок|окей|ok|ладно|понятно|ясно|хорошо|ага|угу|принято|понял|поняла|супер|отлично|класс|да|не знаю|я не знаю)$",t):return ("ACK","Хорошо.")
        if re.match(r"^(?:нет|неа)$",t):return ("ACK","Поняла.")
        if self._COMPLIMENT.match(t):return ("SOCIAL","Спасибо!")
        if re.match(r"^(?:будем знакомы|давай знакомиться|давай познакомимся|приятно познакомиться|очень приятно|рад знакомству|рада знакомству|рад познакомиться|рада познакомиться|взаимно)$",t):
            return ("SOCIAL",f"Очень приятно, {name.object_value}!" if name else "Очень приятно! Как тебя зовут?")
        if re.match(r"^(?:пока|до свидания|до встречи|спокойной ночи|увидимся)(?:[ ,!]+.*)?$",t):return ("SOCIAL","Пока!")
        if re.match(r"^(?:как дела|как ты|как поживаешь|как настроение|как жизнь)$",t):
            return ("SOCIAL","Работаю штатно: знания загружены, могу отвечать и учиться.")
        if re.match(r"^(?:а )?(?:почему|отчего|с чего ты (?:это )?взяла|откуда ты (?:это )?знаешь|откуда знаешь|объясни|поясни|обоснуй|на каком основании)$",t):
            return ("ANSWER",self._why_last())
        if re.match(r"^(?:подробнее|ещё|еще|дальше|продолжай|продолжи|а ещё|а еще|расскажи подробнее|расскажи ещё|расскажи еще|больше)$",t):
            return ("ANSWER",self._more())
        if re.match(r"^(?:что ты знаешь|что знаешь|что ты вообще знаешь)$",t):return ("ANSWER",self._overview())
        if re.match(r"^(?:что нового|что ты узнала нового|что ты узнала|чему ты научилась|чему ты недавно научилась)$",t):return ("ANSWER",self._recent())
        if re.match(r"^(?:ты меня помнишь|помнишь меня|ты знаешь,? кто я|ты меня знаешь|знаешь меня)$",t):return ("ANSWER",self._about_user())
        if re.match(r"^(?:кто я|кто я (?:тебе|для тебя|такой|такая)|что ты знаешь обо мне|что ты обо мне знаешь|расскажи обо мне|расскажи про меня)$",t):return ("ANSWER",self._about_user(yes=False))
        return None

    def _why_last(self):
        if self.last_explain:return self.last_explain
        ids=[x for x in self.last_used if x in self.g.facts]
        if not ids:return "Мне нечего обосновывать: в прошлом ответе я не опиралась на свои знания."
        parts=[]
        for fid in ids[:3]:
            f=self.g.facts[fid];src=self._ORIGIN_RU.get(f.origin,f.origin)
            grp=f", {f.source_group}" if f.source_group and f.origin!="USER_SAID" else ""
            parts.append(f"«{self._item_text(f).rstrip('.')}» — источник: {src}{grp}")
        txt="Я опиралась на свои допущенные знания: "+"; ".join(parts)+"."
        if len(ids)>3:txt+=f" Всего фактов в ответе: {len(ids)}."
        if not all(self.g.facts[x].origin in {"OBS","RECEIPT"} for x in ids):txt+=" Это не моё собственное наблюдение."
        return txt

    def _more(self):
        if not self.more:return "Больше мне добавить нечего."
        label,items=self.more['label'],self.more['items']
        shown,rest=items[:10],items[10:]
        self.more={'label':label,'items':rest} if rest else None
        self.last_used=[x[1] for x in shown if x[1]]
        groups=[]
        for x in shown:
            key=x[2] if len(x)>2 else None;t=str(x[0]).strip().rstrip('.')
            if groups and groups[-1][0]==key:groups[-1][1].append(t)
            else:groups.append([key,[t]])
        body=". ".join(((f"{k}: " if k else "")+"; ".join(ts)) for k,ts in groups)
        txt=f"Ещё про «{label}»: {body}."
        if rest:txt+=f" …и ещё {len(rest)}. Скажи «подробнее», чтобы продолжить."
        return txt

    def _overview(self):
        if self._overview_cache and self._overview_cache[0]==self.g.order:return self._overview_cache[1]
        kw=dict(viewer=self.principal,principal=self.principal,exclude_relations=TECHNICAL_RELATIONS)
        n_facts=self.g.count_active(**kw);n_subjects=self.g.subject_count(**kw)
        top=[]
        for eid,_ in self.g.top_subjects(limit=80,**kw):
            lab=self.g.label(eid)
            if _HUMAN_LABEL.match(lab) and len(lab.split())<=3 and not re.search(r"\d{2,}|_",lab) and eid not in {self.user_eid,self.self_eid}:top.append(lab)
            if len(top)>=8:break
        txt=f"В моей памяти допущенных фактов: {n_facts}, понятий: {n_subjects}."
        if top:txt+=" Больше всего — про: "+", ".join(top)+f". Спроси, например: «что такое {top[0]}?» или «расскажи про {top[-1]}»."
        self._overview_cache=(self.g.order,txt)
        return txt

    def _recent(self):
        items=[];seen=set()
        for f in self.g.active_facts(viewer=self.principal,principal=self.principal,exclude_relations=TECHNICAL_RELATIONS,
                                     newest_first=True,lazy=True):
            if 'sha256=' in str(f.object_value):continue
            if f.subject in seen:continue
            seen.add(f.subject);items.append((self._item_text(f),f.fact_id))
            if len(items)>=12:break
        if not items:return "Пока я ничего не выучила."
        return "Последнее, что я узнала: "+self._bounded("недавнее",items,limit=4)

    def _zero_copula_truth(self,text):
        """«Правда ли, что кошка животное?» / «Кошка животное?»: the Russian present-tense copula is usually silent.

        Read-only. Only a split where BOTH sides name already known entities is read as «X IS_A Y»."""
        raw=str(text).strip()
        if not raw.endswith('?'):return None
        t=raw.rstrip('?!. ').strip()
        di=self._deictic_intents(t)
        if di and len(di)==1 and di[0].relation=="ROLE":      # «Я твой создатель?»; «Ты Transformer?» is not a name question
            x=di[0];s=self.user_eid if norm(x.subject)=="я" else self.self_eid
            for f in self.g.get_all(s,x.relation,viewer=self.principal,principal=self.principal,polarity=None):
                if norm(self.g.object_surface(f))==norm(x.object):
                    self.last_used=[f.fact_id]
                    return "Да." if f.polarity=="POS" else "Нет."
            return "Не знаю."
        ms=re.match(r"^(?:ты|вы)\s+(?:умеешь|можешь|умеете|можете)\s+(.+)$",t,flags=re.IGNORECASE)
        if ms:return self._truth_answer("ты","CAN",ms.group(1).strip(),"POS",raw)
        mc=re.match(r"^(?:может ли|умеет ли)\s+(.+)$",t,flags=re.IGNORECASE)
        if mc:   # «Может ли кошка летать?» = TRUTH(CAN); the subject must already be known, the ability is a literal
            words=mc.group(1).split()
            for i in range(len(words)-1,0,-1):
                if self._rid(" ".join(words[:i])):
                    return self._truth_answer(" ".join(words[:i]),"CAN"," ".join(words[i:]),"POS",raw)
            return None
        m=re.match(r"^(?:правда ли|верно ли|это правда|разве|неужели)\s*,?\s*(?:что\s+)?(.+)$",t,flags=re.IGNORECASE)
        body=(m.group(1) if m else t).strip()
        words=body.split()
        if not 2<=len(words)<=8:return None
        if re.match(r"^(?:что|кто|как|где|когда|почему|зачем|какой|какая|какое|какие|каков|сколько|чей|чья|ли)\b",body,flags=re.IGNORECASE):return None
        lt=self._literal_truth(words,"POS",raw)        # G269: «Новое слово пушистый?», «Новое слово ест орехи?», «Новое слово большой?»
        if lt is not None:return lt
        for i in range(1,len(words)):
            left=" ".join(words[:i]);right=" ".join(words[i:]);pol="POS"
            if right.lower().startswith("не "):right=right[3:].strip();pol="NEG"
            if not right:continue
            if self._rid(left) and self._rid(right) and self._rid(left)!=self._rid(right):
                return self._truth_answer(left,"IS_A",right,pol,raw)
        return None

    _ARITH_OPS={"плюс":"+","прибавить":"+","минус":"-","отнять":"-","умножить на":"*","умноженное на":"*","умножить":"*",
                "разделить на":"/","делить на":"/","поделить на":"/","деленное на":"/","+":"+","-":"-","*":"*","×":"*","/":"/",":":"/"}

    def _arith(self,raw0):
        """Arithmetic is computed by the existing exact oracle; number words come from admitted VALUE facts."""
        t=norm(raw0).strip(' ?!.=')
        m=re.match(r"^(?:сколько будет|чему равно|чему равен|чему равняется|посчитай|вычисли)\s*[:,]?\s*(.+)$",t)
        expr=m.group(1).strip() if m else (t if re.fullmatch(r"[\d\s+\-*/×:]+",t) and re.search(r"\d\s*[+\-*/×:]\s*\d",t) else None)
        if not expr:return None
        toks=re.findall(r"\d+|умножить на|умноженное на|разделить на|делить на|поделить на|деленное на|[a-zа-я]+|[+\-*/×:]",expr)
        out=[];ids=[];words=[]
        for tok in toks:
            if tok in self._ARITH_OPS:out.append(self._ARITH_OPS[tok]);continue
            if tok.isdigit():out.append(tok);continue
            eid=self._rid(tok)
            v=self.g.get(eid,"VALUE",viewer=self.principal,principal=self.principal) if eid else None
            if v is None or not re.fullmatch(r"-?\d+",str(v.object_value)):return None
            out.append(str(v.object_value));ids.append(v.fact_id);words.append(f"{tok} = {v.object_value}")
        if len(out)<3 or len(out)%2==0:return None
        if any((i%2==0)!=bool(re.fullmatch(r"\d+",x)) for i,x in enumerate(out)):return None
        shown=" ".join(out)
        try:r=ExactMathOracle.evaluate("".join(out))
        except ZeroDivisionError:return "На ноль делить нельзя: у такого выражения нет значения."
        except Exception:return None
        word=None
        if re.fullmatch(r"-?\d+",r.result):
            for f in self.g.reverse_facts("VALUE",r.result,object_kind="literal",viewer=self.principal,principal=self.principal):
                word=self.g.label(f.subject);ids.append(f.fact_id);break
        self.last_used=ids
        self.last_explain=(("Числа я взяла из своих знаний ("+"; ".join(words)+"), а посчитала точным калькулятором: ") if words else "Я посчитала точным калькулятором: ")+f"{shown} = {r.result}. Это вычисление, а не наблюдение."
        return f"{self._cap(word)}: {shown} = {r.result}." if word else f"{shown} = {r.result}."

    def _final_fallback(self,text):
        bare=str(text).strip(' ?!.,')
        if 0<len(bare.split())<=4 and len(content_tokens(bare))==len(re.findall(r"[\w-]+",bare)):   # only content words
            topic=self._rid(bare,update_focus=True,loose=True)
            if topic is not None and topic not in {self.user_eid,self.self_eid}:   # «кошка», «Братья Карамазовы»: a topic
                return self._about(Intent("ABOUT",subject=bare,raw=text))
        if not self._is_question(text):
            # A non-question does not become a query merely because a topic is in context.
            # However an elliptic continuation may lawfully expose already-known topic material.
            if self._is_elliptic(text):
                toks=[x for x in re.findall(r"[\w-]+",norm(text)) if x in PRONOUNS]
                preferred=self._pronoun_candidate(toks[-1]) if toks else None
                floor=self._context_floor_text(limit=3,preferred_eid=preferred)
                if floor:
                    self.last_reply_kind="FLOOR"
                    return "По текущей теме у меня доступно: "+floor
            words=content_tokens(text)[:3]
            self.last_reply_kind="NOT_UNDERSTOOD";self.last_unknown_words=words
            return "Я пока не понимаю эту фразу и ничего не запомнила. Скажи проще — например: «запомни: кошка — животное»."
        sub=self._subphrase_entity(text)
        if sub is not None:
            vl=self._verb_literal_answer(sub,text)      # «Что ест новое слово?»
            if vl:return vl
        wd=self._who_does(text)                         # «Кто живёт в норе?»
        if wd:return wd
        shape=self.relation_queries.question_shape(text)
        if shape is not None:   # unbound relation noun: keep the language-learning contract (LANGUAGE_RELATION gap)
            s=self._subphrase_entity(shape['subject'])
            brief=self._facts_brief(s,limit=3) if s else None
            head=f"Я пока не понимаю, какую связь здесь обозначает «{shape['relation_surface']}»."
            return head+(f" Про «{self.g.label(s)}» знаю: {brief}" if brief else " Объясни мне, что это за связь.")
        floor=self._floor_text(text)
        if floor:
            self.last_reply_kind="FLOOR"
            return "Прямого ответа у меня нет, но по теме я знаю: "+floor
        ent=self._subphrase_entity(text,update_focus=True)
        if ent is not None and 2*len(content_tokens(self.g.label(ent)))<=len(content_tokens(text)):
            ent=None   # «чемпионат мира» is not a question about «мир»
        if ent is not None:
            brief=self._facts_brief(ent,limit=3)
            if brief:
                self.last_reply_kind="FLOOR"
                return f"Про «{self.g.label(ent)}» я знаю: {brief}"
        words=content_tokens(text)[:3]
        self.last_reply_kind="NOT_UNDERSTOOD";self.last_unknown_words=words
        if words:return "Я пока не понимаю эту фразу и не нашла в своих знаниях ничего про «"+", ".join(words)+"». Научи меня или спроси иначе."
        return "Я пока не понимаю эту фразу. Попробуй сказать проще или научи меня."

    def _past_predicate_truth(self,p):
        s=self._rid(p.subject,update_focus=True)
        if s is None:return "Не понимаю, о ком или о чём вопрос."
        pit=Intent("EVENT_TRUTH_QUERY",subject=p.subject,relation=p.relation,object=p.object,raw=p.predicate_surface,polarity=p.polarity)
        ok,ov=self._qobj(pit)
        found=False
        for row in self._event_rows(s,p.relation):
            of=row['object_fact']
            if row['polarity']==p.polarity and of.object_kind==ok and str(of.object_value)==str(ov):
                found=True;break
        return "Да. У меня есть такой прошлый эпизод." if found else "Не знаю. У меня нет подтверждённого такого прошлого эпизода."

    def _past_predicate_query(self,pq):
        s=self._rid(pq["subject"],update_focus=True)
        if s is None:return "Не понимаю, о ком или о чём вопрос."
        vals=[]
        for row in self._event_rows(s,pq['relation']):
            if row['polarity']=='NEG':continue
            v=self.g.object_surface(row['object_fact'])
            if v not in vals:vals.append(v)
        if not vals:return "Не знаю о таком прошлом эпизоде."
        return f"В прошлом {self.g.label(s)} {pq['predicate_surface']}: " + ", ".join(vals) + "."

    def _future_predicate_truth(self,p):
        s=self._rid(p.subject,update_focus=True)
        if s is None:return "Не понимаю, о ком или о чём вопрос."
        pit=Intent("FUTURE_TRUTH_QUERY",subject=p.subject,relation=p.relation,object=p.object,raw=p.predicate_surface,polarity=p.polarity)
        ok,ov=self._qobj(pit)
        for row in self._event_rows(s,p.relation,tense="FUTURE"):
            of=row['object_fact']
            if row['polarity']==p.polarity and of.object_kind==ok and str(of.object_value)==str(ov):
                return "У меня есть такое сообщение о будущем, но это не подтверждённый исход."
        return "Не знаю. У меня нет такого сообщения о будущем."

    def _future_predicate_query(self,pq):
        s=self._rid(pq["subject"],update_focus=True)
        if s is None:return "Не понимаю, о ком или о чём вопрос."
        vals=[]
        for row in self._event_rows(s,pq['relation'],tense="FUTURE"):
            if row['polarity']=='NEG':continue
            v=self.g.object_surface(row['object_fact'])
            if v not in vals:vals.append(v)
        if not vals:return "Не знаю о таком сообщении о будущем."
        return f"По сообщениям о будущем {self.g.label(s)} {pq['predicate_surface']}: " + ", ".join(vals) + ". Это не подтверждённый исход."

    def _event_rows(self, subject_eid, relation, tense="PAST"):
        """Return admitted event rows of one explicit tense using the reverse EVENT_SUBJECT index."""
        rows=[];relation=str(relation).upper();tense=str(tense).upper()
        for sf in self.g.reverse_facts('EVENT_SUBJECT',subject_eid,object_kind='entity',viewer=self.principal,principal=self.principal,polarity='POS'):
            e=self.g.entities.get(sf.subject)
            if e is None or e.kind!='event':continue
            pf=self.g.get(e.entity_id,"EVENT_PREDICATE",viewer=self.principal,principal=self.principal)
            tf=self.g.get(e.entity_id,"EVENT_TENSE",viewer=self.principal,principal=self.principal)
            pol=self.g.get(e.entity_id,"EVENT_POLARITY",viewer=self.principal,principal=self.principal)
            of=self.g.get(e.entity_id,"EVENT_OBJECT",viewer=self.principal,principal=self.principal)
            if not (pf and tf and of):continue
            if str(pf.object_value).upper()!=relation or str(tf.object_value).upper()!=tense:continue
            rows.append({'event':e,'object_fact':of,'polarity':str(pol.object_value).upper() if pol else 'POS'})
        return sorted(rows,key=lambda x:(x['event'].created_order,x['event'].entity_id))

    def _latest_past_predicate_query(self,pq):
        s=self._rid(pq["subject"],update_focus=True)
        if s is None:return "Не понимаю, о ком или о чём вопрос."
        rows=[x for x in self._event_rows(s,pq['relation']) if x['polarity']=='POS']
        if not rows:return "Не знаю о таком прошлом эпизоде."
        r=rows[-1];v=self.g.object_surface(r['object_fact'])
        return f"Последнее подтверждённое прошлое: {self.g.label(s)} {pq['predicate_surface']} {v}."

    def _predicate_change_query(self,pq):
        """Compare latest positive past event with current admitted state. Read-only."""
        s=self._rid(pq['subject'],update_focus=True)
        if s is None:return "Не понимаю, о ком или о чём вопрос."
        rows=[x for x in self._event_rows(s,pq['relation']) if x['polarity']=='POS']
        current=self.g.get_all(s,pq['relation'],viewer=self.principal,principal=self.principal,polarity='POS')
        if not rows and not current:return "Не знаю: у меня нет ни прошлого эпизода, ни текущего состояния по этой связи."
        past=[]
        if rows:
            # Only the latest chronological episode is compared with current state;
            # older events remain available to explicit chronology queries.
            past=[self.g.object_surface(rows[-1]['object_fact'])]
        now=[]
        for f in current:
            v=self.g.object_surface(f)
            if v not in now:now.append(v)
        if past==now:
            return "По моим данным изменения не подтверждены: последнее прошлое и текущее состояние совпадают."
        return "Изменение по моим данным: раньше — " + (", ".join(past) if past else "неизвестно") + "; сейчас — " + (", ".join(now) if now else "неизвестно") + "."

    def _event_match_order(self,p):
        s=self._rid(p.subject,update_focus=False)
        if s is None:return None
        pit=Intent("EVENT_TRUTH_QUERY",subject=p.subject,relation=p.relation,object=p.object,raw=p.predicate_surface,polarity=p.polarity)
        ok,ov=self._qobj(pit)
        for row in self._event_rows(s,p.relation):
            of=row['object_fact']
            if row['polarity']==p.polarity and of.object_kind==ok and str(of.object_value)==str(ov):
                return row['event'].created_order
        return None

    def _explain_predicate(self,p):
        """Explain an already interpreted proposition without creating evidence."""
        s=self._rid(p.subject,update_focus=True)
        if s is None:return "Не понимаю, о ком или о чём идёт речь."
        pit=Intent("TRUTH_QUERY",subject=p.subject,relation=p.relation,object=p.object,raw=p.predicate_surface,polarity=p.polarity)
        ok,ov=self._qobj(pit)
        if ok=="entity" and ov is None:return "Не знаю, поэтому не могу это объяснить."
        if p.tense=='PAST':
            order=self._event_match_order(p)
            if order is None:return "Не могу объяснить это как подтверждённый прошлый эпизод: такого эпизода у меня нет."
            return "Потому что в эпизодической памяти есть такой подтверждённый прошлый эпизод. Это запись прошлого, не текущее состояние."
        if p.relation=='CAUSES' and ok=='entity':
            r=self.reasoner.evaluate_causes(s,ov,principal=self.principal,viewer=self.principal)
            if r.value=='DIRECT':
                f=r.direct;return f"Потому что у меня есть прямая причинная связь: {self.g.label(f.subject)} → {self.g.object_surface(f)}. Источник: {f.origin}."
            if r.value=='CHAIN':
                labs=[self.g.label(f.subject)+" → "+self.g.object_surface(f) for f in r.path or []]
                return "Это не прямой факт. Вывод идёт по причинной цепочке: " + "; ".join(labs) + "."
            if r.value=='CONFLICT':return "Я не могу дать однозначное объяснение: в причинных знаниях есть противоречие."
            if r.value=='FALSE':return "Я так не считаю: прямая причинная связь явно отвергнута."
            return "Я этого не знаю, поэтому объяснения у меня нет."
        if p.relation=='IS_A' and ok=='entity':
            x=self.reasoner.explain_is_a(s,ov,principal=self.principal,viewer=self.principal)
            if x['value']=='UNKNOWN':return "Я этого не знаю, поэтому объяснения у меня нет."
            if x['value']=='CONFLICT':return "Я не могу дать однозначное объяснение: в знаниях есть противоречие."
            steps=x.get('steps') or []
            if not steps:return "Это тождественная ссылка на один и тот же объект."
            if x.get('derived'):
                return "Это вывод по цепочке классов: " + "; ".join(f"{z['subject']} → {z['object']}" for z in steps) + "."
            z=steps[0];return f"Потому что у меня сохранён прямой факт: {z['subject']} — {z['object']}. Источник: {z['origin']}."
        if p.relation in {'CAN','PROPERTY','USED_FOR'}:
            rr=self.reasoner.evaluate_relation(s,p.relation,ov,object_kind=ok,principal=self.principal,viewer=self.principal)
            want='FALSE' if p.polarity=='NEG' else 'TRUE'
            if rr.value=='CONFLICT':return "Я не могу дать однозначное объяснение: прямые и наследуемые знания конфликтуют."
            if rr.value!=want:return "Я так не считаю или у меня недостаточно данных."
            if rr.derived:
                chain=' → '.join([self.g.label(f.subject) for f in rr.path or []]+[self.g.label((rr.path or [])[-1].object_value)] if rr.path else [])
                src=rr.direct.origin if rr.direct else 'UNKNOWN'
                return f"Это унаследованный вывод через класс {chain}. Основание свойства: {src}."
        truth=self.g.truth(s,p.relation,ov,object_kind=ok,viewer=self.principal,principal=self.principal)
        want='FALSE' if p.polarity=='NEG' else 'TRUE'
        if truth!=want:return "Я так не считаю или у меня недостаточно данных."
        pol='NEG' if p.polarity=='NEG' else 'POS'
        f=next((x for x in self.g.get_all(s,p.relation,viewer=self.principal,principal=self.principal,polarity=pol)
                if x.object_kind==ok and str(x.object_value)==str(ov)),None)
        if not f:return "У меня есть это состояние, но я не нашла его прямое основание."
        summary=self.g.evidence_summary(s,p.relation,ov,object_kind=ok,polarity=pol,principal=self.principal)
        extra=f" Поддержка: {summary['total_count']} упоминаний, {summary['independent_sources']} независимых источников." if summary['total_count']>1 else ''
        return f"Потому что у меня есть прямой admitted-факт. Источник: {f.origin}.{extra}"

    def _relation_noun_query(self,rq):
        s=self._rid(rq["subject"],update_focus=True)
        if s is None:return "Не понимаю, о чём идёт речь. Уточни."
        rel=rq["relation"];noun=self.g.label(rq["relation_entity"]);sl=self.g.label(s)
        fs=self.g.get_all(s,rel,viewer=self.principal,principal=self.principal)
        inherited=self.reasoner.inherited_relation(s,rel,principal=self.principal,viewer=self.principal)
        algebraic=self.reasoner.algebraic_relation_values(s,rel,principal=self.principal,viewer=self.principal)
        vals=[];seen=set()
        for f in fs:
            v=self.g.object_surface(f);k=(f.object_kind,f.object_value)
            if k not in seen:seen.add(k);vals.append(v)
        for x in inherited:
            f=x.fact;k=(f.object_kind,f.object_value)
            if k not in seen:seen.add(k);vals.append(self.g.object_surface(f))
        for target,source_fact in algebraic:
            k=('entity',target)
            if k not in seen:seen.add(k);vals.append(self.g.label(target))
        if not vals:return "Не знаю. Можешь меня этому научить."
        self.last_used=[f.fact_id for f in fs]+[x.fact.fact_id for x in inherited]+[f.fact_id for _,f in algebraic]
        conflict=self.g.relation_spec(rel).cardinality=="FUNCTIONAL" and self.g.functional_source_conflict(s,rel,principal=self.principal)
        body=f"{self._cap(noun)} у {str(rq['subject']).strip()}: " + ", ".join(vals) + "."
        return body + (" Источники по этой связи расходятся." if conflict else "")

    def _query(self,it:Intent):
        s=self._rid(it.subject,update_focus=True,loose=True)
        special=self._self_user_query(it,s) if s in {self.user_eid,self.self_eid} else None
        if special is not None:return special
        if s is None:return self._unknown_with_floor(it)
        return self._query_entity(s,it)

    def _query_entity(self,s,it:Intent):
        if it.relation=="IS_A":
            # a definition question is answered by whatever defines the entity: IS_A/details first, else MEANS/ROLE/...
            out=self._definition(s) or self._facts_brief(s,limit=self.MAX_ITEMS,capitalize=True)
            return out if out is not None else self._unknown_with_floor(it,s)
        fs=self.g.get_all(s,it.relation,viewer=self.principal,principal=self.principal)
        source_conflict=self.g.relation_spec(it.relation).cardinality=="FUNCTIONAL" and self.g.functional_source_conflict(s,it.relation,principal=self.principal)
        inherited=self.reasoner.inherited_relation(s,it.relation,principal=self.principal,viewer=self.principal)
        algebraic=self.reasoner.algebraic_relation_values(s,it.relation,principal=self.principal,viewer=self.principal)
        if not fs and not inherited and not algebraic:
            vl=(self._purpose_literal(s) if it.relation=="USED_FOR" else None) or self._verb_literal_answer(s,it.raw or '')
            return vl if vl else self._unknown_with_floor(it,s)
        text=self._relation_answer(s,it.relation,fs,inherited,algebraic)
        return (text + " Источники по этой функциональной связи расходятся.") if source_conflict else text

    def _relation_answer(self,s,rel,fs,inherited,algebraic=None):
        """Direct values in one sentence, inherited values grouped per class; bounded with «подробнее»."""
        L=self._subj_word(s);entries=[];seen=set();via={}
        for f in fs:
            o=self._speech_obj(f)
            if (None,o) not in seen:seen.add((None,o));entries.append((None,o,f.fact_id))
        direct_keys={(f.object_kind,f.object_value) for f in fs}
        for x in inherited:
            f=x.fact
            if (f.object_kind,f.object_value) in direct_keys:continue
            anc=self.g.label(x.via[-1].object_value) if x.via else self.g.label(f.subject)
            o=self._speech_obj(f) if f.relation!="PROPERTY" else self.speech.agree(str(self.g.object_surface(f)).strip().rstrip('.'),s)
            if (anc,o) not in seen:
                seen.add((anc,o));entries.append((anc,o,f.fact_id));via[f.fact_id]=[e.fact_id for e in (x.via or [])]
        for target,source_fact in (algebraic or []):
            o=self.g.label(target)
            if (None,o) not in seen:
                seen.add((None,o));entries.append((None,o,source_fact.fact_id))
        shown,rest=entries[:self.MAX_ITEMS],entries[self.MAX_ITEMS:]
        joiner="; " if rel in {"MEANS","RULE"} else ", "
        rel_words={'CAN':'может','PROPERTY':'имеет свойство','USED_FOR':'используется для'}
        groups={}
        for anc,o,_ in shown:groups.setdefault(anc,[]).append(o)
        chunks=[]
        if None in groups:
            vals=groups.pop(None)
            chunks.append(self._group_sentence(s,rel,vals,joiner) if rel!="NAME" else
                          " ".join(self._render(s,f) for f in fs if str(self.g.object_surface(f)).strip().rstrip('.') in vals))
        for anc,vals in groups.items():
            chunks.append(f"По классу {anc} следует: {L} {rel_words.get(rel,'—')} {joiner.join(vals)}.")
        self.last_used=list(dict.fromkeys(x for _,_,fid in shown for x in via.get(fid,[])+[fid]))
        self.more={'label':L,'items':[(o if anc is None else f"по классу {anc}: {o}",fid) for anc,o,fid in rest]} if rest else None
        txt=" ".join(self._cap(c) for c in chunks)
        if rest:txt+=f" …и ещё {len(rest)}. Скажи «подробнее», чтобы продолжить."
        return txt

    # ------------------------------------------------------------------ G269: learning a word from a human
    # The teacher is a person (or an LLM in the teacher's seat). Everything the teacher states is a USER_SAID claim;
    # nothing here is inferred into the graph. The child asks one question at a time and checks itself by inference.
    _ADJ_END=re.compile(r"(?:ый|ий|ой|ая|яя|ое|ее|ые|ие|ого|его|ому|ему|ым|им|ую|юю|ых|их|ыми|ими)$")
    _REL_CLAUSE=re.compile(r"\s*,?\s*\b(?:который|которая|которое|которые|которого|которой|которому|которым|которых|где|чей|чья|чьё|чьи)\b\s+",re.IGNORECASE)
    _FINITE=re.compile(r"(?:ет|ёт|ит|ут|ют|ат|ят|ется|ётся|ится|ются|утся|ятся|атся|ешь|ишь|ал|ял|ил|ел|ла|ло|ли|ался|ялся|ился|лась|лось|лись)$")
    _YES={"да","ага","угу","верно","правильно","точно","конечно","именно","так и есть","да, верно","да, правильно","всё верно","все верно"}
    _NO={"нет","неа","неверно","неправильно","не так","нет, не так","нет, неверно","не совсем"}
    _DONT_KNOW={"не знаю","я не знаю","сам не знаю","сама не знаю","понятия не имею","без понятия","не помню","не уверен","не уверена"}
    _ANNOUNCE=[
        r"^«?(?P<w>[\w-]+)»?\s*(?:—|-|это)\s*(?:это\s+)?(?:новое|незнакомое)\s+(?:для тебя\s+)?слово$",
        r"^(?:запомни\s+)?(?:новое|незнакомое)\s+слово\s*[:—-]?\s*«?(?P<w>[\w-]+)»?$",
        r"^(?:есть|существует)\s+(?:такое\s+)?слово\s*[:—-]?\s*«?(?P<w>[\w-]+)»?$",
        r"^(?:я\s+)?(?:сейчас\s+)?научу\s+(?:тебя\s+)?(?:новому\s+)?слову\s*[:—-]?\s*«?(?P<w>[\w-]+)»?$",
        r"^(?:я\s+)?(?:сейчас\s+)?(?:объясню|расскажу)(?:\s+тебе)?\s*,?\s*что\s+(?:такое|значит|означает)\s+(?:слово\s+)?«?(?P<w>[\w-]+)»?$",
    ]
    _TEACH_ACK=r"^(?:я\s+)?(?:сейчас\s+)?(?:объясню|расскажу)(?:\s+тебе)?\s*,?\s*(?:что\s+(?:оно|это|он|она)\s+(?:значит|означает|такое)|что\s+это\s+за\s+слово)?$"
    _DO_YOU_KNOW=r"^(?:а\s+)?(?:ты\s+)?знаешь\s*,?\s*(?:что\s+такое|кто\s+такой|кто\s+такая|что\s+значит|слово)\s+«?(?P<w>[\w-]+(?:\s+[\w-]+)?)»?$"

    def _is_adj(self,tok):
        t=norm(tok)
        return len(t)>=4 and bool(self._ADJ_END.search(t))

    def _typed_modifier(self,word):
        eid=self._rid(word,loose=True)
        if not eid:return False
        for typ in ("свойство","цвет"):
            t=self.g.resolve(typ)
            if t and self.reasoner.evaluate_is_a(eid,t,principal=self.principal,viewer=self.principal).value=="TRUE":return True
        return False

    def _known_definition(self,eid):
        return bool(eid) and bool(self.g.get_all(eid,"IS_A",viewer=self.principal,principal=self.principal) or
                                  self.g.get(eid,"FOUNDATIONAL",viewer=self.principal,principal=self.principal))

    def _request_gap(self,kind,subject,relation=None,priority=0.7):
        self.gap_requests.append({'kind':kind,'subject':subject,'relation':relation,'priority':priority})

    def _ask_definition(self,label,eid=None):
        """The child's own question. The next statement may answer it elliptically («Это маленькое животное.»)."""
        self.pending_ask={'label':str(label),'eid':eid}
        self._request_gap('DEFINITION',eid or ('surface:'+str(label)),'IS_A')
        if eid:self.asked_in_reply.append(eid)
        return f"Что такое «{label}»?"

    def _announcement(self,text):
        t=norm(str(text)).strip(' .!')
        for pat in self._ANNOUNCE:
            m=re.match(pat,t,flags=re.IGNORECASE)
            if m:return m.group('w')
        return None

    def _teach_announce(self,label):
        eid=self._rid(label,update_focus=True,loose=True)
        if eid and eid not in {self.user_eid,self.self_eid} and self._known_definition(eid):
            brief=self._facts_brief(eid,limit=3)
            self.teach_root=eid
            return f"Это слово я уже знаю: {brief} Расскажи, что ещё о нём знаешь." if brief else "Это слово я уже знаю. Расскажи, что ещё о нём знаешь."
        if eid is None:eid=self.g.entity(label,"concept")      # a statement: the word exists (no facts are claimed)
        self._touch_focus(eid);self.teach_root=eid
        return "Хорошо, слушаю. "+self._ask_definition(self.g.label(eid),eid)

    def _do_you_know(self,label):
        eid=self._rid(label,update_focus=True,loose=True)
        if eid and self._semantic_facts(eid):
            out=self._definition(eid) or self._facts_brief(eid,limit=self.MAX_ITEMS,capitalize=True)
            return "Да. "+out
        self.teach_root=eid
        q=self._ask_definition(self.g.label(eid) if eid else label,eid)
        return "Не знаю. Расскажешь, "+q[0].lower()+q[1:]

    def _split_definition(self,body,*,teaching=False):
        """'(это) маленький пушистый зверёк, который живёт в норе и ест орехи' -> genus, adjectives, verb phrases.

        Read-only. A noun phrase that names a known concept as a whole stays whole («живое существо»). Adjectives
        become properties only in a definition context or when the head noun is already known."""
        b=re.sub(r"^(?:это\s+|это\s+—\s+)?(?:(?:такой|такая|такое|такие|какой-то|какая-то|какое-то)\s+)?","",str(body).strip(' .!'),flags=re.IGNORECASE)
        parts=self._REL_CLAUSE.split(b,maxsplit=1)
        np_=parts[0].strip(' ,');clause=parts[1].strip(' ,') if len(parts)>1 else ''
        toks=np_.split()
        if not toks:return None
        vps=self._split_vps(clause) if clause else []
        whole=self._rid(np_,loose=True)
        if whole is not None or len(toks)==1:return {'genus':np_,'adjs':[],'vps':vps}
        k=0
        while k<len(toks)-1 and self._is_adj(toks[k]):k+=1
        adjs,head=toks[:k]," ".join(toks[k:])
        # «ошибка в программе»: the genus is the noun before the preposition, the rest is a property of the defined thing
        ht=head.split();pp=''
        for j in range(1,len(ht)):
            if norm(ht[j]) in {"в","во","на","из","для","с","со","без","от","до","о","об","про","под","над","при","у","по","между","среди"}:
                pp=" ".join(ht[j:]);head=" ".join(ht[:j]);break
        if pp and (self._rid(head,loose=True) or teaching or vps):
            return {'genus':head,'adjs':adjs,'vps':[pp]+vps}
        if pp:head=" ".join(ht)
        # A classifying adjective may form a compound («живое существо»); one known to be a property or a colour
        # (admitted type structure, as in the typed-phrase organ) is a property of the defined thing.
        if adjs and (self._rid(head,loose=True) or teaching or vps or len(adjs)>=2 or all(self._typed_modifier(a) for a in adjs)):
            return {'genus':head,'adjs':adjs,'vps':vps}
        return {'genus':np_,'adjs':[],'vps':vps}

    def _split_vps(self,clause):
        """«живёт в норе и ест орехи» -> ['живёт в норе','ест орехи']; «любит гулять и играть» keeps the shared verb."""
        raw=[x.strip() for x in re.split(r"\s*,\s*(?:а\s+также\s+|и\s+)?|\s+и\s+",clause) if x.strip()]
        out=[]
        for x in raw:
            first=x.split()[0]
            # a lone non-verb word continues the previous verb: «ест орехи и ягоды», «любит гулять и играть»
            if out and len(x.split())==1 and not self._FINITE.search(norm(first)):
                verb=out[-1].split()[0];x=f"{verb} {x}"
            out.append(x)
        return out

    def _vp_intent(self,subject,vp,mode,raw):
        """One verb phrase about the subject. Known language (claim grammar, learned predicates) decides the relation;
        otherwise the phrase is kept as a literal property — no relation is guessed for an unknown verb."""
        sent=f"{subject} {vp}"
        it=self.lang.parse(sent)
        if it.kind=="CLAIM" and it.relation!="IS_A" and norm(it.subject)==norm(subject):
            return Intent(mode,subject=subject,relation=it.relation,object=it.object,raw=raw,polarity=it.polarity)
        pred=self.predicates.parse_claim(sent,principal=self.principal)
        if pred is not None and norm(pred.subject)==norm(subject) and pred.tense!="PAST":
            return Intent(mode,subject=subject,relation=pred.relation,object=pred.object,raw=raw,polarity=pred.polarity)
        return Intent(mode,subject=subject,relation="PROPERTY",object=vp.strip(' .'),raw=raw)

    def _definition_intents(self,subject,body,mode,raw,*,teaching=False):
        d=self._split_definition(body,teaching=teaching)
        if d is None:return None
        its=[Intent(mode,subject=subject,relation="IS_A",object=d['genus'],raw=raw)]
        for a in d['adjs']:
            its.append(Intent(mode,subject=subject,relation="PROPERTY",object=a,raw=raw))
        for vp in d['vps']:its.append(self._vp_intent(subject,vp,mode,raw))
        return its

    def _definition_route(self,text):
        """Copula statement whose right side is a definition («X — это [прил.] N[, который …]») -> intents, or None."""
        raw=str(text).strip()
        if raw.endswith('?'):return None
        payload=raw.rstrip('.! ');mode="CLAIM"
        m=re.match(r"^(?:запомни|помни)[:,]?\s*(.+)$",payload,flags=re.IGNORECASE)
        if m:mode="REMEMBER_CLAIM";payload=m.group(1).strip()
        if re.match(r"^(?:исправь|нет,?\s*исправь)\b",payload,flags=re.IGNORECASE):return None
        m=re.match(r"^(.+?)\s+(?:—|-)\s+(?:это\s+)?(.+)$",payload) or re.match(r"^(.+?)\s+это\s+(.+)$",payload,flags=re.IGNORECASE)
        if not m:return None
        subj,body=m.group(1).strip(),m.group(2).strip()
        if not subj or norm(subj) in PRONOUNS|self._DEIXIS or re.match(r"^не\s",body,flags=re.IGNORECASE):return None
        if len(subj.split())>4 or norm(body).startswith(("новое слово","незнакомое слово")):return None
        if self._is_question(subj) or re.match(r"^(?:исправь|правда|разве|неужели|почему|откуда|если|все|каждый|каждая|каждое)\b",subj,flags=re.IGNORECASE):return None
        teaching=self._teaching_subject(subj)
        d=self._split_definition(body,teaching=teaching)
        if d is None:return None
        if not (d['adjs'] or d['vps']) and not teaching:return None   # plain «X — Y» keeps the original claim path
        return self._definition_intents(subj,body,mode,raw,teaching=teaching)

    def _teaching_subject(self,label):
        eid=self._rid(label,loose=True)
        if self.pending_ask and (norm(self.pending_ask['label'])==norm(label) or (eid and self.pending_ask.get('eid')==eid)):return True
        return bool(eid and self.teach_root==eid)

    def _commit_definition(self,its):
        """Commit definition intents; reply with what was stored, then ONE question or a self-check by inference."""
        subj=its[0].subject;stored=[];s=None
        answered=bool(self.pending_ask and norm(self.pending_ask['label'])==norm(subj))
        # Preserve the lawful teaching basis through COMMIT.  Clearing the open
        # inquiry before mutation destroyed the very evidence that authorized
        # HUMAN_TEACHING and downgraded a valid answer to SOURCE_ASSERTED.
        for it in its:
            out=self._commit_claim(it,human_teaching=answered)
            if isinstance(out,str):return out
            s,fs=out;stored.extend(fs)
        if answered and self.pending_ask and norm(self.pending_ask['label'])==norm(subj):
            self.pending_ask=None
        if s is None:return "Не понимаю, о чём это. Уточни."
        if answered and self.teach_root is None:self.teach_root=s
        genus=[f for f in stored if f.relation=="IS_A" and f.polarity=="POS"]
        rest=[f for f in stored if f.relation!="IS_A"]
        adjs=[self._render_short(f) for f in rest if f.relation=="PROPERTY" and len(str(self.g.object_surface(f)).split())==1]
        others=[self._render_short(f) for f in rest if not (f.relation=="PROPERTY" and len(str(self.g.object_surface(f)).split())==1)]
        head=self._render(s,genus[0]).rstrip('.') if genus else self.g.label(s)
        if adjs:head+=", "+", ".join(adjs)
        txt="Запомнила: "+head+("; "+"; ".join(others) if others else "")+". Источник: ты мне это сообщил."
        self.last_used=[f.fact_id for f in stored]
        follow=self._follow_up(s,genus[0].object_value if genus and genus[0].object_kind=="entity" else None)
        return txt+(" "+follow if follow else "")

    def _render_short(self,f):
        o=str(self.g.object_surface(f))
        if f.relation=="PROPERTY":return ("не " if f.polarity=="NEG" else "")+self.speech.agree(o,f.subject)
        r=self._render(f.subject,f).rstrip('.')
        lab=self.g.label(f.subject)
        return r[len(lab):].strip(' :') if r.startswith(lab) else r

    def _follow_up(self,s,genus):
        """After a definition: ask about an unknown genus, or check a conclusion the new link makes derivable."""
        if genus is not None and not self._known_definition(genus) and genus not in {self.user_eid,self.self_eid}:
            if self.teach_root is None:self.teach_root=s
            q=self._ask_definition(self.g.label(genus),genus)
            return "А "+q[0].lower()+q[1:]
        root=self.teach_root if self.teach_root in self.g.entities else None
        if root is None or genus is None:return None
        if s==root:     # the root got a known genus: check the next class up, a conclusion that is now derivable
            anc=[f.object_value for f in self.g.get_all(genus,"IS_A",viewer=self.principal,principal=self.principal,polarity="POS")
                 if f.object_kind=="entity"]
            target=anc[0] if anc else None
        else:           # an intermediate word got defined: the root now reaches its genus
            target=genus
        if target is None or target==root:return None
        if self.reasoner.evaluate_is_a(root,target,principal=self.principal,viewer=self.principal).value!="TRUE":return None
        self.pending_confirm={'subject':root,'relation':'IS_A','object':target}
        return f"Значит, {self.g.label(root)} — {self.g.label(target)}?"

    def _pending_turn(self,text):
        """Answers to the child's own question or self-check. Returns (kind, reply) or None."""
        t=norm(str(text)).strip(' .!?,')
        if (self.pending_ask or self.teach_root) and re.match(self._TEACH_ACK,t,flags=re.IGNORECASE):
            return ("ACK","Слушаю.")
        if self.pending_confirm and (t in self._YES or t in self._NO):
            pc=self.pending_confirm;self.pending_confirm=None
            s,o=pc['subject'],pc['object']
            if t in self._YES:
                return ("ANSWER",f"Отлично, значит я правильно поняла: {self.g.label(s)} — {self.g.label(o)}.")
            out=self._commit_claim(Intent("CLAIM",subject=self.g.label(s),relation="IS_A",object=self.g.label(o),raw=str(text),polarity="NEG"))
            reply=f"Запомнила: {self.g.label(s)} — не {self.g.label(o)}."
            ex=self.reasoner.evaluate_is_a(s,o,principal=self.principal,viewer=self.principal)
            if ex.value=="CONFLICT":reply+=" Но тогда у меня противоречие с тем, что я знала раньше. Что из этого неверно?"
            return ("ANSWER",reply)
        if self.pending_ask and t in self._DONT_KNOW:
            # G310 / FOUR LAWS: a human utterance may expose UNKNOWN, but it does not
            # answer the content question and must not create a fact.  Move the current
            # inquiry out of foreground; the knowledge gap remains unresolved.
            pa=self.pending_ask;self.pending_ask=None
            if pa.get('eid'):self.deferred_asks.append(pa['eid'])
            return ("DEFER","Хорошо, спрошу потом.")
        return None

    def _elliptic_answer(self,text):
        """Resolve an open definition inquiry only when the utterance itself grounds the link.

        G310 / FOUR LAWS: temporal adjacency is not COMMIT authority.  A pending
        question may make an anaphor ("это/он/она/...") available, but an arbitrary
        next utterance is never silently reinterpreted as a definition.
        """
        if not self.pending_ask:return None
        raw=str(text).strip()
        if raw.endswith('?') or self._is_question(raw):return None
        label=self.pending_ask['label'];payload=raw.rstrip('.! ');mode="CLAIM"
        # The answer must carry its own discourse bridge to the open inquiry.
        # Explicit teaching syntax is handled below; otherwise only a genuine
        # anaphoric answer is eligible for ellipsis.  Bare unrelated statements,
        # greetings, corrections and emotional replies remain ordinary events.
        explicit_teach=bool(re.match(r"^(?:запомни|помни)\b",payload,flags=re.IGNORECASE))
        # Explicit teaching syntax may raise VALUE/intent, but it cannot select an
        # omitted subject from an open inquiry.  `Запомни` is not COMMIT authority.
        # A teacher must name the subject (`Запомни: кошка — животное`) or answer
        # naturally with a genuine anaphor (`Это животное`).
        if explicit_teach:
            return None
        anaphoric=bool(re.match(r"^(?:ну\s*,?\s*)?(?:это|оно|он|она|они)\b",payload,flags=re.IGNORECASE))
        if not anaphoric:
            return None
        m=re.match(r"^(?:запомни|помни)[:,]?\s*(.+)$",payload,flags=re.IGNORECASE)
        if m:mode="REMEMBER_CLAIM";payload=m.group(1).strip()
        m=re.match(r"^(.+?)\s+(?:—|-)\s+(.+)$",payload)
        if m and norm(m.group(1)) not in {"это"}:return None          # a full statement about something: not elliptic
        if self.lang.parse(payload).kind in {"CLAIM","REMEMBER_CLAIM","CORRECT_CLAIM"} and not re.match(r"^это\b",payload,flags=re.IGNORECASE):
            return None
        if not re.match(r"^(?:ну\s*,?\s*)?(?:это|оно|он|она|они)\b",payload,flags=re.IGNORECASE):
            toks=payload.split()
            head=self._rid(toks[0],loose=True) if toks else None
            asked=self.pending_ask.get('eid')
            if head is not None and head!=asked and len(toks)>=2:
                nxt=norm(toks[1].strip(','))
                if (self._FINITE.search(nxt) and not self._is_adj(nxt)) or self._adjective_claim(payload) is not None:
                    return None                      # «Пылесос шумный», «Пылесос убирает пыль»: a statement about пылесос
        body=re.sub(r"^(?:ну\s*,?\s*)?(?:это|оно|он|она|они)\s+(?:—\s+)?","",payload,flags=re.IGNORECASE)
        first=norm(body.split()[0]) if body.split() else ''
        if self._FINITE.search(first) and not self._is_adj(first):          # «он живёт в лесу и ест орехи»
            return [self._vp_intent(label,vp,mode,raw) for vp in self._split_vps(body)]
        return self._definition_intents(label,body,mode,raw,teaching=True)

    def _match_literal(self,s,text,rels=("PROPERTY","CAN","LIKES","HAS","USED_FOR")):
        """A stored literal of `s` (or of its classes) that says the same words as `text` (inflection-tolerant)."""
        want=tuple(_stems(text))
        if not want:return None
        seen=set();frontier=[s];depth=0
        while frontier and depth<5:
            nxt=[]
            for e in frontier:
                if e in seen:continue
                seen.add(e)
                for rel in rels:
                    for f in self.g.get_all(e,rel,viewer=self.principal,principal=self.principal,polarity=None):
                        if tuple(_stems(self.g.object_surface(f)))==want:return f
                nxt+=[f.object_value for f in self.g.get_all(e,"IS_A",viewer=self.principal,principal=self.principal,polarity="POS") if f.object_kind=="entity"]
            frontier=nxt;depth+=1
        return None

    def _opposite_false(self,s,text):
        """«Новое слово большой?» when новое слово is «маленький» and маленький OPPOSITE большой (admitted structure) -> fact, Q."""
        q=self._rid(text)
        if q is None:return None
        seen=set();frontier=[s];depth=0
        while frontier and depth<5:
            nxt=[]
            for e in frontier:
                if e in seen:continue
                seen.add(e)
                for f in self.g.get_all(e,"PROPERTY",viewer=self.principal,principal=self.principal,polarity="POS"):
                    p=f.object_value if f.object_kind=="entity" else self._rid(self.g.object_surface(f))
                    if not p or p==q:continue
                    if (self.g.truth(p,"OPPOSITE",q,object_kind="entity",viewer=self.principal,principal=self.principal)=="TRUE" or
                        self.g.truth(q,"OPPOSITE",p,object_kind="entity",viewer=self.principal,principal=self.principal)=="TRUE"):
                        return f,p
                nxt+=[f.object_value for f in self.g.get_all(e,"IS_A",viewer=self.principal,principal=self.principal,polarity="POS") if f.object_kind=="entity"]
            frontier=nxt;depth+=1
        return None

    def _literal_truth(self,words,pol,raw):
        """Yes/no about a stored phrase: «Новое слово ест орехи?», «Новое слово пушистый?», «Новое слово большой?» (via OPPOSITE)."""
        for i in range(len(words)-1,0,-1):
            left=" ".join(words[:i]);rest=" ".join(words[i:])
            s=self._rid(left,loose=True)
            if s is None or s in {self.user_eid,self.self_eid}:continue
            f=self._match_literal(s,rest)
            if f is not None:
                self.last_used=[f.fact_id]
                v=(f.polarity=="POS")==(pol=="POS")
                if f.subject!=s:
                    self.last_explain=f"Это унаследовано от класса «{self.g.label(f.subject)}»: {self._item_text(f).rstrip('.')}. Это вывод, а не наблюдение."
                return "Да." if v else "Нет."
            if pol=="POS":
                op=self._opposite_false(s,rest)
                if op is not None:
                    f,p=op;self.last_used=[f.fact_id]
                    self.last_explain=(f"Потому что {self.g.label(s)}: {self.g.object_surface(f)}, а «{self.g.label(p)}» — противоположность "
                                       f"«{rest}». Это вывод, а не наблюдение.")
                    return f"Нет: {self.g.label(s)} — {self.speech.agree(self.g.object_surface(f),s)}."
            return None
        return None

    def _verb_literal_answer(self,s,raw):
        """«Что ест новое слово?», «Где живёт новое слово?» — the question's verb matches the verb of a stored phrase of s."""
        lab_stems=set(_stems(self.g.label(s)))
        verbs={x for x in _stems(raw) if x not in lab_stems}
        if not verbs:return None
        hits=[];seen=set();frontier=[s];depth=0
        while frontier and depth<5 and not hits:
            nxt=[]
            for e in frontier:
                if e in seen:continue
                seen.add(e)
                for f in self.g.get_all(e,"PROPERTY",viewer=self.principal,principal=self.principal,polarity="POS"):
                    o=str(self.g.object_surface(f)).strip()
                    st=_stems(o)
                    if len(o.split())>=2 and st and st[0] in verbs:hits.append(f)
                nxt+=[f.object_value for f in self.g.get_all(e,"IS_A",viewer=self.principal,principal=self.principal,polarity="POS") if f.object_kind=="entity"]
            frontier=nxt;depth+=1
        if not hits:return None
        self.last_used=[f.fact_id for f in hits]
        L=self._cap(self.g.label(s))
        return " ".join(f"{L} {str(self.g.object_surface(f)).strip().rstrip('.')}." for f in hits[:4])

    def _who_does(self,raw):
        """«Кто живёт в норе?» — subjects whose stored phrase says exactly this. Read-only."""
        m=re.match(r"^(?:кто|что)\s+(.+?)\s*\??$",norm(str(raw)).strip())
        if not m:return None
        vp=m.group(1);want=tuple(_stems(vp))
        if len(want)<1 or len(vp.split())<2:return None
        hits=[]
        for fid in self.retriever.candidates(want):
            f=self.g.facts[fid]
            if f.relation not in {"PROPERTY","CAN"} or f.polarity!="POS" or f.principal!=self.principal or not self.g._visible(f,self.principal,self.principal):continue
            if tuple(_stems(self.g.object_surface(f)))==want and f.subject not in {self.user_eid,self.self_eid}:hits.append(f)
        if not hits:return None
        hits.sort(key=lambda f:f.order)
        self.last_used=[f.fact_id for f in hits[:4]]
        return " ".join(f"{self._cap(self.g.label(f.subject))} {str(self.g.object_surface(f)).strip().rstrip('.')}." for f in hits[:4])

    # ------------------------------------------------------------------ G269: speaking about qualities and preferences
    _COMPLIMENT=re.compile(r"^(?:ты\s+)?(?:такая\s+|очень\s+|просто\s+)?(?:молодец|умница|умничка|хорошая|умная|классная|милая|добрая|прелесть|лучшая|супер)(?:\s*[,!]?\s*(?:спасибо|молодец))?$")

    def _adjective_claim(self,text,base=None):
        """«Кошка пушистая», «Небо голубое», «Кошка — пушистая»: a predicate adjective that agrees with its subject is a
        PROPERTY of the subject, not a class (no entity «пушистая» is made). Proposes an Intent only; None otherwise."""
        raw=str(text).strip()
        if raw.endswith('?'):return None
        base=base or self.lang.parse(raw)
        if not (base.kind in {"UNKNOWN","REMEMBER_UNKNOWN"} or
                (base.kind in {"CLAIM","REMEMBER_CLAIM"} and base.relation=="IS_A" and len(str(base.object or '').split())==1)):
            return None
        payload=raw.rstrip('.! ');mode="CLAIM"
        m=re.match(r"^(?:запомни|помни)[:,]?\s*(.+)$",payload,flags=re.IGNORECASE)
        if m:mode="REMEMBER_CLAIM";payload=m.group(1).strip()
        m=re.match(r"^(.+?)\s+(?:(?:—|-)\s+)?(?:это\s+)?(не\s+)?(?:очень\s+|такой\s+|такая\s+|такое\s+)?([А-Яа-яЁё-]+)$",payload)
        if not m:return None
        subj,neg,adj=m.group(1).strip(),bool(m.group(2)),m.group(3)
        ag=self.speech.adjective_gender(adj)
        if not self.speech.is_adjective(adj) or ag not in {"MASC","FEM","NEUT"}:return None
        sw=subj.split();ns=norm(subj)
        if ns=="я":
            ug=self._deixis_gender(self.user_eid)
            if ug is not None and ug!=ag:return None
            return Intent(mode,subject="я",relation="PROPERTY",object=adj,raw=raw,polarity="NEG" if neg else "POS")
        if not 1<=len(sw)<=3 or ns in {"ты","мы","вы","это","этот","эта","все","всё","они"}:return None
        if self._is_question(subj) or re.match(r"^(?:исправь|правда|разве|неужели|почему|если|все|каждый|каждая|каждое|очень|так|как)\b",subj,flags=re.IGNORECASE):return None
        wid=self._rid(adj);typed=bool(wid) and self._typed_modifier(adj)
        if wid and not typed and (self.speech._get(wid,"GRAM_GENDER") or self._semantic_facts(wid)):
            return None                               # a known noun concept («животное может дышать»), not a quality
        if ag=="NEUT" and not typed and re.search(r"\s(?:—|-)\s",payload):
            return None                               # «млекопитающее — животное»: neuter substantives classify
        if ns in {"он","она","оно"}:
            sid=self._pronoun_candidate(ns)
            if sid is None:return None
            g=self.speech.gender(sid)
        else:
            sid=self._rid(subj,loose=True)
            if sid is None and len(sw)>1:return None
            g=self.speech.gender(sid) if sid else self.speech.word_gender(sw[-1])
            if sid is None and g is None:return None
        if g is not None and g!=ag:return None
        return Intent(mode,subject=subj,relation="PROPERTY",object=adj,raw=raw,polarity="NEG" if neg else "POS")

    def _which_query(self,raw0):
        """«Какая собака?» — the subject's qualities; «Какого цвета небо?» — its colour. Read-only."""
        t=norm(raw0).strip(' ?!.')
        m=re.match(r"^какого\s+цвета\s+(?:бывает\s+|бывают\s+)?(.+)$",t)
        if m:return self._colour_answer(m.group(1).strip(),raw0)
        m=re.match(r"^(какой|какая|какое|какие)\s+(?:же\s+)?(.+)$",t)
        if not m or str(getattr(self,'_cur_text','')).strip().endswith('!'):return None     # «Какая красота!» exclaims
        qw,x=m.group(1),m.group(2).strip()
        if len(x.split())>3 or self.lang.parse(raw0).kind!="UNKNOWN":return None    # «какие у тебя правила» is RULE
        if re.match(r"^(?:у|в|во|на|для|о|об|про|с|со|из|от|по|к)\s",x):return None
        s=self._rid(x,update_focus=True,loose=len(x.split())==1)
        if s==self.self_eid:return self._about_self()
        if s==self.user_eid:
            fs=[f for f in self.g.get_all(s,"PROPERTY",viewer=self.principal,principal=self.principal,polarity="POS")
                if self.speech.is_adjective(str(self.g.object_surface(f)))]
            if not fs:return "Не знаю: ты мне про себя такого не говорил."
            self.last_used=[f.fact_id for f in fs[:6]]
            adjs=list(dict.fromkeys(self.speech.agree(str(self.g.object_surface(f)),gender=self._deixis_gender(s)) for f in fs))
            return "Ты "+(adjs[0] if len(adjs)==1 else ", ".join(adjs[:-1][:5])+" и "+adjs[-1])+"."
        if s is None:      # «Какой бокр?» — but «Какой ужас!» is an exclamation, not a question
            if len(x.split())!=1 or x in STOPWORDS or not str(getattr(self,'_cur_text','')).strip().endswith('?'):return None
            return self._lead_with_floor(f"Не знаю, {qw} {x}.",Intent("QUERY",subject=x,relation="PROPERTY",raw=raw0))
        adjs=[];used=[]
        for e,fs in ((s,self.g.get_all(s,"PROPERTY",viewer=self.principal,principal=self.principal,polarity="POS")),):
            for f in fs:
                o=str(self.g.object_surface(f)).strip().rstrip('.')
                if len(o.split())==1 and self.speech.is_adjective(o):
                    a=self.speech.agree(o,s)
                    if a not in adjs:adjs.append(a);used.append(f.fact_id)
        if not adjs:
            for x2 in self.reasoner.inherited_relation(s,"PROPERTY",principal=self.principal,viewer=self.principal):
                o=str(self.g.object_surface(x2.fact)).strip().rstrip('.')
                if len(o.split())==1 and self.speech.is_adjective(o):
                    a=self.speech.agree(o,s)
                    if a not in adjs:adjs.append(a);used.append(x2.fact.fact_id)
        L=self._cap(self.g.label(s))
        if not adjs:
            return self._lead_with_floor(f"Не знаю, {qw} {self.g.label(s)}.",Intent("QUERY",subject=self.g.label(s),relation="PROPERTY",raw=raw0))
        self.last_used=used[:6]
        body=adjs[0] if len(adjs)==1 else ", ".join(adjs[:-1][:5])+" и "+adjs[-1]
        return f"{L} {body}."

    def _colour_answer(self,x,raw0):
        s=self._rid(x,update_focus=True,loose=True)
        if s is None:
            return self._lead_with_floor(f"Не знаю, какого цвета {x}.",Intent("QUERY",subject=x,relation="COLOR",raw=raw0))
        vals=[];used=[]
        for f in self.g.get_all(s,"COLOR",viewer=self.principal,principal=self.principal,polarity="POS"):
            vals.append(str(self.g.object_surface(f)));used.append(f.fact_id)
        cid=self.g.resolve("цвет")
        if cid:
            for f in self.g.get_all(s,"PROPERTY",viewer=self.principal,principal=self.principal,polarity="POS"):
                pid=f.object_value if f.object_kind=="entity" else self._rid(self.g.object_surface(f))
                if pid and self.reasoner.evaluate_is_a(pid,cid,principal=self.principal,viewer=self.principal).value=="TRUE":
                    vals.append(str(self.g.object_surface(f)));used.append(f.fact_id)
        if not vals:
            return self._lead_with_floor(f"Не знаю, какого цвета {self.g.label(s)}.",Intent("QUERY",subject=self.g.label(s),relation="COLOR",raw=raw0))
        self.last_used=used[:6]
        vals=list(dict.fromkeys(self.speech.agree(v,s) for v in vals))
        return f"{self._cap(self.g.label(s))} {' или '.join(vals[:3])}." if all(self.speech.is_adjective(v) for v in vals) else \
               self._cap(self.lang.render_fact(self.speech.phrase(self.g.label(s),'gen',eid=s) or self.g.label(s),"COLOR",", ".join(vals[:3]))) if self.speech.phrase(self.g.label(s),'gen',eid=s) else \
               self._cap(self.lang.render_fact(self.g.label(s),"COLOR",", ".join(vals[:3]),caseless=True))

    def _who_likes(self,raw0):
        """«Кто любит рыбу?» — subjects whose LIKES names this object (the concept or the same words). Read-only."""
        m=re.match(r"^кто\s+(не\s+)?(?:любит|любят)\s+(.+)$",norm(raw0).strip(' ?!.'))
        if not m:return None
        pol="NEG" if m.group(1) else "POS";obj=m.group(2).strip()
        oid=self._rid(obj,loose=True)
        if oid is None and norm(obj) in {"меня","тебя"}:oid=self.user_eid if norm(obj)=="меня" else self.self_eid
        want=tuple(_stems(obj));hits=[]
        cand=set(self.retriever.candidates(want)) if want else set()
        for fid in cand|{f.fact_id for f in (self.g.reverse_facts("LIKES",oid,object_kind="entity",viewer=self.principal,principal=self.principal,polarity=pol) if oid else ())}:
            f=self.g.facts.get(fid)
            if f is None or f.relation!="LIKES" or f.polarity!=pol or f.status not in ACTIVE_STATUSES:continue
            if f.principal!=self.principal or not self.g._visible(f,self.principal,self.principal):continue
            if (oid and f.object_kind=="entity" and f.object_value==oid) or tuple(_stems(self.g.object_surface(f)))==want:hits.append(f)
        if not hits:
            return f"Не знаю, кто {'не ' if pol=='NEG' else ''}любит {obj}."
        hits.sort(key=lambda f:f.order)
        self.last_used=[f.fact_id for f in hits[:4]]
        return " ".join(self._cap(self._render(f.subject,f)) for f in hits[:4])

    _IRREGULAR_VERBS={"ест","едят","даст","дадут","спит","спят","бежит","бегут","хочет","хотят","может","могут"}

    def _verbish(self,word):
        """A finite verb that opens a stored phrase («живёт в норе», «ест орехи»), not a noun or an adjective."""
        w=norm(word)
        if w in self._IRREGULAR_VERBS:return True          # «ест» is a form of the lexeme «есть», still a verb here
        return bool(self._FINITE.search(w)) and not self._is_adj(w) and self._rid(w) is None

    def _purpose_literal(self,s):
        """«Для чего нужна тяпка?» when the teacher said «инструмент для огорода»: the stored «для …» phrase answers."""
        hits=[f for f in self.g.get_all(s,"PROPERTY",viewer=self.principal,principal=self.principal,polarity="POS")
              if norm(str(self.g.object_surface(f))).startswith("для ")]
        if not hits:return None
        self.last_used=[f.fact_id for f in hits[:3]]
        return f"{self._cap(self.g.label(s))} — "+", ".join(str(self.g.object_surface(f)).strip().rstrip('.') for f in hits[:3])+"."

    def _activity_answer(self,raw0):
        """«Что делает пылесос?» — what the subject does: stored verb phrases and abilities (own, then inherited)."""
        m=re.match(r"^(?:а\s+)?что\s+(?:делает|делают|умеет делать)\s+(.+)$",norm(raw0).strip(' ?!.'))
        if not m:return None
        x=m.group(1).strip()
        s=self._rid(x,update_focus=True,loose=True)
        if s is None:
            return self._lead_with_floor(f"Не знаю, что делает {x}.",Intent("QUERY",subject=x,relation="CAN",raw=raw0)) if len(x.split())<=2 else None
        if s in {self.user_eid,self.self_eid}:return None
        vps=[];used=[]
        for f in self.g.get_all(s,"PROPERTY",viewer=self.principal,principal=self.principal,polarity="POS"):
            o=str(self.g.object_surface(f)).strip().rstrip('.');w=o.split()
            if len(w)>=2 and len(w)<=6 and self._verbish(w[0]):
                vps.append(o);used.append(f.fact_id)
        for f in self.g.get_all(s,"CAN",viewer=self.principal,principal=self.principal,polarity="POS"):
            vps.append("может "+str(self.g.object_surface(f)).strip().rstrip('.'));used.append(f.fact_id)
        if not vps:
            return self._lead_with_floor(f"Не знаю, что делает {self.g.label(s)}.",Intent("QUERY",subject=self.g.label(s),relation="CAN",raw=raw0))
        self.last_used=used[:6]
        return f"{self._cap(self.g.label(s))} "+", ".join(dict.fromkeys(vps[:6]))+"."

    def _neg_likes(self,raw0):
        """«Что я не люблю?», «Что кошка не любит?» — the stored negative preferences. Read-only."""
        m=re.match(r"^(?:а\s+)?(?:что|кого)\s+(.+?)\s+не\s+(?:любит|любят|люблю|любишь)$",norm(raw0).strip(' ?!.'))
        if not m:return None
        s=self._rid(m.group(1).strip(),update_focus=True,loose=True)
        if s is None:return None
        fs=self.g.get_all(s,"LIKES",viewer=self.principal,principal=self.principal,polarity="NEG")
        if not fs:
            who=self._subj_word(s)
            return f"Не знаю, что {who} не {'любишь' if s==self.user_eid else ('люблю' if s==self.self_eid else 'любит')}."
        self.last_used=[f.fact_id for f in fs[:6]]
        return " ".join(self._cap(self._render(s,f)) for f in fs[:6])

    def _have_name(self,raw0):
        t=norm(raw0).strip(' ?!.')
        m=re.match(r"^(?:а\s+)?(?:есть\s+ли\s+у\s+(тебя|меня)|у\s+(тебя|меня)\s+есть)\s+имя$",t)
        if not m:return None
        who=m.group(1) or m.group(2)
        s=self.self_eid if who=="тебя" else self.user_eid
        f=self.g.get(s,"NAME",viewer=self.principal,principal=self.principal)
        if f:
            self.last_used=[f.fact_id]
            return f"Да. {'Меня' if s==self.self_eid else 'Тебя'} зовут {f.object_value}."
        if s==self.self_eid:
            c=self._self_concept()
            return "Отдельного имени мне не давали."+(f" Я — {self.g.label(c)}." if c else "")
        return "Не знаю: ты мне не говорил, как тебя зовут."

    def _has_truth(self,raw0):
        """«Есть ли у кошки хвост?» = «У кошки есть хвост?» (read-only truth question)."""
        m=re.match(r"^(?:а\s+)?есть\s+ли\s+у\s+(.+)$",str(raw0).strip().rstrip('?!. '),flags=re.IGNORECASE)
        if not m:return None
        words=m.group(1).split()
        for i in range(len(words)-1,0,-1):
            left=" ".join(words[:i])
            if self._rid(left,loose=True) is not None:
                return self._yes_no_question(Intent("CLAIM",subject=left,relation="HAS",object=" ".join(words[i:]),raw=str(raw0)))
        if len(words)>=2:          # unknown owner: UNKNOWN, never FALSE
            return self._yes_no_question(Intent("CLAIM",subject=words[0],relation="HAS",object=" ".join(words[1:]),raw=str(raw0)))
        return None

    def say(self,text:str)->str:
        # G267: social acts and follow-ups («почему?», «подробнее») read the previous answer's receipts.
        self.gap_requests=[];self.asked_in_reply=[]
        spine=self._semantic_spine_meta(str(text))
        if spine is not None:
            self.last_reply_kind=spine[0];return spine[1]
        pend=self._pending_turn(str(text))            # G269: answers to the child's own question / self-check
        if pend is not None:
            self.last_reply_kind=pend[0];return pend[1]
        meta=self._meta_turn(str(text))
        if meta is not None:
            self.last_reply_kind=meta[0];return meta[1]
        self.last_used=[];self.last_explain=None;self.more=None;self.last_reply_kind="ANSWER";self.last_unknown_words=[]
        pa=self.pending_ask;self.pending_confirm=None
        out=self._say(text)
        # G310 / FOUR LAWS: an unanswered inquiry is a persistent state, not a
        # request/response transport slot.  Only semantic resolution/defer/correction
        # may change its status; an unrelated next utterance leaves it open.
        st=_stems(text)
        if self._is_elliptic(text):self.prev_stems=list(dict.fromkeys(st+self.prev_stems))[:8]
        elif st:self.prev_stems=st
        return out

    @staticmethod
    def _strip_particle(text):
        """G267: a leading discourse particle («А что она может?») is not part of the question.
        Only before a question word or pronoun: «а вызывает б» keeps its subject «а»."""
        return re.sub(r"^\s*(?:ну\s*,?\s*а|а|и|ну|так)\s*,?\s+(?=(?:что|кто|где|когда|почему|зачем|как|какой|какая|какое|какие|сколько|чей|чья|чьё|он|она|оно|они|ты|вы|правда|разве|может|если)\b)",
                      "",str(text),flags=re.IGNORECASE)

    @staticmethod
    def _normalize_remember(text):
        t=str(text).strip()
        if re.match(r"^(?:запомни|помни)\b",t,flags=re.IGNORECASE):
            m=re.match(r"^(?:запомни|помни)\s*,?\s*что\s+(.+)$",t,flags=re.IGNORECASE)
            return ("Запомни: "+m.group(1).strip()) if m else t
        m=re.match(r"^(.+?)[,\s]+(?:запомни|запомни это|запомни это себе|запомни пожалуйста|пожалуйста,? запомни)[.!]*$",t,flags=re.IGNORECASE)
        return ("Запомни: "+m.group(1).strip().rstrip(',')) if m else t

    def _say(self,text:str)->str:
        self._cur_text=text
        text=self._normalize_remember(self._strip_particle(text))
        ann=self._announcement(text)
        if ann:return self._teach_announce(ann)
        dk=re.match(self._DO_YOU_KNOW,norm(text).strip(' .!?'),flags=re.IGNORECASE)
        if dk:return self._do_you_know(dk.group('w'))
        el=self._elliptic_answer(text)
        if el:return self._commit_definition(el)
        dr=self._definition_route(text)
        if dr:return self._commit_definition(dr)
        # G52-G54: chronology/change/explanation are read-only semantic operations.
        raw0=str(text).strip().rstrip('.!?')
        ar=self._arith(raw0)
        if ar is not None:return ar
        m=re.match(r"^кто\s+(твой|твоя|твоё|твое|твои|мой|моя|моё|мое|мои)\s+(.+)$",raw0,flags=re.IGNORECASE)
        if m:
            out=self._who_is_my(m.group(1),m.group(2).strip())
            if out is not None:return out
        m=re.match(r"^кто\s+(тебя|меня)\s+([\w-]+)$",raw0,flags=re.IGNORECASE)   # «Кто тебя создал?» ~ «кто твой создатель»
        if m:
            out=self._who_is_my("твой" if m.group(1).lower()=="тебя" else "мой",m.group(2),fallback=False)
            if out is not None:return out
        # G269: qualities, colours, preferences and possession asked in everyday form (all read-only)
        for h in (self._have_name,self._which_query,self._who_likes,self._has_truth,self._activity_answer,self._neg_likes):
            out=h(raw0)
            if out is not None:return out
        if re.match(r"^ты\s+(?:не\s+)?(?:очень\s+)?(?:любишь|умеешь|можешь)\s+\S",raw0,flags=re.IGNORECASE):
            return self._yes_no_question(self.lang.parse(raw0))     # «ты любишь чай» without «?» is still a question to me
        m=re.match(r'^что\s+(?:раньше|прежде)\s+(.+)$',raw0,flags=re.IGNORECASE)
        if m:
            pq=self.predicates.parse_object_query('Что '+m.group(1),principal=self.principal)
            if pq is not None:return self._latest_past_predicate_query(pq)
        m=re.match(r'^что\s+(?:изменилось|поменялось)\s+в\s+том,?\s+что\s+(.+)$',raw0,flags=re.IGNORECASE)
        if m:
            pq=self.predicates.parse_object_query('Что '+m.group(1),principal=self.principal)
            if pq is not None:return self._predicate_change_query(pq)
        m=re.match(r'^что\s+было\s+раньше[:,]?\s*(.+?)\s+или\s+(.+)$',raw0,flags=re.IGNORECASE)
        if m:
            p1=self.predicates.parse_claim(m.group(1),principal=self.principal);p2=self.predicates.parse_claim(m.group(2),principal=self.principal)
            if p1 is not None and p2 is not None:
                o1=self._event_match_order(p1);o2=self._event_match_order(p2)
                if o1 is None or o2 is None:return "Не знаю: для сравнения мне не хватает подтверждённых прошлых эпизодов."
                if o1==o2:return "По моей хронологии эти события не различаются по порядку."
                return ("Раньше было: "+m.group(1).strip()+".") if o1<o2 else ("Раньше было: "+m.group(2).strip()+".")
        m=re.match(r'^почему\s+ты\s+считаешь,?\s+что\s+(.+)$',raw0,flags=re.IGNORECASE)
        if m:
            p=self.predicates.parse_claim(m.group(1),principal=self.principal)
            if p is not None:return self._explain_predicate(p)
        # Learned predicate truth questions must outrank broad claim regexes such as
        # `X может Y`, otherwise `Правда ли, что X может Y?` becomes a fake subject.
        ptq_early=self.predicates.parse_truth_query(text,principal=self.principal)
        if ptq_early is not None:
            if ptq_early.tense=="PAST":return self._past_predicate_truth(ptq_early)
            if ptq_early.tense=="FUTURE":return self._future_predicate_truth(ptq_early)
            pit=Intent("TRUTH_QUERY",subject=ptq_early.subject,relation=ptq_early.relation,object=ptq_early.object,raw=text,polarity=ptq_early.polarity)
            s_eid=self._rid(pit.subject,update_focus=True);ok,ov=self._qobj(pit)
            if pit.relation=="CAUSES" and (s_eid is None or (ok=="entity" and ov is None)):return "Не знаю."
            if pit.relation=="CAUSES" and pit.polarity=="POS" and ok=="entity":
                source_conflict=self.g.proposition_source_conflict(s_eid,'CAUSES',ov,object_kind='entity',principal=self.principal)
                r=self.reasoner.evaluate_causes(s_eid,ov,principal=self.principal,viewer=self.principal)
                self.last_used=[f.fact_id for f in (r.path or ([r.direct] if r.direct else []))]
                if source_conflict:
                    base={'DIRECT':'канонически прямая связь принята','CHAIN':'канонически есть только причинная цепочка','FALSE':'канонически прямая связь отвергнута','UNKNOWN':'канонического решения нет','CONFLICT':'есть структурное противоречие'}.get(r.value,r.value)
                    return "Источники расходятся; " + base + "."
                if r.value=='DIRECT': return "Да. Это прямое причинное знание."
                if r.value=='CHAIN':
                    labs=[self.g.label(f.subject)+" → "+self.g.object_surface(f) for f in r.path or []]
                    return "Не как прямой факт. У меня есть причинная цепочка: " + "; ".join(labs) + "."
                if r.value=='FALSE': return "Нет."
                if r.value=='CONFLICT': return "В моих знаниях есть причинное противоречие."
                return "Не знаю."
            # G267: every other learned truth question uses the shared evaluator (receipts, `either` readings).
            return self._truth_answer(pit.subject,pit.relation,pit.object,pit.polarity,text)
        # Parse broad/meta intent first so question surfaces are never mistaken for
        # learned relation-noun assertions. Learned exact claims may still outrank
        # the broad generic `X — Y` copula.
        qit=self.quantified.parse(text,principal=self.principal)
        if qit is not None:
            return self._claim(qit)
        # If a universal marker is present but the bounded universal grammar cannot
        # justify it, do not let a generic fallback create an entity named `все ...`.
        if re.match(r'^\s*(?:все|каждый|каждая|каждое)\s+',str(text),flags=re.IGNORECASE):
            return "Я пока не умею безопасно обобщать такую фразу на весь класс."
        di=self._deictic_intents(text)
        if di:
            outs=[self._claim(x) for x in di]
            if len(outs)==1:return outs[0]
            parts=[o.removeprefix("Запомнила: ").removesuffix(" Источник: ты мне это сообщил.") for o in outs]
            body=" ".join([parts[0]]+[self._cap(x) for x in parts[1:]])
            return f"Запомнила: {body} Источник: ты мне это сообщил."
        base_it=self.lang.parse(text)
        raw=str(text).strip();payload=raw;mode="CLAIM"
        if raw.endswith('?') and base_it.kind in {"CLAIM","REMEMBER_CLAIM","CORRECT_CLAIM"}:
            # G267: Russian yes/no questions are formed by intonation: «Кошка — это животное?».
            if base_it.kind=="CLAIM":return self._yes_no_question(base_it)
            return "Не знаю. Это выглядит как вопрос, а не утверждение."
        if base_it.kind in {"CLAIM","REMEMBER_CLAIM","CORRECT_CLAIM"}:
            if re.match(r"^(?:запомни|помни)[:,]?\s*",raw,flags=re.IGNORECASE):
                payload=re.sub(r"^(?:запомни|помни)[:,]?\s*","",raw,flags=re.IGNORECASE);mode="REMEMBER_CLAIM"
            elif re.match(r"^(?:исправь|нет,?\s*исправь)[:,]?\s*",raw,flags=re.IGNORECASE):
                payload=re.sub(r"^(?:исправь|нет,?\s*исправь)[:,]?\s*","",raw,flags=re.IGNORECASE);mode="CORRECT_CLAIM"
            rc_early=self.relation_queries.parse_claim(payload,principal=self.principal)
            if rc_early is not None:
                rit=Intent(mode,subject=rc_early["subject"],relation=rc_early["relation"],object=rc_early["object"],raw=text)
                return self._claim(rit,replace=(mode=="CORRECT_CLAIM"))
            # Ambiguity guard: an unlearned possessive-looking `X <known-genitive> — Y`
            # must not silently become a brand-new IS_A subject. Exact known multiword
            # entities still pass through the generic copula parser.
            m_relshape=re.match(r'^(.+?)\s*(?:—|-|=|это)\s*(.+)$',payload.strip().rstrip('.!?'),flags=re.IGNORECASE)
            if m_relshape:
                left=m_relshape.group(1).strip();parts=left.split()
                if len(parts)>=2 and not (self.g.resolve(left) or self.morphology.resolve(left)):
                    tail=' '.join(parts[1:])
                    if self.g.resolve(tail) or self.morphology.resolve(tail):
                        return "Не понимаю тип этой связи. Сначала научи меня, что означает это слово отношения."
        it=base_it;k=it.kind
        if k in {"CLAIM","REMEMBER_CLAIM"} and it.relation=="IS_A":
            ac=self._adjective_claim(text,base_it)
            if ac is not None:return self._claim(ac)
        if k in {"CLAIM","REMEMBER_CLAIM"}:return self._claim(it)
        if k=="CORRECT_CLAIM":return self._claim(it,replace=True)
        if k=="TRUTH_QUERY":
            return self._truth_answer(it.subject,it.relation,it.object,it.polarity,it.raw)
        if k=="EXPLAIN_QUERY":
            s=self._rid(it.subject,update_focus=True);ok,ov=self._qobj(it)
            if it.relation!="IS_A" or ok!="entity":return "Я пока не умею объяснять такой тип связи."
            if s is None or ov is None:return "Не знаю, поэтому не могу это объяснить."
            ex=self.reasoner.explain_is_a(s,ov,principal=self.principal,viewer=self.principal)
            if ex['value']=="UNKNOWN":return "Не знаю, поэтому не могу это объяснить."
            if ex['value']=="CONFLICT":return "Не могу дать однозначное объяснение: в знаниях есть противоречие."
            self.last_used=[z['fact_id'] for z in ex['steps']]
            if not ex['steps']:
                return "Это тождество, отдельная цепочка не нужна."
            if len(ex['steps'])==1 and not ex['derived']:
                z=ex['steps'][0];return f"Это прямое знание: {z['subject']} — {z['object']}."
            parts=[f"{z['subject']} — {z['object']}" for z in ex['steps']]
            return "Потому что " + ", а ".join(parts) + ". Это вывод, а не отдельное наблюдение."
        if k=="CAUSAL_TRUTH_QUERY":
            s=self._rid(it.subject,update_focus=True);o=self._rid(it.object,update_focus=False)
            if s is None or o is None:return "Не знаю."
            source_conflict=self.g.proposition_source_conflict(s,'CAUSES',o,object_kind='entity',principal=self.principal)
            r=self.reasoner.evaluate_causes(s,o,principal=self.principal,viewer=self.principal)
            self.last_used=[f.fact_id for f in (r.path or ([r.direct] if r.direct else []))]
            if source_conflict:
                base={'DIRECT':'канонически прямая связь принята','CHAIN':'канонически есть только причинная цепочка','FALSE':'канонически прямая связь отвергнута','UNKNOWN':'канонического решения нет','CONFLICT':'есть структурное противоречие'}.get(r.value,r.value)
                return "Источники расходятся; " + base + "."
            if r.value=='DIRECT': return "Да. Это прямое причинное знание."
            if r.value=='CHAIN':
                labs=[self.g.label(f.subject)+" → "+self.g.object_surface(f) for f in r.path or []]
                return "Не как прямой факт. У меня есть причинная цепочка: " + "; ".join(labs) + "."
            if r.value=='FALSE': return "Нет."
            if r.value=='CONFLICT': return "В моих знаниях есть причинное противоречие."
            return "Не знаю."
        if k=="CAUSE_QUERY":return self._cause_answer(it)
        if k=="EFFECT_QUERY":return self._effect_answer(it)
        if k=="CAUSE_CHAIN_QUERY":
            s=self._rid(it.subject,update_focus=True);o=self._rid(it.object,update_focus=False)
            if s is None or o is None:return "Не знаю такой причинной цепочки."
            r=self.reasoner.evaluate_causes(s,o,principal=self.principal,viewer=self.principal)
            self.last_used=[f.fact_id for f in (r.path or [])]
            if r.value=='DIRECT': return f"Есть прямая связь: {self.g.label(s)} → {self.g.label(o)}."
            if r.value=='CHAIN':
                labs=[self.g.label(f.subject)+" → "+self.g.object_surface(f) for f in r.path or []]
                return "Цепочка: " + "; ".join(labs) + "."
            if r.value=='CONFLICT':return "Не могу дать однозначную цепочку: есть противоречие."
            return "Не знаю такой причинной цепочки."
        if k=="PREDICT_QUERY":return self._predict_answer(it)
        if k=="QUERY":return self._query(it)
        if k=="ABOUT":return self._about(it)
        if k=="PROVENANCE":
            q=norm(it.object);candidates=[]
            inner=self.lang.parse(it.object)
            exact=False
            if inner.kind in {"CLAIM","REMEMBER_CLAIM","CORRECT_CLAIM"}:
                s=self._rid(inner.subject,update_focus=False)
                target_kind,target_val=self._qobj(inner)
                exact=s is not None and not (target_kind=="entity" and target_val is None)
                if exact:
                    for f in self.g.get_all(s,inner.relation,viewer=self.principal,principal=self.principal,polarity=inner.polarity):
                        if f.object_kind==target_kind and f.object_value==str(target_val):candidates.append(f)
            if not candidates:
                # bounded fallback for surfaces the parser cannot yet decompose. G267: the WHOLE proposition must be
                # named (subject and object as whole words) and visible to the asker; a letter or a shared object word
                # is not «the knowledge you ask about» (no provenance is claimed for knowledge I do not have).
                word=lambda x:re.search(r"(?<![\w])"+re.escape(x)+r"(?![\w])",q) is not None
                for fid in self.retriever.candidates(_stems(q)):        # G270: indexed candidates, not every fact
                    f=self.g.facts[fid]
                    obj=norm(self.g.object_surface(f));sub=norm(self.g.label(f.subject))
                    if (f.status in {"ADMITTED","REVISED"} and f.relation not in TECHNICAL_RELATIONS and obj and sub
                            and f.principal==self.principal and self.g._visible(f,self.principal,self.principal)
                            and word(obj) and word(sub)):candidates.append(f)
            if not candidates:
                if inner.kind in {"CLAIM","REMEMBER_CLAIM","CORRECT_CLAIM"}:return "Я этого не знаю: такого знания у меня нет, поэтому нет и источника."
                return "Не могу определить, о каком знании ты спрашиваешь."
            f=max(candidates,key=lambda z:z.order);self.last_used=[f.fact_id]
            source={"USER_SAID":"ты мне это сообщил","CREATOR_PRIOR":"это было дано как знание создателя","OBS":"я это наблюдала","EXTERNAL_CORPUS":"это пришло из внешнего источника"}.get(f.origin,f.origin)
            base=f"Источник: {source}. Это не считается моим собственным наблюдением." if f.origin!="OBS" else f"Источник: {source}."
            if exact:
                summary=self.g.evidence_summary(s,inner.relation,target_val,object_kind=target_kind,polarity=inner.polarity,principal=self.principal)
                stances=self.g.proposition_source_stances(s,inner.relation,target_val,object_kind=target_kind,principal=self.principal)
                extra=[]
                if summary['total_count']>1:
                    extra.append(f"Поддержка: {summary['total_count']} упоминаний, {summary['independent_sources']} независимых источников.")
                if len({x['polarity'] for x in stances})>1:
                    extra.append("Источники по этой пропозиции расходятся.")
                if extra:base += " " + " ".join(extra)
            return base
        if k in {"UNKNOWN","REMEMBER_UNKNOWN","CORRECT_UNKNOWN"}:
            payload=text
            if k.startswith("REMEMBER_"):
                payload=re.sub(r"^(?:запомни|помни)[:,]?\s*","",text.strip(),flags=re.IGNORECASE)
            elif k.startswith("CORRECT_"):
                payload=re.sub(r"^(?:исправь|нет,?\s*исправь)[:,]?\s*","",text.strip(),flags=re.IGNORECASE)
            ptq=self.predicates.parse_truth_query(payload,principal=self.principal)
            if ptq is not None and k=="UNKNOWN":
                if ptq.tense=="PAST":return self._past_predicate_truth(ptq)
                if ptq.tense=="FUTURE":return self._future_predicate_truth(ptq)
                return self._truth_answer(ptq.subject,ptq.relation,ptq.object,ptq.polarity,text)
            rc=self.relation_queries.parse_count(payload,principal=self.principal)
            if rc is not None and k=="UNKNOWN":
                s_eid=self._rid(rc["subject"],update_focus=True)
                if s_eid is None and norm(rc["subject"]) in PRONOUNS:return "Не понимаю, о чём идёт речь. Уточни."
                if s_eid is None:
                    return f"По связи «{self.g.label(rc['relation_entity'])}» для {rc['subject']} мне известно значений: 0. Это не утверждение, что других значений нет."
                fs=self.g.get_all(s_eid,rc["relation"],viewer=self.principal,principal=self.principal)
                inherited=self.reasoner.inherited_relation(s_eid,rc["relation"],principal=self.principal,viewer=self.principal)
                keys={(f.object_kind,f.object_value) for f in fs}
                keys.update((x.fact.object_kind,x.fact.object_value) for x in inherited)
                noun=self.g.label(rc["relation_entity"]);sl=self.g.label(s_eid)
                return f"По связи «{noun}» для {sl} мне известно значений: {len(keys)}. Это не утверждение, что других значений нет."
            rq=self.relation_queries.parse(payload,principal=self.principal)
            if rq is not None and k=="UNKNOWN":
                return self._relation_noun_query(rq)
            rc_claim=None if (k=='UNKNOWN' and payload.rstrip().endswith('?')) else self.relation_queries.parse_claim(payload,principal=self.principal)
            if rc_claim is not None:
                pk="CLAIM" if k=="UNKNOWN" else ("CORRECT_CLAIM" if k=="CORRECT_UNKNOWN" else "REMEMBER_CLAIM")
                rit=Intent(pk,subject=rc_claim["subject"],relation=rc_claim["relation"],object=rc_claim["object"],raw=text)
                return self._claim(rit,replace=(k=="CORRECT_UNKNOWN"))
            pq=self.predicates.parse_object_query(payload,principal=self.principal)
            if pq is not None and k=="UNKNOWN":
                if pq.get("tense")=="PAST":return self._past_predicate_query(pq)
                if pq.get("tense")=="FUTURE":return self._future_predicate_query(pq)
                return self._query(Intent("QUERY",subject=pq["subject"],relation=pq["relation"],raw=text))
            pred=None if (k=='UNKNOWN' and payload.rstrip().endswith('?')) else self.predicates.parse_claim(payload,principal=self.principal)
            if pred is not None:
                pk="CLAIM" if k=="UNKNOWN" else ("CORRECT_CLAIM" if k=="CORRECT_UNKNOWN" else "REMEMBER_CLAIM")
                pit=Intent(pk,subject=pred.subject,relation=pred.relation,object=pred.object,raw=text,polarity=pred.polarity)
                if pred.tense=="PAST":return self._event_claim(pit,"PAST")
                if pred.tense=="FUTURE":return self._event_claim(pit,"FUTURE")
                return self._claim(pit,replace=(k=="CORRECT_UNKNOWN"))
            pps=self.phrases.propose_all(payload,principal=self.principal)
            if pps and not (k=="UNKNOWN" and payload.rstrip().endswith('?')):   # G269: «Новое слово большой?» is a question
                if k=="UNKNOWN":
                    body='; '.join(f"{self.g.label(pp.subject)}: {pp.relation} = {self.g.label(pp.object_value) if pp.object_kind=='entity' else pp.object_value}" for pp in pps)
                    return f"Я понимаю это как: {body}. Это интерпретация, а не сохранённый факт."
                kw=dict(origin="USER_SAID",principal=self.principal,privacy="PRIVATE",authority="USER",source_ref=text,source_group=f"USER:{self.principal}")
                fs=[]
                for pp in pps:
                    if k=="CORRECT_UNKNOWN":f=self.g.replace_relation(pp.subject,pp.relation,pp.object_value,object_kind=pp.object_kind,**kw)
                    else:f=self.g.commit(pp.subject,pp.relation,pp.object_value,object_kind=pp.object_kind,**kw)
                    fs.append((pp,f))
                return "Запомнила: " + " ".join(self._render(pp.subject,f) for pp,f in fs) + " Источник: ты мне это сообщил."
        if k=="FORGET_TEXT":
            q=norm(it.object);hits=[]
            for (s,r,p,_),fid in list(self.g.canonical.items()):
                f=self.g.facts[fid]
                rendered=norm(self._render(s,f))
                if q in rendered or norm(self.g.object_surface(f))==q or norm(self.g.label(s))==q:hits.append((s,r,f.object_kind,f.object_value))
            if len(hits)==1:
                s,r,ok,ov=hits[0];done=self.g.forget(s,r,principal=self.principal,object_kind=ok,object_value=ov)
                return "Забыла это." if done else "Не нашла такого знания."
            if not hits:return "Не нашла такого знания."
            return "Нашла несколько подходящих знаний. Уточни, что именно забыть."
        if k in {"UNKNOWN","REMEMBER_UNKNOWN"}:
            ac=self._adjective_claim(text,base_it)
            if ac is not None:return self._claim(ac)
        zc=self._zero_copula_truth(text)
        if zc is not None:return zc
        return self._final_fallback(text)


    def semantic_intent(self,text:str)->Intent:
        """Read-only best semantic interpretation available to the child.

        Runtime/initiative uses this instead of the legacy surface parser so learned
        language and gap accounting share one semantic view. It never commits facts.
        """
        if self.pending_confirm and norm(str(text)).strip(' .!?,') in self._NO:
            pc=self.pending_confirm
            return Intent("CLAIM",subject=self.g.label(pc['subject']),relation="IS_A",object=self.g.label(pc['object']),raw=str(text),polarity="NEG")
        text=self._normalize_remember(self._strip_particle(text))
        if self._announcement(text):return Intent("UNKNOWN",raw=text)
        el=self._elliptic_answer(text)
        if el:return el[0]
        dr=self._definition_route(text)
        if dr:return dr[0]
        raw=str(text).strip();payload=raw;mode=None
        di=self._deictic_intents(text)
        if di:return di[0]
        base=self.lang.parse(text)
        if re.match(r"^ты\s+(?:не\s+)?(?:очень\s+)?(?:любишь|умеешь|можешь)\s+\S",raw.rstrip('.!?'),flags=re.IGNORECASE) and base.kind=="CLAIM":
            return Intent("TRUTH_QUERY",subject=base.subject,relation=base.relation,object=base.object,raw=text,polarity=base.polarity)
        ac=self._adjective_claim(text,base)
        if ac is not None:return ac
        if raw.endswith('?') and base.kind in {"CLAIM","REMEMBER_CLAIM","CORRECT_CLAIM"}:
            if base.kind=="CLAIM":   # G267: «X — это Y?» is a truth question, «X — это?» a definition question
                obj=re.sub(r"^(?:это|это же|ли)\s+","",str(base.object or '').strip(),flags=re.IGNORECASE).strip()
                if base.relation=="IS_A" and norm(obj).strip(' ?') in _EMPTY_COPULA_OBJECTS:
                    return Intent("QUERY",subject=base.subject,relation="IS_A",raw=text)
                return Intent("TRUTH_QUERY",subject=base.subject,relation=base.relation,object=obj,raw=text,polarity=base.polarity)
            return Intent("UNKNOWN",raw=text)
        # Exact learned universal class grammar.
        qit=self.quantified.parse(text,principal=self.principal)
        if qit is not None:return qit
        # Preserve meta/query intents from the bounded core grammar.
        if base.kind not in {"UNKNOWN","CLAIM","REMEMBER_CLAIM","CORRECT_CLAIM"}:return base
        if re.match(r"^(?:запомни|помни)[:,]?\s*",raw,flags=re.IGNORECASE):
            payload=re.sub(r"^(?:запомни|помни)[:,]?\s*","",raw,flags=re.IGNORECASE);mode="REMEMBER_CLAIM"
        elif re.match(r"^(?:исправь|нет,?\s*исправь)[:,]?\s*",raw,flags=re.IGNORECASE):
            payload=re.sub(r"^(?:исправь|нет,?\s*исправь)[:,]?\s*","",raw,flags=re.IGNORECASE);mode="CORRECT_CLAIM"
        rc=None if (mode is None and payload.rstrip().endswith('?')) else self.relation_queries.parse_claim(payload,principal=self.principal)
        if rc is not None:
            return Intent(mode or "CLAIM",subject=rc["subject"],relation=rc["relation"],object=rc["object"],raw=text)
        if mode is None:
            ptq=self.predicates.parse_truth_query(payload,principal=self.principal)
            if ptq is not None:
                qkind="EVENT_TRUTH_QUERY" if ptq.tense=="PAST" else ("FUTURE_TRUTH_QUERY" if ptq.tense=="FUTURE" else "TRUTH_QUERY")
                return Intent(qkind,subject=ptq.subject,relation=ptq.relation,object=ptq.object,raw=text,polarity=ptq.polarity)
            cnt=self.relation_queries.parse_count(payload,principal=self.principal)
            if cnt is not None:return Intent("COUNT_QUERY",subject=cnt["subject"],relation=cnt["relation"],raw=text)
            rq=self.relation_queries.parse(payload,principal=self.principal)
            if rq is not None:return Intent("QUERY",subject=rq["subject"],relation=rq["relation"],raw=text)
            pq=self.predicates.parse_object_query(payload,principal=self.principal)
            if pq is not None:
                qkind="EVENT_QUERY" if pq.get("tense")=="PAST" else ("FUTURE_QUERY" if pq.get("tense")=="FUTURE" else "QUERY")
                return Intent(qkind,subject=pq["subject"],relation=pq["relation"],raw=text)
        # Explicit bounded-core PROPERTY grammar owns phrases such as
        # «X имеет свойство Y».  Do not let the generic learned predicate
        # «иметь» reinterpret them as HAS("свойство Y").
        if base.kind in {"CLAIM","REMEMBER_CLAIM","CORRECT_CLAIM"} and base.relation=="PROPERTY":
            return base
        pred=self.predicates.parse_claim(payload,principal=self.principal)
        if pred is not None:
            pk=mode or ("FUTURE_CLAIM" if pred.tense=="FUTURE" else "CLAIM")
            return Intent(pk,subject=pred.subject,relation=pred.relation,object=pred.object,raw=text,polarity=pred.polarity)
        return base

    def save(self,path):self.g.save(path)
    @classmethod
    def load(cls,path,principal="USER"):return cls(C4Graph.load(path),principal=principal)

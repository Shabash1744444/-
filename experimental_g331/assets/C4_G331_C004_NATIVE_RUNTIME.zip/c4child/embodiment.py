from __future__ import annotations
from dataclasses import dataclass,asdict,field
from typing import Dict,List,Iterable
from .oracles import SandboxReceipt

BODY_PRIMITIVES=('LOOK','TURN','MOVE','REACH','GRASP','RELEASE','USE','SPEAK','WAIT')

@dataclass
class SkillState:
    skill_id:str
    name:str
    primitive:str
    scope:str='SANDBOX'
    attempts:int=0
    verified_successes:int=0
    verified_failures:int=0
    success_streak:int=0
    max_success_streak:int=0
    receipt_ids:List[str]=field(default_factory=list)
    def success_rate(self):
        n=self.verified_successes+self.verified_failures
        return self.verified_successes/n if n else 0.0
    def competent(self,min_verified:int=12,min_rate:float=.85,min_streak:int=4):
        n=self.verified_successes+self.verified_failures
        return n>=min_verified and self.success_rate()>=min_rate and self.max_success_streak>=min_streak

class SkillRegistry:
    SCHEMA='C4_SKILLS_V0.1'
    def __init__(self): self.skills:Dict[str,SkillState]={}
    def define(self,skill_id,name,primitive,scope='SANDBOX'):
        if primitive not in BODY_PRIMITIVES: raise ValueError('unknown primitive')
        s=self.skills.get(skill_id)
        if s is None:
            s=SkillState(str(skill_id),str(name),str(primitive),str(scope));self.skills[s.skill_id]=s
        return s
    def attempted(self,skill_id):
        self.skills[skill_id].attempts+=1
    def apply_receipt(self,skill_id,receipt:SandboxReceipt):
        s=self.skills[skill_id]
        # Only verified sandbox receipts update sandbox motor competence.
        if receipt.provenance!='SANDBOX_RECEIPT' or receipt.reality_scope!='SIMULATION':
            raise ValueError('wrong receipt domain')
        rid=f'{receipt.world_id}:{receipt.episode_id}:{receipt.step}:{receipt.post_state_hash}'
        if rid in s.receipt_ids:return s
        s.receipt_ids.append(rid)
        if receipt.success:
            s.verified_successes+=1;s.success_streak+=1;s.max_success_streak=max(s.max_success_streak,s.success_streak)
        else:
            s.verified_failures+=1;s.success_streak=0
        return s
    def to_dict(self):return {'schema':self.SCHEMA,'skills':[asdict(x) for x in self.skills.values()]}

@dataclass(frozen=True)
class CapabilityGate:
    gate_id:str
    title:str
    required_skills:tuple
    min_verified:int=12
    min_rate:float=.85
    min_streak:int=4
    def unlocked(self,registry:SkillRegistry):
        for sid in self.required_skills:
            s=registry.skills.get(sid)
            if not s or not s.competent(self.min_verified,self.min_rate,self.min_streak):return False
        return True

class NurseryWorldCurriculum:
    """Capability-gated sandbox progression; no fake XP unlocks."""
    def __init__(self):
        self.gates=(
            CapabilityGate('L0_SENSORIMOTOR','Сенсомоторная калибровка',('look_target','turn_target'),8,.80,3),
            CapabilityGate('L1_LOCOMOTION','Перемещение',('move_target','stop_target'),10,.85,3),
            CapabilityGate('L2_MANIPULATION','Манипуляция',('reach_object','grasp_object','release_object'),12,.85,4),
            CapabilityGate('L3_AFFORDANCE','Использование объектов',('use_object',),12,.85,4),
        )
    def highest_unlocked(self,registry:SkillRegistry):
        out=[]
        for gate in self.gates:
            if gate.unlocked(registry):out.append(gate.gate_id)
            else:break
        return out

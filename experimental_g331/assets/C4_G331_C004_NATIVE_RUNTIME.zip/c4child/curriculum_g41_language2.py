from __future__ import annotations

def _ev(i,s,r,o,*,ok='literal',group='G41_RU2'):
    return {'schema':'C4_BOOTSTRAP_EVENT_V0.1','event_id':f'g41:{i}','origin':'CREATOR_PRIOR','source_group':group,
            'scope':{'principal':'USER','privacy':'LOCAL'},'authority':'TEACHER',
            'payload':{'kind':'CLAIM','subject':s,'relation':r,'object':o,'object_kind':ok}}

def build_curriculum_g41_language2():
    out=[];i=0
    def add(s,r,o,ok='literal'):
        nonlocal i;i+=1;out.append(_ev(i,s,r,o,ok=ok))

    plurals={
      'собака':['собаки','собак'],'кошка':['кошки','кошек'],'животное':['животные','животных'],
      'растение':['растения','растений'],'птица':['птицы','птиц'],'рыба':['рыбы','рыб'],
      'насекомое':['насекомые','насекомых'],'млекопитающее':['млекопитающие','млекопитающих'],
      'предмет':['предметы','предметов'],'инструмент':['инструменты','инструментов'],
      'автомобиль':['автомобили','автомобилей'],'велосипед':['велосипеды','велосипедов'],
      'поезд':['поезда','поездов'],'самолёт':['самолёты','самолётов'],'корабль':['корабли','кораблей'],
      'комната':['комнаты','комнат'],'дом':['дома','домов'],'книга':['книги','книг'],
      'дерево':['деревья','деревьев'],'человек':['люди','человека','людей'],
    }
    for lemma,forms in plurals.items():
        for f in forms:add(lemma,'WORD_FORM',f)

    relation_nouns={
      'имя':('NAME',['имя','имени','имена']),
      'местоположение':('LOCATION',['местоположение','местоположения']),
      'класс':('IS_A',['класс','класса','классы']),
      'тип':('IS_A',['тип','типа','типы']),
      'способность':('CAN',['способность','способности','способностей']),
      'умение':('CAN',['умение','умения','умений']),
    }
    for lemma,(rel,forms) in relation_nouns.items():
        add(lemma,'QUERY_RELATION',rel)
        for f in forms:add(lemma,'WORD_FORM',f)
    return out

from __future__ import annotations
from .graph import fast_asdict
from dataclasses import dataclass,asdict,field
from typing import Dict,Optional,List
import hashlib

OPEN='OPEN';ASKED='ASKED';RESOLVED='RESOLVED'

@dataclass
class KnowledgeGap:
    gap_id:str
    kind:str
    subject:str
    relation:Optional[str]=None
    object_value:Optional[str]=None
    reason:str='UNKNOWN'
    first_step:int=0
    last_step:int=0
    evidence_count:int=1
    priority:float=0.5
    status:str=OPEN
    asked_count:int=0
    cause_ids:List[str]=field(default_factory=list)

class KnowledgeGapRegistry:
    SCHEMA='C4_KNOWLEDGE_GAPS_V0.1'
    def __init__(self):self.gaps:Dict[str,KnowledgeGap]={}
    @staticmethod
    def make_id(kind,subject,relation=None,object_value=None):
        raw=f'{kind}|{subject}|{relation or ""}|{object_value or ""}'.encode('utf-8')
        return 'gap:'+hashlib.blake2s(raw,digest_size=8).hexdigest()
    def register(self,kind,subject,*,relation=None,object_value=None,reason='UNKNOWN',step=0,priority=0.5,cause_id=None):
        gid=self.make_id(kind,subject,relation,object_value);g=self.gaps.get(gid)
        if g is None:
            g=KnowledgeGap(gid,str(kind),str(subject),None if relation is None else str(relation),None if object_value is None else str(object_value),str(reason),int(step),int(step),1,float(priority),OPEN,0,[])
            self.gaps[gid]=g
        else:
            g.last_step=int(step);g.evidence_count+=1;g.priority=max(g.priority,float(priority))
            if g.status==RESOLVED:g.status=OPEN
            if reason:g.reason=str(reason)
        if cause_id and cause_id not in g.cause_ids:g.cause_ids.append(str(cause_id))
        return g
    def ensure(self,kind,subject,*,relation=None,object_value=None,reason='UNKNOWN',step=0,priority=0.5,cause_id=None):
        """Idempotent gap materialization for explicit curriculum goals.

        Re-evaluating a declared goal is not new evidence that the gap matters.
        """
        gid=self.make_id(kind,subject,relation,object_value);g=self.gaps.get(gid)
        if g is None:
            return self.register(kind,subject,relation=relation,object_value=object_value,reason=reason,step=step,priority=priority,cause_id=cause_id)
        g.last_step=int(step);g.priority=max(g.priority,float(priority))
        if reason:g.reason=str(reason)
        if cause_id and cause_id not in g.cause_ids:g.cause_ids.append(str(cause_id))
        if g.status==RESOLVED:g.status=OPEN
        return g

    def resolve(self,gap_id):
        g=self.gaps.get(gap_id)
        if g:g.status=RESOLVED
        return g
    def mark_asked(self,gap_id):
        g=self.gaps.get(gap_id)
        if g:g.status=ASKED;g.asked_count+=1
        return g
    def open(self):return [g for g in self.gaps.values() if g.status in {OPEN,ASKED}]
    def to_dict(self):return {'schema':self.SCHEMA,'gaps':[fast_asdict(g) for g in self.gaps.values()]}
    @classmethod
    def from_dict(cls,d):
        x=cls()
        if not d:return x
        for raw in d.get('gaps',[]):
            g=KnowledgeGap(**raw);x.gaps[g.gap_id]=g
        return x

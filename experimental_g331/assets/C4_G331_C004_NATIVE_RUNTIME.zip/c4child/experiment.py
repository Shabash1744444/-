from __future__ import annotations
from dataclasses import dataclass,asdict
from math import log2
from typing import Dict,List,Optional

@dataclass(frozen=True)
class Hypothesis:
    hypothesis_id:str
    prior:float
    predictions:Dict[str,Dict[str,float]]  # action -> outcome -> probability

@dataclass(frozen=True)
class ExperimentProposal:
    action:str
    expected_information_gain_bits:float
    expected_outcomes:tuple
    compared_hypotheses:tuple
    reason:str='DISAMBIGUATE_HYPOTHESES'
    def to_dict(self):return asdict(self)


def _entropy(ps):
    return -sum(p*log2(p) for p in ps if p>0)

def _normalize(xs):
    s=sum(xs)
    return [x/s for x in xs] if s>0 else [1/len(xs)]*len(xs)

class ExperimentSelector:
    """Choose an informative safe action; does not execute it.

    Hypotheses provide predictive distributions over receipts for candidate actions.
    The selector maximizes expected information gain. DRIVE/permission/sandbox still
    decide whether the proposed action may actually be executed.
    """
    def choose(self,hypotheses:List[Hypothesis],allowed_actions:Optional[List[str]]=None)->Optional[ExperimentProposal]:
        if len(hypotheses)<2:return None
        priors=_normalize([max(0.0,h.prior) for h in hypotheses])
        h0=_entropy(priors)
        actions=set()
        for h in hypotheses: actions.update(h.predictions)
        if allowed_actions is not None:actions.intersection_update(allowed_actions)
        best=None
        for action in sorted(actions):
            outcomes=set()
            for h in hypotheses: outcomes.update(h.predictions.get(action,{}))
            if not outcomes:continue
            # outcome marginal and posterior entropy
            expected_h=0.0
            for outcome in outcomes:
                numer=[]
                for prior,h in zip(priors,hypotheses):
                    numer.append(prior*max(0.0,float(h.predictions.get(action,{}).get(outcome,0.0))))
                p_out=sum(numer)
                if p_out<=0:continue
                post=[x/p_out for x in numer]
                expected_h += p_out*_entropy(post)
            ig=max(0.0,h0-expected_h)
            prop=ExperimentProposal(action,ig,tuple(sorted(outcomes)),tuple(h.hypothesis_id for h in hypotheses))
            if best is None or prop.expected_information_gain_bits>best.expected_information_gain_bits+1e-12:
                best=prop
        if best is None or best.expected_information_gain_bits<=1e-12:return None
        return best

from __future__ import annotations
from typing import List,Dict,Any
import itertools,hashlib


def _eid(parts):
    raw='|'.join(map(str,parts)).encode('utf-8')
    return 'cur:'+hashlib.blake2s(raw,digest_size=8).hexdigest()

def event(subject,relation,obj,*,surface=None,origin='CREATOR_PRIOR',privacy='LOCAL',kind='RELATION',object_kind=None,repeat_tag=0):
    payload={'kind':kind,'subject':subject,'relation':relation,'object':obj}
    if surface:payload['language_surface']=surface
    if object_kind:payload['object_kind']=object_kind
    return {'schema':'C4_BOOTSTRAP_EVENT_V0.1','event_id':_eid((subject,relation,obj,repeat_tag,surface)),
            'origin':origin,'status':'ADMITTED','scope':{'principal':'USER','privacy':privacy},
            'payload':payload,'authority':'TEACHER','confidence':1.0,'source_ref':'CURRICULUM_G0_G1_V0.1'}


def build_curriculum(redundancy:int=3)->List[Dict[str,Any]]:
    unique=[]
    def add(s,r,o,surface=None,object_kind=None):unique.append((s,r,o,surface,object_kind))

    # G0: broad ontology / reusable conceptual scaffold.
    tax={
      'живое существо':['человек','животное','растение'],
      'человек':['ребёнок','взрослый'],
      'животное':['кошка','собака','лошадь','птица','рыба'],
      'растение':['дерево','трава','цветок'],
      'предмет':['стол','стул','книга','чашка','ложка','вилка','нож','мяч','телефон','компьютер'],
      'транспорт':['велосипед','автомобиль','автобус','поезд','самолёт','корабль'],
      'место':['дом','комната','кухня','улица','город','лес','школа','магазин'],
      'материал':['дерево-материал','металл','пластик','стекло','бумага','вода'],
      'еда':['хлеб','яблоко','банан','молоко','сыр','суп'],
      'действие':['идти','бежать','есть','пить','говорить','слушать','смотреть','учиться','помнить','спрашивать','отвечать','брать','класть','открывать','закрывать'],
      'свойство':['большой','маленький','горячий','холодный','быстрый','медленный','твёрдый','мягкий','светлый','тёмный'],
      'единица времени':['секунда','минута','час','день','неделя','месяц','год'],
      'число':['ноль','один','два','три','четыре','пять','шесть','семь','восемь','девять','десять'],
      'информационный объект':['вопрос','ответ','знание','память','сообщение'],
    }
    for parent,children in tax.items():
        for child in children:add(child,'IS_A',parent,f'{child} — {parent}', 'entity')


    roots=['живое существо','предмет','транспорт','место','материал','еда','действие','свойство','единица времени','число','информационный объект',
           'состояние знания','оценка утверждения','отношение','структура','временное отношение','пространственное отношение']
    for root in roots:add(root,'FOUNDATIONAL','true',f'{root} — базовое понятие текущего curriculum')

    # Core meta-concepts used by the architecture itself, but taught as creator prior, not self-experience.
    for s,o in [('неизвестно','состояние знания'),('истина','оценка утверждения'),('ложь','оценка утверждения'),
                ('причина','отношение'),('следствие','отношение'),('часть','отношение'),('целое','структура'),
                ('до','временное отношение'),('после','временное отношение'),('внутри','пространственное отношение'),('снаружи','пространственное отношение')]:
        add(s,'IS_A',o,f'{s} — {o}','entity')

    opposites=[('большой','маленький'),('горячий','холодный'),('быстрый','медленный'),('твёрдый','мягкий'),
               ('светлый','тёмный'),('до','после'),('внутри','снаружи'),('лево','право'),('верх','низ'),('истина','ложь'),('одинаковый','разный')]
    for a,b in opposites:
        add(a,'OPPOSITE',b,f'{a} противоположно {b}','entity');add(b,'OPPOSITE',a,f'{b} противоположно {a}','entity')

    # Object composition / affordance-like declarative priors.
    parts=[('колесо','велосипед'),('педаль','велосипед'),('руль','велосипед'),('колесо','автомобиль'),('дверь','автомобиль'),
           ('страница','книга'),('обложка','книга'),('экран','телефон'),('экран','компьютер'),('клавиатура','компьютер'),
           ('комната','дом'),('кухня','дом')]
    for part,whole in parts:
        add(part,'PART_OF',whole,f'{part} — часть {whole}','entity')
        add(whole,'HAS_PART',part,f'{whole} имеет часть {part}','entity')

    uses=[('ложка','есть'),('вилка','есть'),('чашка','пить'),('книга','читать'),('телефон','говорить'),('компьютер','учиться'),
          ('велосипед','ехать'),('автомобиль','ехать')]
    for obj,act in uses:add(obj,'USED_FOR',act,f'{obj} используют, чтобы {act}')

    # G1: compact Russian lexicon. Store forms/synonyms as structure; parser can consume more of this later.
    forms={
      'человек':['человек','человека','человеку','человеком','люди'],
      'ребёнок':['ребёнок','ребенка','ребёнку','дети'],
      'кошка':['кошка','кошки','кошку','кошкой'],
      'собака':['собака','собаки','собаку','собакой'],
      'велосипед':['велосипед','велосипеда','велосипеду','велосипедом','велосипеды'],
      'автомобиль':['автомобиль','автомобиля','автомобили'],
      'книга':['книга','книги','книгу','книгой'],
      'дом':['дом','дома','дому','домом'],
      'вопрос':['вопрос','вопроса','вопросы'],
      'ответ':['ответ','ответа','ответы'],
      'знание':['знание','знания','знаний'],
      'память':['память','памяти'],
    }
    for concept,vals in forms.items():
        for v in vals:add(concept,'WORD_FORM',v,f'форма слова {concept}: {v}')
    synonyms=[('автомобиль','машина'),('ребёнок','дитя'),('ответ','ответная реплика')]
    for a,b in synonyms:
        add(a,'SYNONYM',b,f'{a} близко по смыслу к {b}','entity')

    # Simple numeric/order priors.
    nums=['ноль','один','два','три','четыре','пять','шесть','семь','восемь','девять','десять']
    for i,n in enumerate(nums):add(n,'VALUE',str(i),f'{n} = {i}')
    for a,b in zip(nums,nums[1:]):
        add(a,'BEFORE',b,f'{a} перед {b}');add(b,'AFTER',a,f'{b} после {a}')

    # Create redundant teacher events deliberately. Same semantics must collapse/dedup.
    surfaces=lambda s,r,o,base:[base, f'Знание: {base}.', f'Учитель сообщает: {base}.']
    out=[]
    for s,r,o,base,ok in unique:
        ss=surfaces(s,r,o,base or f'{s} {r} {o}')
        for rep in range(max(1,redundancy)):
            out.append(event(s,r,o,surface=ss[rep%len(ss)],object_kind=ok,repeat_tag=rep))
    return out


def build_curriculum_g2_g5(redundancy:int=2)->List[Dict[str,Any]]:
    unique=[]
    def add(s,r,o,surface=None,object_kind=None,privacy='LOCAL'):
        unique.append((s,r,o,surface,object_kind,privacy))

    # G2 everyday ontology / parts / uses.
    tax={
      'мебель':['стол','стул','кровать','шкаф'],
      'посуда':['чашка','тарелка','ложка','вилка'],
      'одежда':['футболка','куртка','брюки','ботинки'],
      'часть тела':['голова','рука','нога','глаз','ухо','рот','нос'],
      'помещение':['комната','кухня','ванная'],
      'инструмент':['молоток','отвёртка','ножницы'],
      'устройство':['телефон','компьютер','лампа','холодильник'],
      'геометрическая фигура':['круг','квадрат','треугольник','прямоугольник'],
      'цвет':['красный','синий','зелёный','жёлтый','белый','чёрный'],
      'социальная роль':['родитель','ребёнок-роль','учитель','ученик','врач','пациент','продавец','покупатель'],
    }
    for parent,children in tax.items():
        add(parent,'FOUNDATIONAL','true',f'{parent} — базовое понятие текущего curriculum')
        for child in children:add(child,'IS_A',parent,f'{child} — {parent}','entity')

    parts=[('рука','человек'),('нога','человек'),('глаз','человек'),('ухо','человек'),('экран','телефон'),
           ('дверь','холодильник'),('лампа','светильник'),('клавиша','клавиатура')]
    for p,w in parts:
        add(p,'PART_OF',w,f'{p} — часть {w}','entity');add(w,'HAS_PART',p,f'{w} имеет часть {p}','entity')

    uses=[('кровать','спать'),('шкаф','хранить'),('молоток','забивать'),('отвёртка','закручивать'),('ножницы','резать'),
          ('лампа','освещать'),('холодильник','охлаждать'),('телефон','связь'),('компьютер','вычисление')]
    for o,a in uses:add(o,'USED_FOR',a,f'{o} используют для: {a}')

    # G3 project/creator priors. Private/local project knowledge, never OBS.
    project=[
      ('Singularity','IS_A','программный проект','Singularity — программный проект','entity'),
      ('C4','IS_A','исследовательская нейронная архитектура','C4 — исследовательская нейронная архитектура','entity'),
      ('C4','HAS_PART','structural graph','C4 включает structural graph','entity'),
      ('C4','HAS_PART','H3','C4 включает H3','entity'),
      ('C4','HAS_PART','living runtime','C4 включает living runtime','entity'),
      ('C4','HAS_PART','bootstrap teacher','C4 включает bootstrap teacher','entity'),
      ('EVAL','ROLE','owner domain','EVAL — owner domain','entity'),
      ('COMMIT','ROLE','owner domain','COMMIT — owner domain','entity'),
      ('DRIVE','ROLE','owner domain','DRIVE — owner domain','entity'),
      ('MEDIATE','ROLE','owner domain','MEDIATE — owner domain','entity'),
      ('C4','RULE','PROPOSAL != ADMISSION','proposal не равен admission',None),
      ('C4','RULE','REPLAY != NEW EVIDENCE','replay не является новым evidence',None),
      ('C4','RULE','USER_SAID != OBS','сообщение пользователя не является наблюдением',None),
      ('C4','RULE','CREATOR_PRIOR != SELF_EXPERIENCE','prior создателя не является собственным опытом',None),
      ('C4','RULE','UNKNOWN != FALSE','неизвестно не равно ложно',None),
      ('DRIVE','RULE','sole action arbiter','DRIVE — единственный арбитр действия',None),
    ]
    for s,r,o,surf,ok in project:add(s,r,o,surf,ok,'PRIVATE')

    # G4 number/shape/scientific-method scaffold.
    nums=['ноль','один','два','три','четыре','пять','шесть','семь','восемь','девять','десять']
    for a,b in zip(nums,nums[1:]):add(a,'SUCCESSOR',b,f'после числа {a} идёт {b}','entity')
    for shape,sides,corners in [('треугольник','3','3'),('квадрат','4','4'),('прямоугольник','4','4')]:
        add(shape,'HAS_SIDES',sides,f'у {shape} {sides} стороны');add(shape,'HAS_CORNERS',corners,f'у {shape} {corners} угла')
    add('круг','HAS_CORNERS','0','у круга нет углов')
    science=[('наблюдение','IS_A','источник данных'),('гипотеза','IS_A','проверяемое предположение'),('эксперимент','IS_A','проверка гипотезы'),
             ('измерение','IS_A','получение значения'),('ошибка измерения','IS_A','неопределённость'),('доказательство','IS_A','обоснование')]
    for s,r,o in science:add(s,r,o,f'{s} — {o}','entity')
    add('научный метод','HAS_PART','наблюдение','научный метод использует наблюдение','entity')
    add('научный метод','HAS_PART','гипотеза','научный метод использует гипотезу','entity')
    add('научный метод','HAS_PART','эксперимент','научный метод использует эксперимент','entity')

    # G5 tutoring/dialogue/action scaffold.
    dialogue=[('спрашивать','IS_A','действие'),('отвечать','IS_A','действие'),('учить','IS_A','действие'),('исправлять','IS_A','действие'),
              ('запоминать','IS_A','действие'),('забывать','IS_A','действие'),('объяснять','IS_A','действие'),
              ('вопрос','USED_FOR','получение информации'),('ответ','USED_FOR','передача информации'),('исправление','USED_FOR','пересмотр знания')]
    for s,r,o in dialogue:add(s,r,o,f'{s}: {o}','entity' if r=='IS_A' else None)

    out=[]
    for s,r,o,base,ok,privacy in unique:
        forms=[base or f'{s} {r} {o}',f'Знание: {base or f"{s} {r} {o}"}.']
        for rep in range(max(1,redundancy)):
            out.append(event(s,r,o,surface=forms[rep%len(forms)],object_kind=ok,repeat_tag=1000+rep,privacy=privacy))
    return out

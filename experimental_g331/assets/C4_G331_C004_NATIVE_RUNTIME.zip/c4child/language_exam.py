from __future__ import annotations
from dataclasses import dataclass,asdict
import random
from .language_ru import Intent

@dataclass
class LanguageProbe:
    kind:str
    question:str
    expected:str
    answer:str
    passed:bool

class LanguageExamEngine:
    """Read-only exam generated from admitted language bindings and world facts."""
    def __init__(self,dialogue,seed=49):self.d=dialogue;self.rng=random.Random(seed)
    def _probe(self,kind,q,expected,pred):
        g=self.d.g;before=(len(g.facts),len(g.entities),g.order);ans=self.d.say(q);after=(len(g.facts),len(g.entities),g.order)
        return LanguageProbe(kind,q,expected,ans,bool(pred(ans)) and before==after)
    def _lexemes_for(self,relname):
        g=self.d.g;out=[]
        for e in g.entities.values():
            f=g.get(e.entity_id,relname,viewer=self.d.principal,principal=self.d.principal)
            if f:out.append((e.entity_id,str(f.object_value)))
        return out
    def relation_nouns(self,limit=80):
        g=self.d.g;out=[]
        for lex,rel in self._lexemes_for('QUERY_RELATION'):
            noun=g.label(lex)
            facts=[f for f in g.facts.values() if f.status in {'ADMITTED','REVISED'} and f.principal==self.d.principal and f.relation==rel and f.polarity=='POS' and g._visible(f,self.d.principal,self.d.principal)]
            self.rng.shuffle(facts)
            for f in facts[:3]:
                s=g.label(f.subject);v=g.object_surface(f);q=f'Какой {noun} у {s}?'
                out.append(self._probe('RELATION_NOUN',q,v,lambda a,v=v:v.lower() in a.lower()))
                if len(out)>=limit:return out
        return out
    def predicate_truth(self,limit=100):
        g=self.d.g;out=[]
        for lex,rel in self._lexemes_for('PREDICATE_RELATION'):
            forms=[g.object_surface(f) for f in g.get_all(lex,'PREDICATE_PRESENT_FORM',viewer=self.d.principal,principal=self.d.principal)]
            if not forms:continue
            form=forms[0]
            facts=[f for f in g.facts.values() if f.status in {'ADMITTED','REVISED'} and f.principal==self.d.principal and f.relation==rel and f.polarity=='POS' and g._visible(f,self.d.principal,self.d.principal)]
            self.rng.shuffle(facts)
            for f in facts[:4]:
                s=g.label(f.subject);o=g.object_surface(f)
                # Ensure the same surface would resolve to the exact stored object semantics.
                ok,ov=self.d._obj(Intent('CLAIM',subject=s,relation=rel,object=o,raw=''))
                if ok!=f.object_kind or str(ov)!=str(f.object_value):continue
                q=f'Правда ли, что {s} {form} {o}?'
                if rel=='CAUSES':
                    out.append(self._probe('PREDICATE_TRUE',q,'DIRECT',lambda a:'прямое причинное' in a.lower()))
                else:
                    out.append(self._probe('PREDICATE_TRUE',q,'Да.',lambda a:a.endswith('Да.')))
                nq=f'Правда ли, что {s} не {form} {o}?'
                out.append(self._probe('PREDICATE_NEGATED_TRUE_FACT',nq,'Нет.',lambda a:a.endswith('Нет.')))
                if len(out)>=limit:return out
        return out
    def morphology(self,limit=80):
        g=self.d.g;out=[]
        items=[]
        for e in g.entities.values():
            parents=g.get_all(e.entity_id,'IS_A',viewer=self.d.principal,principal=self.d.principal)
            if not parents:continue
            forms=g.get_all(e.entity_id,'WORD_FORM',viewer=self.d.principal,principal=self.d.principal)
            for wf in forms:
                if not wf.object_value or str(wf.object_value).lower()==e.label.lower():continue
                items.append((e.entity_id,str(wf.object_value),g.object_surface(parents[0])))
        self.rng.shuffle(items)
        for eid,form,parent in items[:limit]:
            q=f'Что такое {form}?'
            out.append(self._probe('WORD_FORM_DEFINITION',q,parent,lambda a,p=parent:p.lower() in a.lower()))
        return out
    def run(self,limits=None):
        lim=limits or {};xs=[]
        xs+=self.relation_nouns(lim.get('relation_nouns',80))
        xs+=self.predicate_truth(lim.get('predicate_truth',100))
        xs+=self.morphology(lim.get('morphology',80))
        fails=[x for x in xs if not x.passed]
        by={}
        for x in xs:
            z=by.setdefault(x.kind,{'total':0,'passed':0});z['total']+=1;z['passed']+=int(x.passed)
        for z in by.values():z['accuracy']=z['passed']/z['total']
        return {'total':len(xs),'passed':len(xs)-len(fails),'failed':len(fails),'accuracy':(len(xs)-len(fails))/len(xs) if xs else 1.0,
                'by_kind':by,'failures':[asdict(x) for x in fails],'results':[asdict(x) for x in xs]}

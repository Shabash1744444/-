from __future__ import annotations
from dataclasses import dataclass
from collections import deque
from typing import List,Optional
from .graph import C4Graph,Fact

@dataclass
class ReasoningResult:
    value:str  # TRUE|FALSE|UNKNOWN|CONFLICT
    direct:Optional[Fact]=None
    path:Optional[List[Fact]]=None
    derived:bool=False
    rule_id:Optional[str]=None
    rule_antecedent:Optional[list]=None

class StructuralReasoner:
    """Bounded graph reasoning over admitted structure. No result is persisted automatically."""
    def __init__(self,graph:C4Graph,max_depth=6,rule_induction=None):self.g=graph;self.max_depth=int(max_depth);self.rule_induction=rule_induction

    def is_a_path(self,subject:str,target:str,*,principal='USER',viewer='USER'):
        if subject==target:return []
        q=deque([(subject,[])]);seen={subject}
        while q:
            cur,path=q.popleft()
            if len(path)>=self.max_depth:continue
            for f in self.g.get_all(cur,'IS_A',viewer=viewer,principal=principal,polarity='POS'):
                if f.object_kind!='entity':continue
                nxt=f.object_value;np=path+[f]
                if nxt==target:return np
                if nxt not in seen:seen.add(nxt);q.append((nxt,np))
        return None

    def evaluate_is_a(self,subject:str,target:str,*,principal='USER',viewer='USER'):
        direct=self.g.truth(subject,'IS_A',target,object_kind='entity',viewer=viewer,principal=principal)
        path=self.is_a_path(subject,target,principal=principal,viewer=viewer)
        if direct=='TRUE':
            f=next((x for x in self.g.get_all(subject,'IS_A',viewer=viewer,principal=principal,polarity='POS') if x.object_value==target),None)
            return ReasoningResult('TRUE',direct=f,path=[f] if f else path,derived=False)
        if direct=='FALSE':
            f=next((x for x in self.g.get_all(subject,'IS_A',viewer=viewer,principal=principal,polarity='NEG') if x.object_value==target),None)
            return ReasoningResult('CONFLICT' if path else 'FALSE',direct=f,path=path,derived=bool(path))
        if path:return ReasoningResult('TRUE',direct=None,path=path,derived=True)
        return ReasoningResult('UNKNOWN')

    def explain_is_a(self,subject:str,target:str,*,principal='USER',viewer='USER'):
        r=self.evaluate_is_a(subject,target,principal=principal,viewer=viewer)
        if r.value=='UNKNOWN':return {'value':'UNKNOWN','steps':[],'derived':False}
        steps=[]
        for f in r.path or []:
            steps.append({'subject':self.g.label(f.subject),'relation':f.relation,'object':self.g.object_surface(f),'origin':f.origin,'fact_id':f.fact_id})
        return {'value':r.value,'steps':steps,'derived':r.derived,'direct_negative':None if not r.direct or r.direct.polarity!='NEG' else {'subject':self.g.label(r.direct.subject),'object':self.g.object_surface(r.direct),'origin':r.direct.origin,'fact_id':r.direct.fact_id}}

@dataclass
class CausalReasoningResult:
    value:str  # DIRECT|CHAIN|FALSE|UNKNOWN|CONFLICT
    direct:Optional[Fact]=None
    path:Optional[List[Fact]]=None

# Attach bounded causal methods without changing the semantics of StructuralReasoner IS_A logic.
def _causal_path(self,cause:str,effect:str,*,principal='USER',viewer='USER'):
    if cause==effect:return []
    q=deque([(cause,[])]);seen={cause}
    while q:
        cur,path=q.popleft()
        if len(path)>=self.max_depth:continue
        for f in self.g.get_all(cur,'CAUSES',viewer=viewer,principal=principal,polarity='POS'):
            if f.object_kind!='entity':continue
            nxt=f.object_value;np=path+[f]
            if nxt==effect:return np
            if nxt not in seen:seen.add(nxt);q.append((nxt,np))
    return None

def _evaluate_causes(self,cause:str,effect:str,*,principal='USER',viewer='USER'):
    direct_truth=self.g.truth(cause,'CAUSES',effect,object_kind='entity',viewer=viewer,principal=principal)
    path=_causal_path(self,cause,effect,principal=principal,viewer=viewer)
    pos_direct=None;neg_direct=None
    for f in self.g.get_all(cause,'CAUSES',viewer=viewer,principal=principal,polarity='POS'):
        if f.object_kind=='entity' and f.object_value==effect:pos_direct=f;break
    for f in self.g.get_all(cause,'CAUSES',viewer=viewer,principal=principal,polarity='NEG'):
        if f.object_kind=='entity' and f.object_value==effect:neg_direct=f;break
    if neg_direct and path:return CausalReasoningResult('CONFLICT',direct=neg_direct,path=path)
    if pos_direct:return CausalReasoningResult('DIRECT',direct=pos_direct,path=[pos_direct])
    if neg_direct:return CausalReasoningResult('FALSE',direct=neg_direct,path=None)
    if path:return CausalReasoningResult('CHAIN',direct=None,path=path)
    return CausalReasoningResult('UNKNOWN')

def _direct_causes_of(self,effect:str,*,principal='USER',viewer='USER'):
    return self.g.reverse_facts('CAUSES',effect,object_kind='entity',viewer=viewer,principal=principal,polarity='POS')

def _direct_effects_of(self,cause:str,*,principal='USER',viewer='USER'):
    return [f for f in self.g.get_all(cause,'CAUSES',viewer=viewer,principal=principal,polarity='POS') if f.object_kind=='entity']

StructuralReasoner.causal_path=_causal_path
StructuralReasoner.evaluate_causes=_evaluate_causes
StructuralReasoner.direct_causes_of=_direct_causes_of
StructuralReasoner.direct_effects_of=_direct_effects_of

@dataclass
class InheritedRelationValue:
    fact:Fact
    via:List[Fact]

INHERITABLE_RELATIONS={'CAN','PROPERTY','USED_FOR'}

def _inherited_relation(self,subject:str,relation:str,*,principal='USER',viewer='USER'):
    relation=str(relation).upper();
    if relation not in INHERITABLE_RELATIONS:return []
    # Direct negative exclusions on the instance block the exact inherited value.
    blocked={(f.object_kind,f.object_value) for f in self.g.get_all(subject,relation,viewer=viewer,principal=principal,polarity='NEG')}
    q=deque([(subject,[])]);seen={subject};best={}
    while q:
        cur,path=q.popleft()
        if len(path)>=self.max_depth:continue
        for edge in self.g.get_all(cur,'IS_A',viewer=viewer,principal=principal,polarity='POS'):
            if edge.object_kind!='entity':continue
            anc=edge.object_value;np=path+[edge]
            if anc in seen:continue
            seen.add(anc)
            for f in self.g.get_all(anc,relation,viewer=viewer,principal=principal,polarity='POS'):
                key=(f.object_kind,f.object_value)
                if key in blocked:continue
                old=best.get(key)
                if old is None or len(np)<len(old.via):best[key]=InheritedRelationValue(f,np)
            q.append((anc,np))
    return list(best.values())

StructuralReasoner.inherited_relation=_inherited_relation

def _explain_relation(self,subject:str,relation:str,object_value:str,*,object_kind='literal',principal='USER',viewer='USER'):
    r=self.evaluate_relation(subject,relation,object_value,object_kind=object_kind,principal=principal,viewer=viewer)
    out={'value':r.value,'derived':r.derived,'kind':'UNKNOWN','subject':self.g.label(subject),'relation':str(relation).upper(),'object':self.g.label(object_value) if object_kind=='entity' and object_value in self.g.entities else str(object_value),'persistent_mutation':False}
    if r.direct is not None:
        out.update({'kind':'DIRECT_FACT','origin':r.direct.origin,'fact_id':r.direct.fact_id,'polarity':r.direct.polarity});return out
    if r.rule_id and getattr(self,'rule_induction',None) is not None:
        rule=self.rule_induction.rules.get(r.rule_id)
        ants=[]
        for rel,pol,ok,ov in (r.rule_antecedent or []):
            ants.append({'relation':rel,'polarity':pol,'object_kind':ok,'object':self.g.label(ov) if ok=='entity' and ov in self.g.entities else ov})
        out.update({'kind':'LEARNED_RULE','rule_id':r.rule_id,'antecedent':ants,'not_observation':True})
        if rule is not None:
            out['rule_status']=rule.status;out['train_support']=rule.train_support;out['validation_support']=rule.validation_support;out['validation_negatives']=rule.validation_negatives;out['independent_sources']=rule.independent_sources;out['supersedes']=rule.supersedes
        return out
    if r.derived:
        out.update({'kind':'STRUCTURAL_DERIVATION','path':[{'subject':self.g.label(f.subject),'relation':f.relation,'object':self.g.object_surface(f),'fact_id':f.fact_id} for f in (r.path or [])]})
    elif r.value in {'TRUE','FALSE'}:out['kind']='STRUCTURAL_RESULT'
    return out

StructuralReasoner.explain_relation=_explain_relation

@dataclass
class PredictionStep:
    effect:str
    depth:int
    path:List[Fact]

def _predict_effects(self,cause:str,*,principal='USER',viewer='USER',horizon=2):
    horizon=max(1,min(int(horizon),self.max_depth));out=[];q=deque([(cause,[])])
    best_depth={cause:0}
    while q:
        cur,path=q.popleft();depth=len(path)
        if depth>=horizon:continue
        for f in self.g.get_all(cur,'CAUSES',viewer=viewer,principal=principal,polarity='POS'):
            if f.object_kind!='entity':continue
            eff=f.object_value;np=path+[f];nd=len(np)
            if eff not in best_depth or nd<best_depth[eff]:
                best_depth[eff]=nd;out.append(PredictionStep(eff,nd,np));q.append((eff,np))
    return sorted(out,key=lambda x:(x.depth,self.g.label(x.effect)))

StructuralReasoner.predict_effects=_predict_effects


# G294: conservative relation algebra. Derived inverse/symmetric readings are read-only.
INVERSE_RELATIONS={
    'PART_OF':'HAS_PART',
    'HAS_PART':'PART_OF',
    'BEFORE':'AFTER',
    'AFTER':'BEFORE',
}
SYMMETRIC_RELATIONS={'SYNONYM','ANTONYM','OPPOSITE'}
ALGEBRA_RELATIONS=set(INVERSE_RELATIONS)|SYMMETRIC_RELATIONS

def _algebraic_relation_facts(self,subject:str,relation:str,object_value:str,*,object_kind='entity',principal='USER',viewer='USER'):
    """Return facts that support the exact relation by a safe inverse/symmetry law.

    Nothing is persisted.  A returned fact is the source fact whose reversed reading
    licenses the queried proposition.  Both POS and NEG are preserved, so a direct
    contradiction can be surfaced as CONFLICT instead of silently choosing a side.
    """
    relation=str(relation).upper(); target=str(object_value)
    if object_kind!='entity' or relation not in ALGEBRA_RELATIONS:return []
    source_rel=INVERSE_RELATIONS.get(relation,relation)
    out=[]
    # Query s REL o is supported by o SOURCE_REL s.
    for pol in ('POS','NEG'):
        for f in self.g.get_all(target,source_rel,viewer=viewer,principal=principal,polarity=pol):
            if f.object_kind=='entity' and f.object_value==subject:
                out.append(f)
    return out

StructuralReasoner.algebraic_relation_facts=_algebraic_relation_facts

# G300: enumerate safe read-only inverse/symmetric values for open relation queries.
def _algebraic_relation_values(self,subject:str,relation:str,*,principal='USER',viewer='USER'):
    relation=str(relation).upper()
    if relation not in ALGEBRA_RELATIONS:return []
    source_rel=INVERSE_RELATIONS.get(relation,relation)
    out=[];seen=set()
    for f in self.g.reverse_facts(source_rel,subject,object_kind='entity',viewer=viewer,principal=principal,polarity='POS'):
        target=f.subject
        if target in seen:continue
        rr=self.evaluate_relation(subject,relation,target,object_kind='entity',principal=principal,viewer=viewer)
        if rr.value=='TRUE' and rr.derived:
            seen.add(target);out.append((target,f))
    return out

StructuralReasoner.algebraic_relation_values=_algebraic_relation_values

# G296: strict temporal order algebra. BEFORE/AFTER are inverse views of one
# directed order. Positive paths compose transitively, reverse positive paths
# refute the queried order, and cycles/explicit negative-vs-positive paths are
# surfaced as CONFLICT. Nothing derived here is persisted.
TEMPORAL_RELATIONS={'BEFORE','AFTER'}

def _before_edges(self,node:str,*,principal='USER',viewer='USER'):
    out=[];seen=set()
    # node BEFORE x
    for f in self.g.get_all(node,'BEFORE',viewer=viewer,principal=principal,polarity='POS'):
        if f.object_kind!='entity':continue
        k=(f.fact_id,f.object_value)
        if k not in seen:seen.add(k);out.append((f.object_value,f))
    # x AFTER node  ==  node BEFORE x
    for f in self.g.reverse_facts('AFTER',node,object_kind='entity',viewer=viewer,principal=principal,polarity='POS'):
        k=(f.fact_id,f.subject)
        if k not in seen:seen.add(k);out.append((f.subject,f))
    return out

def _before_path(self,start:str,target:str,*,principal='USER',viewer='USER'):
    if start==target:return None
    q=deque([(start,[])]);seen={start}
    while q:
        cur,path=q.popleft()
        if len(path)>=self.max_depth:continue
        for nxt,f in _before_edges(self,cur,principal=principal,viewer=viewer):
            np=path+[f]
            if nxt==target:return np
            if nxt not in seen:
                seen.add(nxt);q.append((nxt,np))
    return None

def _evaluate_temporal_relation(self,subject:str,relation:str,target:str,*,principal='USER',viewer='USER'):
    relation=str(relation).upper();target=str(target)
    # Normalize both query surfaces to LEFT BEFORE RIGHT.
    left,right=(subject,target) if relation=='BEFORE' else (target,subject)
    pos_path=_before_path(self,left,right,principal=principal,viewer=viewer)
    reverse_path=_before_path(self,right,left,principal=principal,viewer=viewer)

    direct=self.g.truth(subject,relation,target,object_kind='entity',viewer=viewer,principal=principal)
    direct_fact=None
    if direct!='UNKNOWN':
        pol='POS' if direct=='TRUE' else 'NEG'
        direct_fact=next((x for x in self.g.get_all(subject,relation,viewer=viewer,principal=principal,polarity=pol)
                          if x.object_kind=='entity' and x.object_value==target),None)

    algebra=self.algebraic_relation_facts(subject,relation,target,object_kind='entity',principal=principal,viewer=viewer)
    neg_support=[]
    if direct_fact is not None and direct_fact.polarity=='NEG':neg_support.append(direct_fact)
    neg_support.extend(f for f in algebra if f.polarity=='NEG')

    # A strict temporal order cannot hold in both directions.
    if pos_path and reverse_path:
        return ReasoningResult('CONFLICT',direct=direct_fact,path=pos_path,derived=True)
    # Explicit negative evidence versus a positive temporal path is a conflict.
    if neg_support and pos_path:
        return ReasoningResult('CONFLICT',direct=direct_fact or neg_support[0],path=pos_path,derived=True)
    if pos_path:
        if direct=='TRUE':
            return ReasoningResult('TRUE',direct=direct_fact,path=[direct_fact] if direct_fact else pos_path,derived=False)
        return ReasoningResult('TRUE',direct=None,path=pos_path,derived=True)
    if neg_support:
        is_direct=(direct=='FALSE' and direct_fact is not None)
        return ReasoningResult('FALSE',direct=direct_fact if is_direct else None,path=[neg_support[0]],derived=not is_direct)
    # A proven reverse order refutes the queried strict order, read-only.
    if reverse_path:
        return ReasoningResult('FALSE',direct=None,path=reverse_path,derived=True)
    return ReasoningResult('UNKNOWN')

StructuralReasoner.temporal_before_path=_before_path
StructuralReasoner.evaluate_temporal_relation=_evaluate_temporal_relation

# G48: truth evaluation for typed inheritable relations, including negative class facts.
def _evaluate_relation(self,subject:str,relation:str,object_value:str,*,object_kind='literal',principal='USER',viewer='USER'):
    relation=str(relation).upper();target=str(object_value)
    if relation in TEMPORAL_RELATIONS and object_kind=='entity':
        return self.evaluate_temporal_relation(subject,relation,target,principal=principal,viewer=viewer)
    direct=self.g.truth(subject,relation,target,object_kind=object_kind,viewer=viewer,principal=principal)
    direct_fact=None
    if direct!='UNKNOWN':
        pol='POS' if direct=='TRUE' else 'NEG'
        direct_fact=next((x for x in self.g.get_all(subject,relation,viewer=viewer,principal=principal,polarity=pol)
                if x.object_kind==object_kind and x.object_value==target),None)
    algebra=self.algebraic_relation_facts(subject,relation,target,object_kind=object_kind,principal=principal,viewer=viewer)
    if algebra:
        apols={f.polarity for f in algebra}
        aval='CONFLICT' if len(apols)>1 else ('TRUE' if 'POS' in apols else 'FALSE')
        if direct!='UNKNOWN' and direct!=aval:
            return ReasoningResult('CONFLICT',direct=direct_fact,path=[algebra[0]],derived=True)
        if direct!='UNKNOWN':
            return ReasoningResult(direct,direct=direct_fact,path=[direct_fact] if direct_fact else None,derived=False)
        return ReasoningResult(aval,direct=None,path=[algebra[0]],derived=True)
    if direct!='UNKNOWN':
        return ReasoningResult(direct,direct=direct_fact,path=[direct_fact] if direct_fact else None,derived=False)
    if relation not in INHERITABLE_RELATIONS:
        if getattr(self,'rule_induction',None) is not None:
            rr=self.rule_induction.infer_truth(self.g,subject,relation,target,object_kind=object_kind,principal=principal,viewer=viewer)
            if rr.truth!='UNKNOWN':return ReasoningResult(rr.truth,direct=None,path=None,derived=rr.derived,rule_id=rr.rule_id,rule_antecedent=rr.antecedent)
        return ReasoningResult('UNKNOWN')
    q=deque([(subject,[])]);seen_depth={subject:0};by_depth={}
    while q:
        cur,path=q.popleft();depth=len(path)
        if depth>=self.max_depth:continue
        for edge in self.g.get_all(cur,'IS_A',viewer=viewer,principal=principal,polarity='POS'):
            if edge.object_kind!='entity':continue
            anc=edge.object_value;np=path+[edge];nd=len(np)
            oldd=seen_depth.get(anc)
            if oldd is None or nd<oldd:
                seen_depth[anc]=nd;q.append((anc,np))
            elif nd>oldd:
                continue
            for pol in ('POS','NEG'):
                for f in self.g.get_all(anc,relation,viewer=viewer,principal=principal,polarity=pol):
                    if f.object_kind==object_kind and f.object_value==target:
                        by_depth.setdefault(nd,[]).append((pol,f,np))
    if not by_depth:
        if getattr(self,'rule_induction',None) is not None:
            rr=self.rule_induction.infer_truth(self.g,subject,relation,target,object_kind=object_kind,principal=principal,viewer=viewer)
            if rr.truth!='UNKNOWN':return ReasoningResult(rr.truth,direct=None,path=None,derived=rr.derived,rule_id=rr.rule_id,rule_antecedent=rr.antecedent)
        return ReasoningResult('UNKNOWN')
    d=min(by_depth);rows=by_depth[d];pols={x[0] for x in rows}
    if len(pols)>1:return ReasoningResult('CONFLICT',direct=None,path=rows[0][2],derived=True)
    pol,f,path=rows[0]
    return ReasoningResult('TRUE' if pol=='POS' else 'FALSE',direct=f,path=path,derived=True)

StructuralReasoner.evaluate_relation=_evaluate_relation

from __future__ import annotations

def _ev(i,s,r,o,*,ok='literal',group='G34_RU',origin='CREATOR_PRIOR'):
    p={'kind':'CLAIM','subject':s,'relation':r,'object':o,'object_kind':ok}
    return {'schema':'C4_BOOTSTRAP_EVENT_V0.1','event_id':f'g34:{i}','origin':origin,'source_group':group,
            'scope':{'principal':'USER','privacy':'LOCAL'},'authority':'TEACHER','payload':p}

def build_curriculum_g34_language():
    out=[];i=0
    def add(s,r,o,ok='literal'):
        nonlocal i;i+=1;out.append(_ev(i,s,r,o,ok=ok))

    # Grammatical gender is lexical/discourse metadata, not world ontology.
    genders={
      'Антон':'MASC','Борис':'MASC','Иван':'MASC','Руслан':'MASC',
      'Мария':'FEM','Анна':'FEM','Александра':'FEM',
      'дом':'MASC','мяч':'MASC','стол':'MASC','велосипед':'MASC','автомобиль':'MASC','телефон':'MASC','кот':'MASC',
      'книга':'FEM','кошка':'FEM','собака':'FEM','машина':'FEM','земля':'FEM','вода':'FEM','комната':'FEM','чашка':'FEM',
      'окно':'NEUT','море':'NEUT','знание':'NEUT','животное':'NEUT','растение':'NEUT'
    }
    for w,g in genders.items():add(w,'GRAM_GENDER',g)

    # Learned predicate lexicon. Multiple verbs may present the same causal relation.
    predicates={
      'любить':('LIKES',['любит','любят'],['любил','любила','любили']),
      'обожать':('LIKES',['обожает','обожают'],['обожал','обожала','обожали']),
      'иметь':('HAS',['имеет','имеют'],['имел','имела','имели']),
      'содержать':('HAS',['содержит','содержат'],['содержал','содержала']),
      'мочь':('CAN',['может','могут'],['мог','могла','могли']),
      'уметь':('CAN',['умеет','умеют'],['умел','умела','умели']),
      'вызывать':('CAUSES',['вызывает','вызывают'],['вызывал','вызывала']),
      'порождать':('CAUSES',['порождает','порождают'],['порождал','порождала']),
    }
    for lemma,(rel,present,past) in predicates.items():
        add(lemma,'PREDICATE_RELATION',rel)
        for f in [lemma]+present+past:add(lemma,'WORD_FORM',f)
        for f in present:add(lemma,'PREDICATE_PRESENT_FORM',f)
        for f in past:add(lemma,'PREDICATE_PAST_FORM',f)


    relation_nouns={
      'цвет':('COLOR',['цвет','цвета','цвету','цветом']),
      'часть':('HAS_PART',['часть','части','частей','частью']),
      'свойство':('PROPERTY',['свойство','свойства','свойств','свойством']),
      'назначение':('USED_FOR',['назначение','назначения','назначений']),
    }
    for lemma,(rel,forms) in relation_nouns.items():
        add(lemma,'QUERY_RELATION',rel)
        for f in forms:add(lemma,'WORD_FORM',f)

    # Common noun paradigms. These are examples from which morphology may propose
    # transformations for other already-known lexemes; proposals are never auto-admitted.
    nouns={
      'стол':['стола','столу','столом','столы','столов'],
      'мяч':['мяча','мячу','мячом','мячи','мячей'],
      'окно':['окна','окну','окном','окна','окон'],
      'земля':['земли','земле','землю','землёй','землей'],
      'вода':['воды','воде','воду','водой'],
      'машина':['машины','машине','машину','машиной'],
      'комната':['комнаты','комнате','комнату','комнатой'],
      'чашка':['чашки','чашке','чашку','чашкой'],
      'тарелка':['тарелки','тарелке','тарелку','тарелкой'],
      'кнопка':['кнопки','кнопке','кнопку','кнопкой'],
    }
    for lemma,forms in nouns.items():
        for f in [lemma]+forms:add(lemma,'WORD_FORM',f)

    # Reusable adjective concepts. Their type drives typed phrase composition.
    adjective_groups={
      'цвет':{
        'синий':['синяя','синее','синие','синего','синей','синему','синим','синюю'],
        'красный':['красная','красное','красные','красного','красной','красному','красным','красную'],
        'зелёный':['зелёная','зелёное','зелёные','зелёного','зелёной','зелёному','зелёным','зелёную'],
        'белый':['белая','белое','белые','белого','белой','белому','белым','белую'],
        'чёрный':['чёрная','чёрное','чёрные','чёрного','чёрной','чёрному','чёрным','чёрную'],
      },
      'свойство':{
        'мокрый':['мокрая','мокрое','мокрые','мокрого','мокрой','мокрому','мокрым','мокрую'],
        'сухой':['сухая','сухое','сухие','сухого','сухой','сухому','сухим','сухую'],
        'большой':['большая','большое','большие','большого','большой','большому','большим','большую'],
        'маленький':['маленькая','маленькое','маленькие','маленького','маленькой','маленькому','маленьким','маленькую'],
        'горячий':['горячая','горячее','горячие','горячего','горячей','горячему','горячим','горячую'],
        'холодный':['холодная','холодное','холодные','холодного','холодной','холодному','холодным','холодную'],
      }
    }
    for typ,items in adjective_groups.items():
        for lemma,forms in items.items():
            add(lemma,'IS_A',typ,'entity')
            for f in [lemma]+forms:add(lemma,'WORD_FORM',f)
    return out

from __future__ import annotations
from dataclasses import dataclass,asdict,field
from typing import Dict,Optional,Tuple
import hashlib,json,math
import numpy as np
from .oracles import SandboxReceipt


def _v3(x):
    a=np.asarray(x,dtype=float).reshape(3)
    return a

def _receipt_id(r:SandboxReceipt):
    raw=f'{r.world_id}|{r.episode_id}|{r.step}|{r.action}|{r.pre_state_hash}|{r.post_state_hash}'.encode()
    return 'srec:'+hashlib.blake2s(raw,digest_size=10).hexdigest()

@dataclass
class SpatialTransition:
    receipt_id:str
    action:str
    pre_position:Tuple[float,float,float]
    post_position:Tuple[float,float,float]
    pre_yaw_deg:float
    post_yaw_deg:float
    local_delta:Tuple[float,float,float]
    target_id:Optional[str]=None
    target_distance_before:Optional[float]=None
    target_distance_after:Optional[float]=None
    reality_scope:str='SIMULATION'
    provenance:str='SANDBOX_TRANSITION'
    def to_dict(self):return asdict(self)

@dataclass
class SpatialEffectStats:
    action:str
    support:int=0
    success:int=0
    failure:int=0
    sum_local_delta:list=field(default_factory=lambda:[0.0,0.0,0.0])
    sum_yaw_delta:float=0.0
    sum_target_distance_delta:float=0.0
    target_distance_samples:int=0
    receipt_ids:list=field(default_factory=list)

class SpatialEffectLearner:
    """Learns sandbox action effects from verified transitions, not action names.

    The learned state is explicitly SIMULATION-scoped. It is a motor/world prior,
    not an external-world fact and not evidence that a requested action happened.
    """
    SCHEMA='C4_SPATIAL_EFFECTS_V0.1'
    def __init__(self,min_support=4,epsilon=.05):
        self.min_support=int(min_support);self.epsilon=float(epsilon);self.rows:Dict[str,SpatialEffectStats]={}
    def observe(self,receipt:SandboxReceipt,transition:SpatialTransition):
        if receipt.provenance!='SANDBOX_RECEIPT' or receipt.reality_scope!='SIMULATION':raise ValueError('unverified spatial receipt')
        if transition.reality_scope!='SIMULATION' or transition.provenance!='SANDBOX_TRANSITION':raise ValueError('wrong transition scope')
        rid=_receipt_id(receipt)
        if rid!=transition.receipt_id:raise ValueError('receipt/transition mismatch')
        action=str(receipt.action);row=self.rows.setdefault(action,SpatialEffectStats(action))
        if rid in row.receipt_ids:return row
        row.receipt_ids.append(rid);row.support+=1
        if receipt.success:
            row.success+=1
            for i,x in enumerate(transition.local_delta):row.sum_local_delta[i]+=float(x)
            dyaw=((float(transition.post_yaw_deg)-float(transition.pre_yaw_deg)+180.0)%360.0)-180.0
            row.sum_yaw_delta+=dyaw
            if transition.target_distance_before is not None and transition.target_distance_after is not None:
                row.sum_target_distance_delta+=float(transition.target_distance_after)-float(transition.target_distance_before)
                row.target_distance_samples+=1
        else:row.failure+=1
        return row
    def effect(self,action):
        row=self.rows.get(str(action))
        if not row or row.support<self.min_support:return {'action':str(action),'status':'UNKNOWN','scope':'SIMULATION','support':0 if not row else row.support}
        n=max(1,row.success);m=np.asarray(row.sum_local_delta,dtype=float)/n;yaw=row.sum_yaw_delta/n
        tags=[];e=self.epsilon
        if m[0]<-e:tags.append('LEFT')
        elif m[0]>e:tags.append('RIGHT')
        if m[1]<-e:tags.append('DOWN')
        elif m[1]>e:tags.append('UP')
        if m[2]<-e:tags.append('BACKWARD')
        elif m[2]>e:tags.append('FORWARD')
        if yaw<-1.0:tags.append('TURN_LEFT')
        elif yaw>1.0:tags.append('TURN_RIGHT')
        dd=None
        if row.target_distance_samples:
            dd=row.sum_target_distance_delta/row.target_distance_samples
            if dd<-e:tags.append('TOWARD')
            elif dd>e:tags.append('AWAY')
        return {'action':str(action),'status':'LEARNED','scope':'SIMULATION','support':row.support,'success':row.success,'failure':row.failure,
                'mean_local_delta':m.tolist(),'mean_yaw_delta':yaw,'mean_target_distance_delta':dd,'effects':tags}
    def to_dict(self):return {'schema':self.SCHEMA,'min_support':self.min_support,'epsilon':self.epsilon,'rows':[asdict(x) for x in self.rows.values()]}
    @classmethod
    def from_dict(cls,d):
        x=cls((d or {}).get('min_support',4),(d or {}).get('epsilon',.05))
        for z in (d or {}).get('rows',[]):
            row=SpatialEffectStats(**z);x.rows[row.action]=row
        return x

class Synthetic3DWorld:
    """Small deterministic 3D sandbox used only for training/evaluation.

    Axes in SELF coordinates: +x right, +y up, +z forward. Yaw is rotation
    around +y; positive yaw turns right. World labels never enter the learner.
    """
    def __init__(self,world_id='nursery3d',episode_id='e1',self_pos=(0,0,0),yaw_deg=0.0):
        self.world_id=str(world_id);self.episode_id=str(episode_id);self.step=0
        self.self_pos=_v3(self_pos);self.yaw_deg=float(yaw_deg);self.objects={};self._transitions={}
    def add_object(self,object_id,pos):self.objects[str(object_id)]={'pos':_v3(pos)};return str(object_id)
    def _basis(self,yaw=None):
        a=math.radians(self.yaw_deg if yaw is None else float(yaw));c,s=math.cos(a),math.sin(a)
        right=np.array([c,0.0,-s]);up=np.array([0.0,1.0,0.0]);forward=np.array([s,0.0,c])
        return right,up,forward
    def relative_vector(self,object_id):
        d=self.objects[str(object_id)]['pos']-self.self_pos;r,u,f=self._basis()
        return np.array([float(np.dot(d,r)),float(np.dot(d,u)),float(np.dot(d,f))])
    def distance(self,object_id):return float(np.linalg.norm(self.objects[str(object_id)]['pos']-self.self_pos))
    def qualitative(self,object_id,axis_epsilon=.15,near=1.5,far=4.0):
        x,y,z=self.relative_vector(object_id);d=self.distance(object_id);tags=[]
        tags.append('LEFT' if x<-axis_epsilon else 'RIGHT' if x>axis_epsilon else 'CENTER_X')
        tags.append('DOWN' if y<-axis_epsilon else 'UP' if y>axis_epsilon else 'LEVEL')
        tags.append('BEHIND' if z<-axis_epsilon else 'FRONT' if z>axis_epsilon else 'CENTER_Z')
        tags.append('NEAR' if d<=near else 'FAR' if d>=far else 'MID')
        return {'relative':[float(x),float(y),float(z)],'distance':d,'tags':tags,'scope':'SIMULATION'}
    def _snapshot(self):
        return {'self':[round(float(x),8) for x in self.self_pos],'yaw':round(self.yaw_deg%360.0,8),
                'objects':{k:[round(float(x),8) for x in v['pos']] for k,v in sorted(self.objects.items())}}
    def state_hash(self):
        raw=json.dumps(self._snapshot(),sort_keys=True,separators=(',',':')).encode();return hashlib.blake2s(raw,digest_size=12).hexdigest()
    def request(self,action,*,target_id=None,amount=1.0):
        pre=self.state_hash();raw=f'{self.world_id}|{self.episode_id}|{self.step}|{action}|{target_id}|{amount}|{pre}'.encode()
        return {'request_id':'areq:'+hashlib.blake2s(raw,digest_size=10).hexdigest(),'action':str(action),'target_id':None if target_id is None else str(target_id),
                'amount':float(amount),'pre_state_hash':pre,'reality_scope':'SIMULATION'}
    def apply(self,request):
        pre_hash=self.state_hash();pre_pos=self.self_pos.copy();pre_yaw=self.yaw_deg
        action=str(request['action']);target=request.get('target_id');amount=float(request.get('amount',1.0));success=True;outcome='OK'
        db=None
        if target is not None and target in self.objects:db=self.distance(target)
        if request.get('pre_state_hash')!=pre_hash:
            success=False;outcome='STALE_ACTION_REQUEST'
        else:
            r,u,f=self._basis()
            if action=='MOVE_LEFT':self.self_pos-=r*amount
            elif action=='MOVE_RIGHT':self.self_pos+=r*amount
            elif action=='MOVE_UP':self.self_pos+=u*amount
            elif action=='MOVE_DOWN':self.self_pos-=u*amount
            elif action=='MOVE_FORWARD':self.self_pos+=f*amount
            elif action=='MOVE_BACKWARD':self.self_pos-=f*amount
            elif action in {'MOVE_TOWARD','MOVE_AWAY'}:
                if target not in self.objects:success=False;outcome='UNKNOWN_TARGET'
                else:
                    v=self.objects[target]['pos']-self.self_pos;n=float(np.linalg.norm(v))
                    if n<1e-9:success=False;outcome='ZERO_DISTANCE'
                    else:self.self_pos+=(v/n)*amount*(1.0 if action=='MOVE_TOWARD' else -1.0)
            elif action=='TURN_LEFT':self.yaw_deg-=amount
            elif action=='TURN_RIGHT':self.yaw_deg+=amount
            else:success=False;outcome='UNKNOWN_ACTION'
        self.step+=1;post_hash=self.state_hash();post_pos=self.self_pos.copy();post_yaw=self.yaw_deg
        da=None
        if target is not None and target in self.objects:da=self.distance(target)
        receipt=SandboxReceipt(self.world_id,self.episode_id,self.step,action,pre_hash,post_hash,outcome,success)
        # express translation in the pre-action egocentric frame
        rr,uu,ff=self._basis(pre_yaw);dw=post_pos-pre_pos
        local=(float(np.dot(dw,rr)),float(np.dot(dw,uu)),float(np.dot(dw,ff)))
        tr=SpatialTransition(_receipt_id(receipt),action,tuple(pre_pos),tuple(post_pos),pre_yaw,post_yaw,local,target,db,da)
        self._transitions[tr.receipt_id]=tr
        return receipt,tr

# ---------------------------------------------------------------------------
# G308: contact / collision / effort-response physics

@dataclass
class InteractionTransition:
    """Environment-owned observable interaction result.

    Hidden simulator parameters (mass/resistance) are deliberately NOT exposed.
    The learner receives only motor effort plus verified geometric/outcome changes.
    """
    receipt_id:str
    action:str
    target_id:str
    effort:float
    contact:bool
    collision:bool
    pre_target_position:Tuple[float,float,float]
    post_target_position:Tuple[float,float,float]
    target_displacement:float
    surface_distance_before:float
    surface_distance_after:float
    reality_scope:str='SIMULATION'
    provenance:str='SANDBOX_INTERACTION'
    def to_dict(self):return asdict(self)

@dataclass
class InteractionActionStats:
    action:str
    support:int=0
    success:int=0
    failure:int=0
    contacts:int=0
    collisions:int=0
    receipt_ids:list=field(default_factory=list)

@dataclass
class TargetResponseStats:
    target_id:str
    samples:int=0
    sum_effort:float=0.0
    sum_displacement:float=0.0
    receipt_ids:list=field(default_factory=list)

class ContactEffortLearner:
    """Learns verified contact and effort->displacement response without semantic labels.

    The resulting response index is SIMULATION-scoped.  It is not a statement that
    an object is 'heavy', has a particular mass, or will behave identically in the
    external world.  Size/name/appearance are not learner inputs.
    """
    SCHEMA='C4_CONTACT_EFFORT_V0.1'
    def __init__(self,min_support=4,min_response_samples=4,epsilon=1e-6,separation_ratio=1.35):
        self.min_support=int(min_support);self.min_response_samples=int(min_response_samples)
        self.epsilon=float(epsilon);self.separation_ratio=float(separation_ratio)
        self.actions:Dict[str,InteractionActionStats]={};self.targets:Dict[str,TargetResponseStats]={}
    def observe(self,receipt:SandboxReceipt,transition:InteractionTransition):
        if receipt.provenance!='SANDBOX_RECEIPT' or receipt.reality_scope!='SIMULATION':raise ValueError('unverified interaction receipt')
        if transition.reality_scope!='SIMULATION' or transition.provenance!='SANDBOX_INTERACTION':raise ValueError('wrong interaction scope')
        rid=_receipt_id(receipt)
        if rid!=transition.receipt_id:raise ValueError('receipt/interaction mismatch')
        if str(receipt.action)!=str(transition.action):raise ValueError('action mismatch')
        row=self.actions.setdefault(str(receipt.action),InteractionActionStats(str(receipt.action)))
        if rid in row.receipt_ids:return row
        row.receipt_ids.append(rid);row.support+=1
        if receipt.success:row.success+=1
        else:row.failure+=1
        if transition.contact:row.contacts+=1
        if transition.collision:row.collisions+=1
        if transition.contact and transition.action=='PUSH_TARGET' and float(transition.effort)>self.epsilon:
            t=self.targets.setdefault(str(transition.target_id),TargetResponseStats(str(transition.target_id)))
            if rid not in t.receipt_ids:
                t.receipt_ids.append(rid);t.samples+=1;t.sum_effort+=float(transition.effort);t.sum_displacement+=float(transition.target_displacement)
        return row
    def interaction_effect(self,action):
        row=self.actions.get(str(action))
        if not row or row.support<self.min_support:return {'action':str(action),'status':'UNKNOWN','scope':'SIMULATION','support':0 if not row else row.support}
        effects=[];contact_rate=row.contacts/row.support;collision_rate=row.collisions/row.support
        if contact_rate>=.75:effects.append('CONTACT')
        if collision_rate>=.75:effects.append('COLLISION')
        return {'action':row.action,'status':'LEARNED','scope':'SIMULATION','support':row.support,'success':row.success,'failure':row.failure,
                'contact_rate':contact_rate,'collision_rate':collision_rate,'effects':effects}
    def response_profile(self,target_id):
        row=self.targets.get(str(target_id))
        if not row or row.samples<self.min_response_samples or row.sum_effort<=self.epsilon:
            return {'target_id':str(target_id),'status':'UNKNOWN','scope':'SIMULATION','samples':0 if not row else row.samples}
        mobility=row.sum_displacement/row.sum_effort
        resistance=None if mobility<=self.epsilon else 1.0/mobility
        return {'target_id':row.target_id,'status':'LEARNED','scope':'SIMULATION','samples':row.samples,
                'mobility_per_effort':mobility,'response_resistance_index':resistance}
    def predict_displacement(self,target_id,effort):
        p=self.response_profile(target_id)
        if p['status']!='LEARNED':return {'target_id':str(target_id),'status':'UNKNOWN','scope':'SIMULATION'}
        return {'target_id':str(target_id),'status':'PREDICTION','scope':'SIMULATION','effort':float(effort),
                'predicted_displacement':max(0.0,float(effort)*p['mobility_per_effort'])}
    def compare_response(self,a,b):
        pa,pb=self.response_profile(a),self.response_profile(b)
        if pa['status']!='LEARNED' or pb['status']!='LEARNED':return {'status':'UNKNOWN','scope':'SIMULATION','a':str(a),'b':str(b)}
        ma,mb=pa['mobility_per_effort'],pb['mobility_per_effort'];r=self.separation_ratio
        if ma*r<mb:rel='A_MORE_RESISTANT'
        elif mb*r<ma:rel='A_LESS_RESISTANT'
        else:rel='SIMILAR_RESPONSE'
        return {'status':'LEARNED','scope':'SIMULATION','a':str(a),'b':str(b),'relation':rel,'a_mobility':ma,'b_mobility':mb}
    def to_dict(self):
        return {'schema':self.SCHEMA,'min_support':self.min_support,'min_response_samples':self.min_response_samples,
                'epsilon':self.epsilon,'separation_ratio':self.separation_ratio,
                'actions':[asdict(x) for x in self.actions.values()],'targets':[asdict(x) for x in self.targets.values()]}
    @classmethod
    def from_dict(cls,d):
        x=cls((d or {}).get('min_support',4),(d or {}).get('min_response_samples',4),(d or {}).get('epsilon',1e-6),(d or {}).get('separation_ratio',1.35))
        for z in (d or {}).get('actions',[]):
            row=InteractionActionStats(**z);x.actions[row.action]=row
        for z in (d or {}).get('targets',[]):
            row=TargetResponseStats(**z);x.targets[row.target_id]=row
        return x

class SyntheticContactWorld:
    """Deterministic sandbox for verified contact and effort-response experience.

    Hidden object ``response`` controls how far a movable target shifts for a given
    effort.  It participates in world physics/state hashing but is never copied into
    InteractionTransition, so C4 can only infer response from experienced outcomes.
    """
    def __init__(self,world_id='nursery_contact',episode_id='e1',self_pos=(0,0,0),yaw_deg=0.0,reach=1.0):
        self.world_id=str(world_id);self.episode_id=str(episode_id);self.step=0
        self.self_pos=_v3(self_pos);self.yaw_deg=float(yaw_deg);self.reach=float(reach);self.objects={}
    def add_object(self,object_id,pos,*,radius=.2,response=1.0,anchored=False):
        self.objects[str(object_id)]={'pos':_v3(pos),'radius':float(radius),'response':max(float(response),1e-6),'anchored':bool(anchored)}
        return str(object_id)
    def _snapshot(self):
        return {'self':[round(float(x),8) for x in self.self_pos],'yaw':round(self.yaw_deg%360.0,8),'reach':round(self.reach,8),
                'objects':{k:{'pos':[round(float(x),8) for x in v['pos']], 'radius':round(v['radius'],8),
                              'response':round(v['response'],8),'anchored':v['anchored']} for k,v in sorted(self.objects.items())}}
    def state_hash(self):
        raw=json.dumps(self._snapshot(),sort_keys=True,separators=(',',':')).encode();return hashlib.blake2s(raw,digest_size=12).hexdigest()
    def surface_distance(self,target_id):
        o=self.objects[str(target_id)];return max(0.0,float(np.linalg.norm(o['pos']-self.self_pos))-o['radius'])
    def request(self,action,*,target_id,effort=1.0):
        pre=self.state_hash();raw=f'{self.world_id}|{self.episode_id}|{self.step}|{action}|{target_id}|{effort}|{pre}'.encode()
        return {'request_id':'areq:'+hashlib.blake2s(raw,digest_size=10).hexdigest(),'action':str(action),'target_id':str(target_id),
                'effort':max(0.0,float(effort)),'pre_state_hash':pre,'reality_scope':'SIMULATION'}
    def apply(self,request):
        pre_hash=self.state_hash();action=str(request.get('action'));target=str(request.get('target_id'));effort=max(0.0,float(request.get('effort',0.0)))
        success=True;outcome='OK';contact=False;collision=False
        pre_target=np.zeros(3,dtype=float);post_target=np.zeros(3,dtype=float);db=float('inf');da=float('inf')
        if request.get('pre_state_hash')!=pre_hash:success=False;outcome='STALE_ACTION_REQUEST'
        elif target not in self.objects:success=False;outcome='UNKNOWN_TARGET'
        else:
            o=self.objects[target];pre_target=o['pos'].copy();db=self.surface_distance(target);contact=db<=self.reach+1e-9
            if action=='TOUCH_TARGET':
                if not contact:success=False;outcome='NO_CONTACT'
                else:outcome='CONTACT'
            elif action=='PUSH_TARGET':
                if not contact:success=False;outcome='NO_CONTACT'
                else:
                    collision=effort>0.0
                    if o['anchored'] or effort<=0.0:outcome='CONTACT_BLOCKED'
                    else:
                        d=o['pos']-self.self_pos;n=float(np.linalg.norm(d));direction=(d/n) if n>1e-9 else np.array([0.0,0.0,1.0])
                        displacement=min(1.25,0.24*effort/o['response'])
                        o['pos']=o['pos']+direction*displacement;outcome='PUSHED'
            else:success=False;outcome='UNKNOWN_ACTION'
            post_target=o['pos'].copy();da=self.surface_distance(target)
        self.step+=1;post_hash=self.state_hash()
        receipt=SandboxReceipt(self.world_id,self.episode_id,self.step,action,pre_hash,post_hash,outcome,success)
        if target not in self.objects:
            pre_target=post_target=np.zeros(3,dtype=float);db=da=float('inf')
        displacement=float(np.linalg.norm(post_target-pre_target))
        tr=InteractionTransition(_receipt_id(receipt),action,target,effort,contact,collision,tuple(pre_target),tuple(post_target),displacement,db,da)
        return receipt,tr


# ---------------------------------------------------------------------------
# G309: support / release / fall dynamics

@dataclass
class SupportFallTransition:
    """Environment-owned low-level vertical dynamics observation.

    The simulator's acceleration constant is deliberately NOT exposed.  The
    learner sees only verified before/after position, velocity, held state and
    geometric contact-below state.
    """
    receipt_id:str
    event:str
    object_id:str
    dt:float
    pre_y:float
    post_y:float
    pre_vy:float
    post_vy:float
    held_before:bool
    held_after:bool
    contact_below_before:bool
    contact_below_after:bool
    reality_scope:str='SIMULATION'
    provenance:str='SANDBOX_DYNAMICS'
    @property
    def vertical_displacement(self):return float(self.post_y-self.pre_y)
    def to_dict(self):
        d=asdict(self);d['vertical_displacement']=self.vertical_displacement;return d

@dataclass
class DynamicsBucket:
    key:str
    support:int=0
    receipt_ids:list=field(default_factory=list)
    sum_dy:float=0.0
    sum_abs_dy:float=0.0
    sum_accel_y:float=0.0
    accel_samples:int=0

class SupportFallLearner:
    """Learns sandbox vertical regularities from verified state transitions.

    No word such as gravity/support/fall is installed as graph truth here.
    Public tags are capability-local engineering labels for inspectability.
    They remain SIMULATION-scoped and can later be bound to language through an
    explicit teaching act.
    """
    SCHEMA='C4_SUPPORT_FALL_V0.1'
    def __init__(self,min_support=4,epsilon=.01):
        self.min_support=int(min_support);self.epsilon=float(epsilon);self.rows:Dict[str,DynamicsBucket]={}
    def _bucket(self,key):return self.rows.setdefault(key,DynamicsBucket(key))
    def observe(self,receipt:SandboxReceipt,tr:SupportFallTransition):
        if receipt.provenance!='SANDBOX_RECEIPT' or receipt.reality_scope!='SIMULATION':raise ValueError('unverified dynamics receipt')
        if tr.reality_scope!='SIMULATION' or tr.provenance!='SANDBOX_DYNAMICS':raise ValueError('wrong dynamics scope')
        rid=_receipt_id(receipt)
        if rid!=tr.receipt_id:raise ValueError('receipt/dynamics mismatch')
        if str(receipt.action)!=str(tr.event):raise ValueError('event mismatch')
        keys=[]
        if tr.event=='RELEASE_OBJECT' and tr.held_before and not tr.held_after:keys.append('RELEASE')
        if tr.event=='ENVIRONMENT_STEP':
            if tr.held_before:keys.append('HELD')
            elif tr.contact_below_before:keys.append('CONTACT_BELOW')
            else:keys.append('FREE_NO_CONTACT')
            if (not tr.contact_below_before) and tr.contact_below_after:keys.append('CONTACT_ONSET')
        for key in keys:
            row=self._bucket(key)
            if rid in row.receipt_ids:continue
            row.receipt_ids.append(rid);row.support+=1
            dy=tr.vertical_displacement;row.sum_dy+=dy;row.sum_abs_dy+=abs(dy)
            # Acceleration is estimated only from uninterrupted free-flight steps.
            if key=='FREE_NO_CONTACT' and not tr.contact_below_after and tr.dt>0:
                row.sum_accel_y+=(float(tr.post_vy)-float(tr.pre_vy))/float(tr.dt);row.accel_samples+=1
        return keys
    def effect(self,key):
        row=self.rows.get(str(key))
        if not row or row.support<self.min_support:return {'condition':str(key),'status':'UNKNOWN','scope':'SIMULATION','support':0 if not row else row.support}
        mean_dy=row.sum_dy/row.support;mean_abs=row.sum_abs_dy/row.support;tags=[];e=self.epsilon
        if key=='RELEASE':tags.append('HELD_TO_FREE')
        elif key=='HELD' and mean_abs<=e:tags.append('POSITION_STABLE')
        elif key=='CONTACT_BELOW' and mean_abs<=e:tags.extend(['CONTACT_BELOW','POSITION_STABLE'])
        elif key=='FREE_NO_CONTACT':
            if mean_dy<-e:tags.append('DOWNWARD_CHANGE')
            if row.accel_samples:
                a=row.sum_accel_y/row.accel_samples
                if a<-e:tags.append('DOWNWARD_ACCELERATION')
        elif key=='CONTACT_ONSET':tags.extend(['CONTACT_ONSET','DOWNWARD_MOTION_STOPPED'])
        out={'condition':key,'status':'LEARNED','scope':'SIMULATION','support':row.support,'mean_vertical_displacement':mean_dy,'effects':tags}
        if row.accel_samples:out['mean_acceleration_y']=row.sum_accel_y/row.accel_samples;out['acceleration_samples']=row.accel_samples
        return out
    def predict_free_step(self,pre_vy,dt):
        row=self.rows.get('FREE_NO_CONTACT')
        if not row or row.accel_samples<self.min_support:return {'status':'UNKNOWN','scope':'SIMULATION'}
        a=row.sum_accel_y/row.accel_samples;dt=float(dt);vy=float(pre_vy)
        return {'status':'PREDICTION','scope':'SIMULATION','pre_vy':vy,'dt':dt,'predicted_dy':vy*dt+.5*a*dt*dt,'predicted_post_vy':vy+a*dt}
    def to_dict(self):return {'schema':self.SCHEMA,'min_support':self.min_support,'epsilon':self.epsilon,'rows':[asdict(x) for x in self.rows.values()]}
    @classmethod
    def from_dict(cls,d):
        x=cls((d or {}).get('min_support',4),(d or {}).get('epsilon',.01))
        for z in (d or {}).get('rows',[]):
            row=DynamicsBucket(**z);x.rows[row.key]=row
        return x

class SyntheticSupportWorld:
    """Deterministic SIMULATION world for release/free-motion/contact episodes.

    ``accel_y`` is environment physics and participates in world state hashing,
    but never enters SupportFallTransition.  Thus the learner must estimate it
    from experienced state changes.  Visual size/radius may vary independently.
    """
    def __init__(self,world_id='nursery_support',episode_id='e1',*,support_y=0.0,accel_y=-1.6):
        self.world_id=str(world_id);self.episode_id=str(episode_id);self.step=0
        self.support_y=float(support_y);self.accel_y=float(accel_y);self.objects={}
    def add_object(self,object_id,*,y=1.0,radius=.1,held=True,vy=0.0):
        self.objects[str(object_id)]={'y':float(y),'radius':max(1e-6,float(radius)),'held':bool(held),'vy':float(vy)}
        if not held and self._contact(str(object_id)):
            self.objects[str(object_id)]['y']=self.support_y+self.objects[str(object_id)]['radius'];self.objects[str(object_id)]['vy']=0.0
        return str(object_id)
    def _contact(self,object_id):
        o=self.objects[str(object_id)];return (o['y']-o['radius'])<=self.support_y+1e-9
    def _snapshot(self):
        return {'support_y':round(self.support_y,8),'accel_y':round(self.accel_y,8),'objects':{k:{'y':round(v['y'],8),'radius':round(v['radius'],8),'held':v['held'],'vy':round(v['vy'],8)} for k,v in sorted(self.objects.items())}}
    def state_hash(self):
        raw=json.dumps(self._snapshot(),sort_keys=True,separators=(',',':')).encode();return hashlib.blake2s(raw,digest_size=12).hexdigest()
    def request_release(self,object_id):
        pre=self.state_hash();raw=f'{self.world_id}|{self.episode_id}|{self.step}|RELEASE_OBJECT|{object_id}|{pre}'.encode()
        return {'request_id':'areq:'+hashlib.blake2s(raw,digest_size=10).hexdigest(),'action':'RELEASE_OBJECT','object_id':str(object_id),'pre_state_hash':pre,'reality_scope':'SIMULATION'}
    def release(self,request):
        pre_hash=self.state_hash();oid=str(request.get('object_id'));success=True;outcome='RELEASED'
        if request.get('pre_state_hash')!=pre_hash:success=False;outcome='STALE_ACTION_REQUEST'
        elif oid not in self.objects:success=False;outcome='UNKNOWN_OBJECT'
        o=self.objects.get(oid,{'y':0.,'vy':0.,'held':False,'radius':.1})
        py=float(o['y']);pvy=float(o['vy']);hb=bool(o['held']);cb=self._contact(oid) if oid in self.objects else False
        if success:
            if not o['held']:success=False;outcome='NOT_HELD'
            else:o['held']=False
        self.step+=1;post_hash=self.state_hash();ha=bool(o['held']);ca=self._contact(oid) if oid in self.objects else False
        receipt=SandboxReceipt(self.world_id,self.episode_id,self.step,'RELEASE_OBJECT',pre_hash,post_hash,outcome,success)
        tr=SupportFallTransition(_receipt_id(receipt),'RELEASE_OBJECT',oid,0.0,py,float(o['y']),pvy,float(o['vy']),hb,ha,cb,ca)
        return receipt,tr
    def advance(self,object_id,dt=.25):
        oid=str(object_id);dt=max(1e-6,float(dt));pre_hash=self.state_hash();success=True;outcome='ADVANCED'
        if oid not in self.objects:success=False;outcome='UNKNOWN_OBJECT';o={'y':0.,'vy':0.,'held':False,'radius':.1}
        else:o=self.objects[oid]
        py=float(o['y']);pvy=float(o['vy']);hb=bool(o['held']);cb=self._contact(oid) if oid in self.objects else False
        if success:
            if o['held']:
                o['vy']=0.0;outcome='HELD_STABLE'
            elif cb and o['vy']<=0.0:
                o['y']=self.support_y+o['radius'];o['vy']=0.0;outcome='CONTACT_STABLE'
            else:
                ny=o['y']+o['vy']*dt+.5*self.accel_y*dt*dt
                nvy=o['vy']+self.accel_y*dt
                floor_center=self.support_y+o['radius']
                if ny<=floor_center:
                    o['y']=floor_center;o['vy']=0.0;outcome='CONTACT_REACHED'
                else:
                    o['y']=ny;o['vy']=nvy;outcome='FREE_CHANGE'
        self.step+=1;post_hash=self.state_hash();ha=bool(o['held']);ca=self._contact(oid) if oid in self.objects else False
        receipt=SandboxReceipt(self.world_id,self.episode_id,self.step,'ENVIRONMENT_STEP',pre_hash,post_hash,outcome,success)
        tr=SupportFallTransition(_receipt_id(receipt),'ENVIRONMENT_STEP',oid,dt,py,float(o['y']),pvy,float(o['vy']),hb,ha,cb,ca)
        return receipt,tr
